// scripts/bench/engine-followup-csv-memory.runner.mjs
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { setImmediate } from "node:timers/promises";

// actual-source:src/core/math.ts
var G = 9.80665;
var TAU = Math.PI * 2;
var clamp = (x, a, b) => Math.max(a, Math.min(b, x));
var lerp = (a, b, t) => a + (b - a) * t;

// actual-source:src/simulation/bike-definitions.ts
function chassisLean(lean, spec) {
  const arm = spec.cgHeight - spec.crownRadius;
  return lean + Math.asin(clamp(spec.crownRadius * Math.sin(lean) / arm, -1, 1));
}
function dynamicLean(chassis, spec) {
  let lo = -Math.PI / 2, hi = Math.PI / 2;
  for (let i = 0; i < 40; i++) {
    const mid = (lo + hi) / 2;
    if (chassisLean(mid, spec) < chassis) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}
function bikeEnvelope(spec, wheelbase, mass, topSpeed, margins = {}) {
  const gain = spec.riderOffsetMax * 0.25 / spec.cgHeight;
  const lean = Math.min(
    dynamicLean(spec.maxLean, spec),
    Math.atan(Math.max(0.2, 0.72 * spec.mu - gain))
  );
  const lateralBase = G * Math.min(Math.tan(lean) + gain / Math.cos(lean), 0.8 * spec.mu);
  const brakingBase = Math.min(
    G * spec.cgToFront / spec.cgHeight * spec.stoppieMargin,
    ((spec.frontBrake ?? Infinity) + (spec.rearBrake ?? 0)) / mass
  );
  const rearWing = spec.downforce * (1 - spec.downforceFront);
  const brakingAero = (spec.drag + spec.stoppieMargin * rearWing * wheelbase / spec.cgHeight) / mass;
  return Object.freeze({
    lateralBase: Math.round(lateralBase * 100) / 100,
    lateralAero: 0,
    brakingBase: Math.round(brakingBase * 100) / 100,
    brakingAero: Math.round(brakingAero * 1e6) / 1e6,
    lateralMargin: margins.lateralMargin ?? 0.86,
    slowLateralMargin: margins.slowLateralMargin ?? 0.8,
    brakingMargin: margins.brakingMargin ?? 0.78,
    topSpeed,
    referenceMu: 1.82,
    downforceReference: mass
  });
}
var BIKE_SETUP_KEYS = Object.freeze({
  electronic: Object.freeze([
    "frontPreload",
    "rearPreload",
    "frontDamping",
    "rearDamping",
    "steeringDamper",
    "gearing",
    "tractionMap",
    "wheelieMap",
    "engineBrakeMap"
  ]),
  roadster: Object.freeze([
    "frontPreload",
    "rearPreload",
    "frontDamping",
    "rearDamping",
    "gearing",
    "tractionMap",
    "engineBrakeMap"
  ]),
  classic: Object.freeze(["rearPreload", "frontDamping", "rearDamping", "gearing"]),
  offroad: Object.freeze(["rearPreload", "frontDamping", "rearDamping", "gearing"])
});
var TRACTION_MAPS = Object.freeze([
  0.92,
  1,
  0.96,
  0.92,
  0.88,
  0.84,
  0.8
]);
var WHEELIE_MAPS = Object.freeze([
  { limit: 1, keep: 0.2 },
  { limit: 1.6, keep: 0.08 },
  { limit: 1.3, keep: 0.14 },
  { limit: 1, keep: 0.2 },
  { limit: 0.75, keep: 0.26 },
  { limit: 0.5, keep: 0.32 }
]);
var ENGINE_BRAKE_MAPS = Object.freeze([0, 0.06, 0.12, 0.18]);
var GP_AI_MARGINS = Object.freeze({ brakingMargin: 0.7 });
var GP_BIKE = Object.freeze({
  riderMass: 72,
  fuel: 16,
  cgHeight: 0.62,
  cgToFront: 0.7,
  cgToRear: 0.75,
  frontWheelRadius: 0.3,
  rearWheelRadius: 0.32,
  crownRadius: 0.075,
  maxSteer: 0.6,
  steerRate: 2.4,
  maxLean: 1.12,
  mu: 1.75,
  frontBrake: 7600,
  rearBrake: 1900,
  drag: 0.215,
  tuckDrag: 0.09,
  downforce: 0.045,
  downforceFront: 0.6,
  rolling: 0.015,
  riderOffsetMax: 0.3,
  drivelineEfficiency: 0.92,
  gearbox: "seamless",
  shiftCut: 0,
  manualClutch: Object.freeze({ capacity: 195, inertia: 0.105 }),
  launchRPM: 9e3,
  wheelieLimit: 0.1,
  stoppieMargin: 0.92,
  forkTravel: 0.125,
  forkRate: 32e3,
  shockTravel: 0.13,
  shockRate: 38e3,
  crashEnergy: 2600
});
var SUPERBIKE = Object.freeze({
  riderMass: 72,
  fuel: 15,
  cgHeight: 0.64,
  cgToFront: 0.69,
  cgToRear: 0.75,
  frontWheelRadius: 0.3,
  rearWheelRadius: 0.32,
  crownRadius: 0.08,
  maxSteer: 0.6,
  steerRate: 2.2,
  maxLean: 1.08,
  mu: 1.62,
  frontBrake: 6800,
  rearBrake: 1700,
  drag: 0.235,
  tuckDrag: 0.08,
  downforce: 0,
  downforceFront: 0.6,
  rolling: 0.016,
  riderOffsetMax: 0.28,
  drivelineEfficiency: 0.91,
  gearbox: "quickshifter",
  shiftCut: 0.035,
  launchRPM: 7500,
  wheelieLimit: 0.12,
  stoppieMargin: 0.9,
  forkTravel: 0.12,
  forkRate: 3e4,
  shockTravel: 0.12,
  shockRate: 36e3,
  crashEnergy: 2800
});
var bikeStations = Object.freeze({
  floorY: -0.5,
  damageZ: 0.62,
  frontElement: Object.freeze([1, 0.8]),
  rearElement: Object.freeze([-1, 1.2]),
  jackZ: Object.freeze([-0.8, 0.7]),
  jackX: 0.1
});
var wheels = (spec) => Object.freeze([
  Object.freeze([0, spec.frontWheelRadius - spec.cgHeight, spec.cgToFront]),
  Object.freeze([0, spec.frontWheelRadius - spec.cgHeight, spec.cgToFront]),
  Object.freeze([0, spec.rearWheelRadius - spec.cgHeight, -spec.cgToRear]),
  Object.freeze([0, spec.rearWheelRadius - spec.cgHeight, -spec.cgToRear])
]);
var GP_R1 = Object.freeze({
  id: "gpr1",
  version: 1,
  name: "GP-R1 PROTOTYPE",
  classId: "gp-bike",
  dynamicsKind: "bike",
  spec: Object.freeze({
    dryMass: 157 + GP_BIKE.riderMass,
    wheelRadius: GP_BIKE.rearWheelRadius,
    wheelInertia: 0.9,
    wheelbase: 1.45,
    track: 0,
    inertia: Object.freeze([62, 55, 24]),
    restLength: 0.3,
    linkCentreHeight: 0.3,
    travel: GP_BIKE.forkTravel,
    maxSteer: GP_BIKE.maxSteer,
    finalDrive: 2.6,
    gearRatios: Object.freeze([0, 0, 4.7, 3.85, 3.25, 2.85, 2.55, 2.36]),
    idleRPM: 4200,
    shiftRPM: 17600,
    downshiftRPM: 11500,
    limiterRPM: 18200,
    maxBatteryJ: 0,
    motorPowerW: 224e3,
    regenPowerW: 0,
    brakeTorque: GP_BIKE.frontBrake * GP_BIKE.frontWheelRadius,
    airDensity: 1.225,
    torqueCurve: Object.freeze([
      Object.freeze([4e3, 58]),
      Object.freeze([8e3, 92]),
      Object.freeze([11e3, 113]),
      Object.freeze([13500, 124]),
      Object.freeze([16e3, 127]),
      Object.freeze([17500, 121]),
      Object.freeze([18200, 104])
    ])
  }),
  wheelPositions: wheels(GP_BIKE),
  drivetrain: "rwd",
  aero: Object.freeze({ downforce: 0, drag: 1, frontZ: 0.55, rearZ: -0.55 }),
  halfExtents: Object.freeze([0.36, 0.56, 1.02]),
  stations: bikeStations,
  tireGrip: 1,
  hybrid: false,
  drs: false,
  setupKeys: BIKE_SETUP_KEYS.electronic,
  ai: bikeEnvelope(GP_BIKE, 1.45, 157 + GP_BIKE.riderMass + GP_BIKE.fuel, 99, GP_AI_MARGINS),
  bike: GP_BIKE
});
var SBK_1000 = Object.freeze({
  id: "sbk1000",
  version: 1,
  name: "SBK-1000 SUPERBIKE",
  classId: "superbike",
  dynamicsKind: "bike",
  spec: Object.freeze({
    dryMass: 200 + SUPERBIKE.riderMass,
    wheelRadius: SUPERBIKE.rearWheelRadius,
    wheelInertia: 0.95,
    wheelbase: 1.44,
    track: 0,
    inertia: Object.freeze([70, 62, 28]),
    restLength: 0.3,
    linkCentreHeight: 0.3,
    travel: SUPERBIKE.forkTravel,
    maxSteer: SUPERBIKE.maxSteer,
    finalDrive: 2.53,
    gearRatios: Object.freeze([0, 0, 4.55, 3.7, 3.1, 2.7, 2.4, 2.19]),
    idleRPM: 2e3,
    shiftRPM: 14300,
    downshiftRPM: 9200,
    limiterRPM: 14800,
    maxBatteryJ: 0,
    motorPowerW: 16e4,
    regenPowerW: 0,
    brakeTorque: SUPERBIKE.frontBrake * SUPERBIKE.frontWheelRadius,
    airDensity: 1.225,
    torqueCurve: Object.freeze([
      Object.freeze([3e3, 55]),
      Object.freeze([6e3, 84]),
      Object.freeze([9e3, 107]),
      Object.freeze([11e3, 117]),
      Object.freeze([13e3, 114]),
      Object.freeze([14e3, 106]),
      Object.freeze([14800, 88])
    ])
  }),
  wheelPositions: wheels(SUPERBIKE),
  drivetrain: "rwd",
  aero: Object.freeze({ downforce: 0, drag: 1, frontZ: 0.55, rearZ: -0.55 }),
  halfExtents: Object.freeze([0.38, 0.58, 1.04]),
  stations: bikeStations,
  tireGrip: 1,
  hybrid: false,
  drs: false,
  setupKeys: BIKE_SETUP_KEYS.electronic,
  ai: bikeEnvelope(SUPERBIKE, 1.44, 200 + SUPERBIKE.riderMass + SUPERBIKE.fuel, 87),
  bike: SUPERBIKE
});
var BIKE_VEHICLES = Object.freeze({
  gpr1: GP_R1,
  sbk1000: SBK_1000
});
function roadBike(sheet) {
  const b = sheet.bike, wheelbase = b.cgToFront + b.cgToRear, mass = sheet.machineMass + b.riderMass;
  return Object.freeze({
    id: sheet.id,
    version: 1,
    name: sheet.name,
    classId: sheet.classId,
    dynamicsKind: "bike",
    spec: Object.freeze({
      dryMass: mass,
      wheelRadius: b.rearWheelRadius,
      wheelInertia: sheet.wheelInertia,
      wheelbase,
      track: 0,
      inertia: Object.freeze([...sheet.inertia]),
      restLength: 0.3,
      linkCentreHeight: 0.3,
      travel: b.forkTravel,
      maxSteer: b.maxSteer,
      finalDrive: sheet.finalDrive,
      gearRatios: Object.freeze([...sheet.gearRatios]),
      idleRPM: sheet.idleRPM,
      shiftRPM: sheet.shiftRPM,
      downshiftRPM: sheet.downshiftRPM,
      limiterRPM: sheet.limiterRPM,
      maxBatteryJ: 0,
      motorPowerW: sheet.powerW,
      regenPowerW: 0,
      brakeTorque: b.frontBrake * b.frontWheelRadius,
      airDensity: 1.225,
      torqueCurve: Object.freeze(
        sheet.torqueCurve.map((p) => Object.freeze([p[0], p[1]]))
      )
    }),
    wheelPositions: wheels(b),
    drivetrain: "rwd",
    aero: Object.freeze({ downforce: 0, drag: 1, frontZ: 0.55, rearZ: -0.55 }),
    halfExtents: Object.freeze([...sheet.halfExtents]),
    stations: bikeStations,
    tireGrip: 1,
    hybrid: false,
    drs: false,
    setupKeys: sheet.setupKeys ?? BIKE_SETUP_KEYS.electronic,
    ai: bikeEnvelope(b, wheelbase, mass + b.fuel, sheet.topSpeed, sheet.aiMargins),
    bike: b
  });
}
var GP_R2 = roadBike({
  id: "gpr2",
  name: "GP-R2 PROTOTYPE",
  classId: "gp-bike",
  bike: Object.freeze({
    ...GP_BIKE,
    manualClutch: Object.freeze({ capacity: 200, inertia: 0.112 }),
    cgHeight: 0.61,
    cgToFront: 0.72,
    cgToRear: 0.73,
    maxLean: 1.13,
    frontBrake: 7700,
    drag: 0.25,
    tuckDrag: 0.09,
    downforce: 0.062,
    downforceFront: 0.7,
    launchRPM: 9e3,
    wheelieLimit: 0.09
  }),
  machineMass: 157,
  wheelInertia: 0.9,
  inertia: [61, 54, 24],
  finalDrive: 2.6,
  gearRatios: [0, 0, 4.6, 3.8, 3.2, 2.82, 2.53, 2.34],
  idleRPM: 4300,
  shiftRPM: 18e3,
  downshiftRPM: 11800,
  limiterRPM: 18500,
  powerW: 216e3,
  torqueCurve: [
    [4e3, 46],
    [8e3, 76],
    [11e3, 98],
    [14e3, 116],
    [16500, 124],
    [17800, 117],
    [18500, 100]
  ],
  halfExtents: [0.37, 0.56, 1.02],
  topSpeed: 96,
  aiMargins: GP_AI_MARGINS
});
var SS_600 = roadBike({
  id: "ss600",
  name: "SS-600 SUPERSPORT",
  classId: "supersport",
  bike: Object.freeze({
    ...SUPERBIKE,
    fuel: 13,
    cgHeight: 0.6,
    cgToFront: 0.66,
    cgToRear: 0.71,
    frontWheelRadius: 0.3,
    rearWheelRadius: 0.315,
    crownRadius: 0.08,
    steerRate: 2.3,
    maxLean: 1.05,
    mu: 1.55,
    frontBrake: 6200,
    rearBrake: 1500,
    drag: 0.215,
    tuckDrag: 0.09,
    launchRPM: 9e3,
    wheelieLimit: 0.12,
    forkRate: 26e3,
    shockRate: 32e3,
    crashEnergy: 2600
  }),
  machineMass: 175,
  wheelInertia: 0.8,
  inertia: [60, 52, 23],
  finalDrive: 2.85,
  gearRatios: [0, 0, 5.2, 4.1, 3.45, 3, 2.7, 2.48],
  idleRPM: 1800,
  shiftRPM: 15600,
  downshiftRPM: 1e4,
  limiterRPM: 16e3,
  powerW: 95e3,
  torqueCurve: [
    [4e3, 30],
    [8e3, 46],
    [11e3, 58],
    [13e3, 63],
    [14500, 62.5],
    [15500, 57],
    [16e3, 52]
  ],
  halfExtents: [0.35, 0.56, 1],
  topSpeed: 74
});
var NR_900 = roadBike({
  id: "nr900",
  name: "NR-900 NAKED ROADSTER",
  classId: "road-bike",
  bike: Object.freeze({
    ...SUPERBIKE,
    riderMass: 75,
    fuel: 11,
    cgHeight: 0.66,
    cgToFront: 0.68,
    cgToRear: 0.75,
    frontWheelRadius: 0.3,
    rearWheelRadius: 0.315,
    crownRadius: 0.085,
    maxSteer: 0.62,
    steerRate: 2.6,
    maxLean: 0.96,
    mu: 1.3,
    frontBrake: 5600,
    rearBrake: 1500,
    drag: 0.3,
    tuckDrag: 0.04,
    rolling: 0.017,
    riderOffsetMax: 0.2,
    drivelineEfficiency: 0.9,
    shiftCut: 0.04,
    launchRPM: 6500,
    wheelieLimit: 0.14,
    stoppieMargin: 0.88,
    forkTravel: 0.13,
    forkRate: 22e3,
    shockTravel: 0.13,
    shockRate: 28e3,
    crashEnergy: 2400
  }),
  machineMass: 182,
  wheelInertia: 0.85,
  inertia: [66, 58, 26],
  finalDrive: 2.9,
  gearRatios: [0, 0, 4.4, 3.4, 2.8, 2.4, 2.15, 1.97],
  idleRPM: 1300,
  shiftRPM: 10600,
  downshiftRPM: 6e3,
  limiterRPM: 11e3,
  powerW: 88e3,
  torqueCurve: [
    [2e3, 55],
    [4e3, 78],
    [7e3, 93],
    [9e3, 88],
    [1e4, 84],
    [10500, 76],
    [11e3, 68]
  ],
  halfExtents: [0.42, 0.58, 1.02],
  topSpeed: 62,
  setupKeys: BIKE_SETUP_KEYS.roadster
});
var CR_750 = roadBike({
  id: "cr750",
  name: "CR-750 CLASSIC RACER",
  classId: "classic-bike",
  bike: Object.freeze({
    ...SUPERBIKE,
    fuel: 18,
    cgHeight: 0.58,
    cgToFront: 0.7,
    cgToRear: 0.72,
    frontWheelRadius: 0.31,
    rearWheelRadius: 0.315,
    crownRadius: 0.065,
    steerRate: 2,
    maxLean: 0.9,
    mu: 1.25,
    // Single front disc and a rear drum: brake-limited, not stoppie-limited.
    frontBrake: 1700,
    rearBrake: 650,
    drag: 0.24,
    tuckDrag: 0.1,
    rolling: 0.018,
    riderOffsetMax: 0.2,
    drivelineEfficiency: 0.9,
    shiftCut: 0.09,
    launchRPM: 7500,
    wheelieLimit: 0.15,
    stoppieMargin: 0.86,
    forkRate: 18e3,
    shockTravel: 0.09,
    shockRate: 26e3,
    crashEnergy: 2200
  }),
  machineMass: 160,
  wheelInertia: 0.8,
  inertia: [58, 50, 22],
  finalDrive: 2.4,
  gearRatios: [0, 0, 3.4, 2.75, 2.35, 2.1, 1.94],
  idleRPM: 1500,
  shiftRPM: 9600,
  downshiftRPM: 6800,
  limiterRPM: 1e4,
  powerW: 75e3,
  torqueCurve: [
    [4e3, 45],
    [6e3, 62],
    [7500, 76],
    [8500, 80],
    [9e3, 79],
    [9500, 70],
    [1e4, 58]
  ],
  halfExtents: [0.34, 0.55, 1],
  topSpeed: 66,
  // Narrow tyres and drum-era brakes: the rider brakes earlier and leans less.
  aiMargins: { lateralMargin: 0.8, slowLateralMargin: 0.74, brakingMargin: 0.66 },
  setupKeys: BIKE_SETUP_KEYS.classic
});
var BIKE_ADDITIONS = Object.freeze({
  gpr2: GP_R2,
  ss600: SS_600,
  nr900: NR_900,
  cr750: CR_750
});

// actual-source:src/simulation/aero-map.ts
var RIDE_AXIS = [0, 0.012, 0.025, 0.044, 0.065, 0.075, 0.11, 0.16, 0.25];
var PITCH_AXIS = [-0.12, -0.06, 0, 0.06, 0.12];
var PITCH_FRONT = [0.8, 0.92, 1, 1.03, 0.88];
var PITCH_REAR = [0.9, 1.025, 1, 0.93, 0.81];
var PITCH_FLOOR = [0.61, 0.85, 1, 0.89, 0.65];
var PITCH_DRAG = [1.18, 1.055, 1, 1.055, 1.18];
var WING_GROUND = [0.88, 0.94, 0.98, 1, 1, 1, 0.985, 0.96, 0.93];
var FLOOR = [
  0.3,
  0.3,
  0.300507355,
  0.462353516,
  0.79376297,
  0.925087738,
  1,
  0.965605416,
  0.70468809,
  0.3,
  0.3,
  0.374912262,
  0.65,
  0.945072174,
  0.999492645,
  1,
  0.925889854,
  0.675704114,
  0.300507355,
  0.374912262,
  0.552716064,
  0.851548004,
  1,
  1,
  1,
  0.884705905,
  0.645648526,
  0.462353516,
  0.65,
  0.851548004,
  1,
  1,
  1,
  0.986097544,
  0.827786507,
  0.604109383,
  0.79376297,
  0.945072174,
  1,
  1,
  1,
  1,
  0.916218872,
  0.769126364,
  0.561299864,
  0.925087738,
  0.999492645,
  1,
  1,
  1,
  1,
  0.884705905,
  0.742672583,
  0.541994188,
  1,
  1,
  1,
  0.986097544,
  0.916218872,
  0.884705905,
  0.782704538,
  0.65704682,
  0.479505459,
  0.965605416,
  0.925889854,
  0.884705905,
  0.827786507,
  0.769126364,
  0.742672583,
  0.65704682,
  0.551562566,
  0.402524224,
  0.70468809,
  0.675704114,
  0.645648526,
  0.604109383,
  0.561299864,
  0.541994188,
  0.479505459,
  0.402524224,
  0.2937577
];
var lower = (axis, x) => {
  let i = 0;
  while (i < axis.length - 2 && x > axis[i + 1]) i++;
  return i;
};
function sample1(axis, values, x) {
  const i = lower(axis, x);
  return lerp(values[i], values[i + 1], clamp((x - axis[i]) / (axis[i + 1] - axis[i]), 0, 1));
}
function sampleAeroMap(frontM, rearM, pitchRad, out) {
  if (!Number.isFinite(frontM) || !Number.isFinite(rearM) || !Number.isFinite(pitchRad))
    throw new Error("Non-finite aero map input");
  const i = lower(RIDE_AXIS, frontM), j = lower(RIDE_AXIS, rearM), n = RIDE_AXIS.length;
  const u = clamp((frontM - RIDE_AXIS[i]) / (RIDE_AXIS[i + 1] - RIDE_AXIS[i]), 0, 1);
  const v = clamp((rearM - RIDE_AXIS[j]) / (RIDE_AXIS[j + 1] - RIDE_AXIS[j]), 0, 1);
  const floor = lerp(
    lerp(FLOOR[i * n + j], FLOOR[i * n + j + 1], v),
    lerp(FLOOR[(i + 1) * n + j], FLOOR[(i + 1) * n + j + 1], v),
    u
  );
  out.front = sample1(RIDE_AXIS, WING_GROUND, frontM) * sample1(PITCH_AXIS, PITCH_FRONT, pitchRad);
  out.rear = sample1(RIDE_AXIS, WING_GROUND, rearM) * sample1(PITCH_AXIS, PITCH_REAR, pitchRad);
  out.floor = floor * sample1(PITCH_AXIS, PITCH_FLOOR, pitchRad) * Math.exp(-7 * Math.max(0, (frontM + rearM) * 0.5 - RIDE_AXIS[RIDE_AXIS.length - 1]));
  out.drag = sample1(PITCH_AXIS, PITCH_DRAG, pitchRad);
  return out;
}

// actual-source:src/simulation/powertrain.ts
var LEGACY_ENGINE = Object.freeze({
  inertia: 0.34,
  throttleRise: 0,
  throttleFall: 0,
  throttleProgression: 1,
  frictionBase: 12,
  frictionViscous: 0.04,
  pumping: 0,
  turbo: null,
  table: null
});
var LEGACY_GEARBOX = Object.freeze({ shiftTime: 0.09, shiftCut: 1 });

// actual-source:src/simulation/tire-families.ts
var family = (id, name, grip, looseGrip, winterGrip = 0, blockDrainageMm = 0) => Object.freeze({
  id,
  name,
  grip: Object.freeze(grip),
  looseGrip,
  winterGrip,
  ...blockDrainageMm > 0 ? { blockDrainageMm } : {}
});
var TIRE_FAMILIES = Object.freeze({
  /** Wide, warm, high-downforce single-seater slick (the reference, 1.0). */
  "formula-slick": family("formula-slick", "Formula slick", [0.9, 1.05], 0),
  /** Closed-wheel racing slick: narrower relative to mass than a Formula slick. */
  slick: family("slick", "Racing slick", [0.74, 0.96], 0),
  /** Treaded track-day/club tyre: lower peak, a little loose-surface bite. */
  "semi-slick": family("semi-slick", "Semi-slick", [0.66, 0.84], 0.08, 0.03),
  /** High-performance road tyre: progressive, lower peak friction. */
  road: family("road", "Performance road", [0.58, 0.8], 0.12, 0.06),
  /** Rally gravel tyre: block tread for loose surfaces, softer on asphalt. */
  gravel: family("gravel", "Gravel rally", [0.56, 0.74], 0.55, 0.2),
  /** Large-volume off-road tyre: deep tread, heavy carcass. */
  "all-terrain": family("all-terrain", "All-terrain", [0.5, 0.7], 0.6, 0.18),
  /** Small soft kart slick: very low load per tyre, high friction. */
  kart: family("kart", "Kart slick", [0.85, 1.1], 0),
  /** Narrow 1960s cross-ply racing tyre. */
  historic: family("historic", "Historic cross-ply", [0.5, 0.7], 0.05),
  /** 1970s-80s racing slick: wide bias-ply or early radial construction, far
   * more grip than a cross-ply but less than a modern slick. */
  "historic-slick": family("historic-slick", "Historic slick", [0.68, 0.9], 0),
  /** Off-road motorcycle knobby: tall square blocks that bite into loam,
   * sand and mud (bike definitions carry their own peak μ; tireGrip 1). */
  knobby: family("knobby", "Motocross knobby", [0.6, 1.1], 0.8, 0.15, 3.2),
  /** Supermoto treaded slick: sticky on asphalt, a little bite on dirt. */
  supermoto: family("supermoto", "Supermoto treaded slick", [0.6, 1.1], 0.25, 0.03)
});
var TIRE_FAMILY_IDS = Object.freeze(Object.keys(TIRE_FAMILIES));

// actual-source:src/simulation/vehicle-catalogue/builder.ts
var BASELINE = Object.freeze({
  fuel: 24,
  frontSpring: 115e3,
  rearSpring: 125e3,
  frontRide: 0.065,
  rearRide: 0.075,
  frontWing: 0.55,
  rearWing: 0.58,
  /** Formula floor map at its static clearance gives ClA per unit scale. */
  airDensity: 1.225
});
var round = (x, digits = 4) => Number(x.toFixed(digits));
var engineFriction = (engine, rpm) => engine.frictionBase + rpm * Math.PI / 30 * engine.frictionPerRad;
var tuple = (v) => Object.freeze(v);
function effective(sheet, key) {
  const limit = sheet.setupLimits?.[key];
  const value = sheet.setupDefaults?.[key] ?? BASELINE[key];
  return limit ? Math.max(limit[0], Math.min(limit[1], value)) : value;
}
function aeroScales(sheet, frontAxle, rearAxle) {
  const fw = effective(sheet, "frontWing"), rw = effective(sheet, "rearWing"), h = sheet.groundClearance, map = sampleAeroMap(h, h, 0, { front: 0, rear: 0, floor: 0, drag: 0 }), cf = map.front * (0.85 + fw * 0.8), cr = map.rear * (1.05 + rw * 0.9), cfl = map.floor * 2.25, sum = cf + cr + cfl, L = sheet.wheelbase, { clA, cdA, balance } = sheet.aero;
  const drag = cdA / (1.3 * map.drag * (0.76 + fw * 0.14 + rw * 0.23));
  if (!(clA > 0)) return { downforce: 0, drag, frontZ: frontAxle, rearZ: rearAxle };
  const target = balance * sum * L;
  let frontZ = rearAxle + (target + cfl * rearAxle) / cf;
  frontZ = Math.max(rearAxle + 0.2, Math.min(frontAxle + sheet.overhangFront, frontZ));
  let rearZ = rearAxle + (target - cf * (frontZ - rearAxle) + cfl * rearAxle) / cr;
  rearZ = Math.max(rearAxle - sheet.overhangRear, Math.min(frontAxle, rearZ));
  return { downforce: clA / (1.3 * sum), drag, frontZ, rearZ };
}
function defineVehicle(sheet) {
  const L = sheet.wheelbase, frontAxle = (1 - sheet.frontWeight) * L, rearAxle = -sheet.frontWeight * L, restLength = sheet.restLength ?? 0.25, fuel = sheet.fuelLoad ?? BASELINE.fuel, loaded = (sheet.mass + fuel) * G, frontSag = loaded * sheet.frontWeight * 0.5 / effective(sheet, "frontSpring"), rearSag = loaded * (1 - sheet.frontWeight) * 0.5 / effective(sheet, "rearSpring"), frontRest = restLength + effective(sheet, "frontRide") - BASELINE.frontRide, rearRest = restLength + effective(sheet, "rearRide") - BASELINE.rearRide, frontY = round(frontRest - frontSag + sheet.wheelRadius - sheet.cogHeight), rearY = round(rearRest - rearSag + sheet.wheelRadius - sheet.cogHeight), frontExtent = frontAxle + sheet.overhangFront, rearExtent = -rearAxle + sheet.overhangRear, length = frontExtent + rearExtent, yaw = 0.8 * sheet.mass * (length * length + sheet.width * sheet.width) / 12, inertia = sheet.inertia ?? [round(yaw * 0.35, 0), round(yaw, 0), round(yaw * 0.9, 0)], aero = aeroScales(sheet, frontAxle, rearAxle), family2 = TIRE_FAMILIES[sheet.tireFamily], [frontMass, rearMass] = sheet.elementMass ?? [3.5, 4], hybrid = sheet.hybrid;
  const ai = Object.freeze({
    lineScale: 0.85,
    lookahead: Object.freeze([5, 0.38]),
    ...sheet.ai,
    ...sheet.ai.fanBase ? { fanBase: Object.freeze({ ...sheet.ai.fanBase }) } : {},
    referenceMu: 1.82,
    downforceReference: sheet.ai.lateralAero > 0 || sheet.ai.brakingAero > 0 ? sheet.mass + fuel : 0
  });
  const definition = Object.freeze({
    id: sheet.id,
    version: sheet.version ?? 1,
    name: sheet.name,
    classId: sheet.classId,
    dynamicsKind: "four-wheel",
    spec: Object.freeze({
      dryMass: sheet.mass,
      wheelRadius: sheet.wheelRadius,
      wheelInertia: sheet.wheelInertia,
      wheelbase: L,
      track: sheet.trackFront,
      inertia: tuple(inertia),
      restLength,
      linkCentreHeight: sheet.linkCentreHeight,
      travel: 0.17,
      maxSteer: sheet.maxSteer,
      finalDrive: sheet.finalDrive,
      gearRatios: tuple(sheet.gearRatios),
      idleRPM: sheet.idleRPM,
      shiftRPM: sheet.shiftRPM,
      downshiftRPM: sheet.downshiftRPM,
      limiterRPM: sheet.limiterRPM,
      maxBatteryJ: hybrid?.batteryJ ?? 0,
      motorPowerW: hybrid?.motorPowerW ?? 0,
      regenPowerW: hybrid?.regenPowerW ?? 0,
      brakeTorque: sheet.brakeTorque,
      airDensity: BASELINE.airDensity,
      torqueCurve: tuple(
        sheet.torqueCurve.map(
          ([rpm, net]) => tuple([rpm, round(net + engineFriction(sheet.engine, rpm), 1)])
        )
      ),
      engine: Object.freeze({ ...sheet.engine })
    }),
    wheelPositions: tuple([
      tuple([-sheet.trackFront / 2, frontY, round(frontAxle)]),
      tuple([sheet.trackFront / 2, frontY, round(frontAxle)]),
      tuple([-sheet.trackRear / 2, rearY, round(rearAxle)]),
      tuple([sheet.trackRear / 2, rearY, round(rearAxle)])
    ]),
    drivetrain: sheet.drivetrain,
    aero: Object.freeze({
      downforce: round(aero.downforce),
      drag: round(aero.drag),
      frontZ: round(aero.frontZ, 3),
      rearZ: round(aero.rearZ, 3)
    }),
    halfExtents: tuple([
      round(sheet.width / 2, 3),
      round(sheet.height * 0.4, 3),
      round(Math.max(frontExtent, rearExtent), 3)
    ]),
    stations: Object.freeze({
      floorY: round(sheet.groundClearance - sheet.cogHeight, 3),
      damageZ: round(Math.min(frontExtent, rearExtent) * 0.55, 3),
      frontElement: tuple([round(frontExtent - 0.12, 3), frontMass]),
      rearElement: tuple([round(-(rearExtent - 0.2), 3), rearMass]),
      jackZ: tuple([round(rearAxle * 0.85, 3), round(frontAxle * 0.85, 3)]),
      jackX: round(sheet.width * 0.24, 3),
      skid: tuple([
        round(sheet.width * 0.3, 3),
        round(frontAxle * 0.8, 3),
        round(rearAxle * 0.8, 3)
      ])
    }),
    tireGrip: sheet.tireGrip,
    ...sheet.rearGrip !== void 0 && sheet.rearGrip !== 1 ? { tireGripRear: round(sheet.tireGrip * sheet.rearGrip, 4) } : {},
    hybrid: !!hybrid,
    drs: !!sheet.drs,
    setupKeys: tuple([...sheet.setupKeys]),
    ai,
    driveline: Object.freeze({ ...sheet.driveline }),
    ...hybrid?.frontAxleAbove !== void 0 ? { hybridAxle: Object.freeze({ axle: "front", minSpeed: hybrid.frontAxleAbove }) } : {},
    tireFamily: family2.id,
    restHeight: round(sheet.cogHeight + 0.01, 3),
    ...sheet.fuelLoad !== void 0 ? { fuelLoad: sheet.fuelLoad } : {},
    ...sheet.setupDefaults ? { setupDefaults: Object.freeze({ ...sheet.setupDefaults }) } : {},
    ...sheet.setupLimits ? {
      setupLimits: Object.freeze(
        Object.fromEntries(
          Object.entries(sheet.setupLimits).map(([k, v]) => [k, tuple([v[0], v[1]])])
        )
      )
    } : {},
    powertrain: sheet.powertrain ?? (hybrid ? "hybrid" : "combustion"),
    // Turbo lag on the catalogue's legacy engine block (instant intake,
    // linear part load): the only engine-response change a sheet can make.
    ...sheet.turbo ? {
      dynamics: Object.freeze({
        engine: Object.freeze({
          ...LEGACY_ENGINE,
          turbo: Object.freeze({
            ...sheet.turbo,
            spoolRPM: tuple([sheet.turbo.spoolRPM[0], sheet.turbo.spoolRPM[1]])
          })
        })
      })
    } : {},
    // Skirts seal up to 12 mm above the static floor and lose suction over
    // the next 50 mm (a crest, kerb or rake change breaks the seal).
    ...sheet.fan ? {
      fan: Object.freeze({
        force: sheet.fan.force,
        sealHeight: round(sheet.groundClearance + 0.012, 3),
        fade: 0.05,
        z: round(sheet.fan.z ?? 0, 3)
      })
    } : {}
  });
  return Object.freeze({
    definition,
    bands: Object.freeze({ ...sheet.bands }),
    brief: sheet.brief
  });
}
function catalogue(entries) {
  const definitions = {}, bands = {}, briefs = {};
  for (const e of entries) {
    if (Object.hasOwn(definitions, e.definition.id))
      throw new Error(`Duplicate catalogue vehicle ${e.definition.id}`);
    definitions[e.definition.id] = e.definition;
    bands[e.definition.id] = e.bands;
    briefs[e.definition.id] = e.brief;
  }
  return {
    definitions: Object.freeze(definitions),
    bands: Object.freeze(bands),
    briefs: Object.freeze(briefs)
  };
}

// actual-source:src/simulation/differential.ts
var OPEN = Object.freeze({
  type: "open",
  preload: 0,
  power: 0,
  coast: 0
});
var LOCKED = Object.freeze({
  type: "locked",
  preload: 0,
  power: 0,
  coast: 0
});
var OPEN_CENTRE = Object.freeze({ ...OPEN, frontShare: 0.5 });
function lsd(preload, power, coast) {
  return Object.freeze({ type: "lsd", preload, power, coast });
}
var BASE = Object.freeze({
  kind: "open",
  preload: 0,
  powerLock: 0,
  coastLock: 0,
  viscousPower: 0,
  viscousCoast: 0,
  biasRatio: 1,
  maxLocking: 1e9,
  split: 0.5,
  stickFraction: 0.5,
  setupScaled: false
});
function differential(overrides) {
  return Object.freeze({ ...BASE, ...overrides });
}
var LEGACY_AXLE = differential({
  kind: "viscous",
  viscousPower: 55,
  viscousCoast: 55,
  maxLocking: 1050,
  setupScaled: true
});
var CLUTCH_LSD = differential({
  kind: "clutch",
  preload: 60,
  powerLock: 0.35,
  coastLock: 0.2,
  maxLocking: 2500,
  setupScaled: true
});
var OPEN_AXLE = differential({ kind: "open" });
var SPOOL = differential({ kind: "locked", stickFraction: 0.8 });
var TORSEN = differential({ kind: "torsen", biasRatio: 2.5 });
var differentialOutput = () => ({ first: 0, second: 0, locking: 0 });
var AXLE = differentialOutput();
var CENTRE = differentialOutput();

// actual-source:src/simulation/vehicle-catalogue/common.ts
var ALIGNMENT = [
  "frontPressure",
  "rearPressure",
  "frontCamber",
  "rearCamber",
  "frontToe",
  "rearToe"
];
var KEYS = Object.freeze({
  /** Single-seaters and prototypes: wings, springs, ride, bars, alignment. */
  winged: Object.freeze([
    "frontWing",
    "rearWing",
    "brakeBias",
    "diffPower",
    "diffCoast",
    "frontSpring",
    "rearSpring",
    "frontARB",
    "rearARB",
    "frontRide",
    "rearRide",
    ...ALIGNMENT
  ]),
  /** Racing saloons/GTs without adjustable wings in this model. */
  closed: Object.freeze([
    "brakeBias",
    "diffPower",
    "diffCoast",
    "frontSpring",
    "rearSpring",
    "frontARB",
    "rearARB",
    "frontRide",
    "rearRide",
    ...ALIGNMENT
  ]),
  /** Homologated springs and ride (karts, trucks, road cars, historics). */
  fixedChassis: Object.freeze([
    "brakeBias",
    "diffPower",
    "diffCoast",
    "frontARB",
    "rearARB",
    ...ALIGNMENT
  ])
});
function combustion(litres, clutchCapacity, inertia) {
  return Object.freeze({
    frictionBase: Number((3.5 * litres).toFixed(2)),
    frictionPerRad: Number((0.011 * litres).toFixed(4)),
    inertia,
    idleTorque: Math.min(180, Math.round(30 * litres + 20)),
    clutchCapacity
  });
}

// actual-source:src/simulation/vehicle-catalogue/touring-club.ts
var TOURING_TC2 = defineVehicle({
  id: "tc2",
  name: "TC-2 TOURING",
  classId: "touring",
  brief: "Rear-drive touring saloon: 2.0 L turbo four, 280 kW, 1240 kg, small splitter and wing. Intended skill: intermediate. Strengths: rotation on entry, traction with the limited-slip differential. Weaknesses: power oversteer, kerb strikes; it shares the touring grid with the front-drive TC-1, which brakes later.",
  mass: 1240,
  frontWeight: 0.52,
  cogHeight: 0.47,
  wheelbase: 2.75,
  trackFront: 1.58,
  trackRear: 1.58,
  width: 1.9,
  height: 1.3,
  overhangFront: 0.95,
  overhangRear: 0.85,
  groundClearance: 0.08,
  wheelRadius: 0.325,
  wheelInertia: 1.5,
  linkCentreHeight: 0.25,
  maxSteer: 0.46,
  finalDrive: 3.65,
  gearRatios: [-3.2, 0, 3.1, 2.25, 1.75, 1.42, 1.18, 1],
  idleRPM: 1500,
  shiftRPM: 7e3,
  downshiftRPM: 4e3,
  limiterRPM: 7300,
  torqueCurve: [
    [2e3, 320],
    [3500, 440],
    [5500, 450],
    [6500, 412],
    [7300, 340]
  ],
  engine: combustion(2, 760, 0.2),
  brakeTorque: 9e3,
  aero: { clA: 0.55, cdA: 0.78, balance: 0.42 },
  tireFamily: "slick",
  tireGrip: 0.82,
  rearGrip: 1.04,
  drivetrain: "rwd",
  driveline: { rear: lsd(70, 0.4, 0.25) },
  setupKeys: KEYS.closed,
  ai: {
    lateralBase: 12.8,
    lateralAero: 64e-5,
    brakingBase: 13.57,
    brakingAero: 75e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 67
  },
  bands: {
    accel0to100: [4, 5.6],
    topSpeed: [225, 265],
    braking100Distance: [26, 40],
    lateral80G: [1.15, 1.5]
  }
});
var CLUB_ROADSTER = defineVehicle({
  id: "cr1",
  name: "CR-1 CLUB ROADSTER",
  classId: "club",
  brief: "Lightweight open two-seater on semi-slicks: 2.0 L naturally aspirated four, 130 kW, 620 kg with driver, no downforce, the aerodynamics of a brick. Intended skill: novice. Strengths: low inertia, progressive limit, cheap. Weaknesses: top speed, slipstream exposure, lift at speed.",
  mass: 620,
  frontWeight: 0.48,
  cogHeight: 0.4,
  wheelbase: 2.25,
  trackFront: 1.38,
  trackRear: 1.42,
  width: 1.58,
  height: 1.05,
  overhangFront: 0.65,
  overhangRear: 0.45,
  groundClearance: 0.1,
  wheelRadius: 0.29,
  wheelInertia: 0.9,
  linkCentreHeight: 0.2,
  maxSteer: 0.48,
  finalDrive: 4.1,
  gearRatios: [-3.4, 0, 3.15, 2.2, 1.65, 1.3, 1.04],
  idleRPM: 1e3,
  shiftRPM: 7600,
  downshiftRPM: 4200,
  limiterRPM: 8e3,
  torqueCurve: [
    [2e3, 130],
    [4e3, 170],
    [6e3, 190],
    [7e3, 180],
    [7500, 166],
    [8e3, 140]
  ],
  engine: combustion(2, 400, 0.14),
  brakeTorque: 3600,
  aero: { clA: 0, cdA: 0.75, balance: 0.5 },
  tireFamily: "semi-slick",
  tireGrip: 0.74,
  drivetrain: "rwd",
  driveline: { rear: lsd(30, 0.3, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: {
    frontSpring: 6e4,
    rearSpring: 65e3,
    frontARB: 12e3,
    rearARB: 6e3,
    frontRide: 0.075,
    rearRide: 0.085
  },
  setupLimits: { frontARB: [0, 3e4], rearARB: [0, 25e3] },
  elementMass: [2, 2],
  ai: {
    lateralBase: 12.49,
    lateralAero: 0,
    brakingBase: 13,
    brakingAero: 0,
    lateralMargin: 0.75,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 55
  },
  bands: {
    accel0to100: [3.5, 5],
    topSpeed: [190, 220],
    braking100Distance: [28, 42],
    lateral80G: [1.1, 1.45]
  }
});

// actual-source:src/simulation/vehicle-catalogue/small-road.ts
var SHIFTER_KART = defineVehicle({
  id: "sk125",
  name: "SK-125 SHIFTER KART",
  classId: "kart",
  brief: "Gearbox kart: 125 cc two-stroke, 36 kW at 13 500 rpm, six-speed sequential, 175 kg with driver, solid rear axle, no suspension. Intended skill: novice\u2013expert. Strengths: braking, direction changes, enormous grip per kilogram. Weaknesses: understeer from the locked axle, tiny engine inertia (stalls, wheelspin), no protection in contact.",
  mass: 175,
  frontWeight: 0.42,
  cogHeight: 0.28,
  wheelbase: 1.04,
  trackFront: 1.12,
  trackRear: 1.36,
  width: 1.4,
  height: 0.62,
  overhangFront: 0.45,
  overhangRear: 0.3,
  groundClearance: 0.03,
  wheelRadius: 0.137,
  wheelInertia: 0.06,
  restLength: 0.08,
  linkCentreHeight: 0.12,
  maxSteer: 0.45,
  // Pitch and roll exceed a bare kart's so the shared per-corner dampers stay
  // inside the explicit 120 Hz stability limit (c·dt / I < 2).
  inertia: [45, 55, 70],
  finalDrive: 4.5,
  gearRatios: [-3, 0, 3, 2.3, 1.9, 1.6, 1.38, 1.19],
  idleRPM: 3500,
  shiftRPM: 14e3,
  downshiftRPM: 9e3,
  limiterRPM: 14500,
  torqueCurve: [
    [6e3, 13],
    [9e3, 21],
    [11e3, 26],
    [12500, 27],
    [13500, 25.5],
    [14500, 21]
  ],
  fuelLoad: 6,
  engine: {
    frictionBase: 0.4,
    frictionPerRad: 12e-4,
    inertia: 8e-3,
    idleTorque: 6,
    // Centrifugal launch clutch: slips at about 10 500 rpm from rest, locks
    // above 11 500 rpm (engagement spans 0.55-1.1 x engageRPM).
    clutchCapacity: 92,
    engageRPM: 15e3,
    clutchCoupling: 0.15
  },
  brakeTorque: 900,
  aero: { clA: 0, cdA: 0.6, balance: 0.5 },
  tireFamily: "kart",
  tireGrip: 1,
  rearGrip: 1,
  drivetrain: "rwd",
  driveline: { rear: LOCKED },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: {
    frontSpring: 6e4,
    rearSpring: 7e4,
    frontARB: 0,
    rearARB: 12e3,
    frontRide: 0.065,
    rearRide: 0.075,
    brakeBias: 0.48
  },
  setupLimits: { frontARB: [0, 15e3], rearARB: [0, 25e3], brakeBias: [0.48, 0.58] },
  elementMass: [0.8, 0.8],
  ai: {
    lateralBase: 17.9,
    lateralAero: 0,
    brakingBase: 19.92,
    brakingAero: 0,
    lateralMargin: 0.72,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 38,
    // A kart on a car circuit: tighter preview, further from the kerbs.
    lineScale: 0.75,
    lookahead: [4, 0.32]
  },
  bands: {
    accel0to100: [2.6, 4.2],
    topSpeed: [125, 150],
    braking100Distance: [18, 34],
    lateral80G: [1.8, 2.8]
  }
});
var ELECTRIC_HYPERCAR = defineVehicle({
  id: "eh3",
  name: "EH-3 ELECTRIC HYPERCAR",
  classId: "road",
  brief: "Road-legal electric hypercar for the open world: four motors modelled as one equivalent drive (1.1 MW, 1200 N m at the motor, single reduction), 1980 kg, four-wheel drive with a limited-slip centre coupling, road tyres. Intended skill: novice. Strengths: instant torque, traction. Weaknesses: mass, brake heat, tyre limit. Known limit: energy is drawn from the shared fuel-mass proxy.",
  mass: 1980,
  frontWeight: 0.44,
  cogHeight: 0.42,
  wheelbase: 2.75,
  trackFront: 1.7,
  trackRear: 1.66,
  width: 2.04,
  height: 1.2,
  overhangFront: 1.05,
  overhangRear: 0.95,
  groundClearance: 0.1,
  wheelRadius: 0.36,
  wheelInertia: 2.2,
  linkCentreHeight: 0.22,
  maxSteer: 0.5,
  finalDrive: 7.7,
  gearRatios: [-1, 0, 1],
  idleRPM: 300,
  shiftRPM: 19800,
  downshiftRPM: 400,
  limiterRPM: 2e4,
  torqueCurve: [
    [300, 1200],
    [8e3, 1200],
    [1e4, 1050],
    [14e3, 750],
    [18e3, 583],
    [2e4, 500]
  ],
  engine: {
    frictionBase: 2,
    frictionPerRad: 4e-3,
    inertia: 0.15,
    idleTorque: 120,
    clutchCapacity: 2e3
  },
  brakeTorque: 14e3,
  aero: { clA: 0.8, cdA: 0.68, balance: 0.45 },
  tireFamily: "road",
  tireGrip: 0.8,
  rearGrip: 1.12,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(200, 0.3, 0.3), frontShare: 0.45 },
    front: lsd(150, 0.3, 0.2),
    rear: lsd(150, 0.4, 0.2)
  },
  powertrain: "electric",
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 1e5, rearSpring: 11e4, frontARB: 24e3, rearARB: 18e3 },
  ai: {
    lateralBase: 11.11,
    lateralAero: 97e-5,
    brakingBase: 12.98,
    brakingAero: 65e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 97
  },
  bands: {
    accel0to100: [1.9, 2.8],
    topSpeed: [320, 365],
    braking100Distance: [28, 40],
    lateral80G: [1.1, 1.45]
  }
});
var SUPERCAR = defineVehicle({
  id: "sc7",
  name: "SC-7 SUPERCAR",
  classId: "road",
  brief: "Road-legal mid-engined supercar for the open world: 4.0 L twin-turbo V8, 530 kW, 1480 kg, seven-speed dual-clutch, electronic rear differential, active aero. Intended skill: novice\u2013intermediate. Strengths: acceleration, top speed. Weaknesses: rear-drive traction from rest, weight in long braking zones.",
  mass: 1480,
  frontWeight: 0.42,
  cogHeight: 0.44,
  wheelbase: 2.7,
  trackFront: 1.67,
  trackRear: 1.62,
  width: 1.98,
  height: 1.15,
  overhangFront: 1.05,
  overhangRear: 0.85,
  groundClearance: 0.1,
  wheelRadius: 0.35,
  wheelInertia: 2,
  linkCentreHeight: 0.18,
  maxSteer: 0.48,
  finalDrive: 3.2,
  gearRatios: [-3, 0, 3.4, 2.4, 1.85, 1.5, 1.25, 1.07, 0.995],
  idleRPM: 1e3,
  shiftRPM: 7900,
  downshiftRPM: 3800,
  limiterRPM: 8200,
  torqueCurve: [
    [2e3, 480],
    [3500, 720],
    [5500, 770],
    [6500, 760],
    [7500, 675],
    [8200, 560]
  ],
  engine: combustion(4, 1100, 0.24),
  brakeTorque: 11e3,
  aero: { clA: 0.55, cdA: 0.72, balance: 0.42 },
  tireFamily: "road",
  tireGrip: 0.77,
  rearGrip: 1.15,
  drivetrain: "rwd",
  driveline: { rear: lsd(80, 0.4, 0.25) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 95e3, rearSpring: 105e3, frontARB: 22e3, rearARB: 17e3 },
  ai: {
    lateralBase: 10.94,
    lateralAero: 86e-5,
    brakingBase: 13.12,
    brakingAero: 64e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 92,
    lineScale: 0.8
  },
  bands: {
    accel0to100: [2.6, 3.8],
    topSpeed: [315, 350],
    braking100Distance: [28, 40],
    lateral80G: [1.05, 1.4]
  }
});

// actual-source:src/simulation/vehicle-catalogue/gt.ts
var GT_LIMITS = {
  frontSpring: [9e4, 165e3],
  rearSpring: [9e4, 175e3],
  frontRide: [0.055, 0.1],
  rearRide: [0.06, 0.11]
};
var GT_BANDS = {
  accel0to100: [3, 4.2],
  topSpeed: [265, 300],
  braking100Distance: [24, 36],
  lateral80G: [1.3, 1.75]
};
var GT_FRONT_V8 = defineVehicle({
  id: "gt8f",
  name: "GT-8F FRONT-ENGINE GT",
  classId: "gt",
  brief: "Front-mid-engined GT: 6.3 L naturally aspirated V8 with a rear transaxle, 405 kW, 1310 kg, slicks, fixed rear wing and splitter, ABS/TC available. Intended skill: novice\u2013intermediate. Strengths: stable under braking, torque out of slow corners. Weaknesses: turn-in understeer, heavy nose over kerbs.",
  mass: 1310,
  frontWeight: 0.49,
  cogHeight: 0.46,
  wheelbase: 2.7,
  trackFront: 1.68,
  trackRear: 1.66,
  width: 2.04,
  height: 1.2,
  overhangFront: 1.1,
  overhangRear: 0.85,
  groundClearance: 0.07,
  wheelRadius: 0.345,
  wheelInertia: 2,
  linkCentreHeight: 0.24,
  maxSteer: 0.42,
  finalDrive: 3.2,
  gearRatios: [-2.9, 0, 3, 2.2, 1.75, 1.45, 1.24, 1.085],
  idleRPM: 1200,
  shiftRPM: 7300,
  downshiftRPM: 4200,
  limiterRPM: 7600,
  torqueCurve: [
    [2e3, 430],
    [3500, 580],
    [5e3, 640],
    [6e3, 630],
    [7e3, 552],
    [7600, 470]
  ],
  engine: combustion(6.3, 950, 0.3),
  brakeTorque: 9500,
  aero: { clA: 2.3, cdA: 0.88, balance: 0.42 },
  tireFamily: "slick",
  tireGrip: 0.86,
  rearGrip: 1.08,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.45, 0.3) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  elementMass: [4, 5],
  ai: {
    lateralBase: 12.54,
    lateralAero: 159e-5,
    brakingBase: 14.4,
    brakingAero: 201e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.65,
    brakingMargin: 0.74,
    topSpeed: 77
  },
  bands: GT_BANDS
});
var GT_MID_V10 = defineVehicle({
  id: "gt10m",
  name: "GT-10M MID-ENGINE GT",
  classId: "gt",
  brief: "Mid-engined GT: 5.2 L naturally aspirated V10 behind the driver, 430 kW, 1290 kg, 42/58 weight split. Intended skill: intermediate. Strengths: rotation, traction, high-revving power. Weaknesses: lift-off oversteer, rear tyre wear.",
  mass: 1290,
  frontWeight: 0.42,
  cogHeight: 0.45,
  wheelbase: 2.65,
  trackFront: 1.68,
  trackRear: 1.66,
  width: 2.04,
  height: 1.18,
  overhangFront: 1.05,
  overhangRear: 0.85,
  groundClearance: 0.07,
  wheelRadius: 0.345,
  wheelInertia: 2,
  linkCentreHeight: 0.23,
  maxSteer: 0.42,
  finalDrive: 3.5,
  gearRatios: [-2.9, 0, 3.1, 2.3, 1.85, 1.53, 1.31, 1.134],
  idleRPM: 1300,
  shiftRPM: 8400,
  downshiftRPM: 4800,
  limiterRPM: 8700,
  torqueCurve: [
    [2500, 380],
    [4500, 500],
    [6500, 565],
    [7500, 550],
    [8e3, 513],
    [8700, 440]
  ],
  engine: combustion(5.2, 850, 0.26),
  brakeTorque: 9500,
  aero: { clA: 2.4, cdA: 0.9, balance: 0.4 },
  tireFamily: "slick",
  tireGrip: 0.86,
  rearGrip: 1.1,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.45, 0.3) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  elementMass: [4, 5],
  ai: {
    lateralBase: 12.17,
    lateralAero: 197e-5,
    brakingBase: 15.01,
    brakingAero: 172e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.65,
    brakingMargin: 0.74,
    topSpeed: 78
  },
  bands: GT_BANDS
});
var GT_SPORT = defineVehicle({
  id: "gs4",
  name: "GS-4 GT SPORT",
  classId: "gt-sport",
  brief: "Entry GT: turbocharged 3.0 L straight-six, 330 kW, 1460 kg, modest aero, harder slicks. Intended skill: novice. Strengths: torque, stability, low running cost. Weaknesses: weight transfer, brake fade over long stints, low top speed.",
  mass: 1460,
  frontWeight: 0.48,
  cogHeight: 0.48,
  wheelbase: 2.6,
  trackFront: 1.62,
  trackRear: 1.6,
  width: 1.95,
  height: 1.25,
  overhangFront: 1,
  overhangRear: 0.85,
  groundClearance: 0.09,
  wheelRadius: 0.33,
  wheelInertia: 1.8,
  linkCentreHeight: 0.25,
  maxSteer: 0.44,
  finalDrive: 3.2,
  gearRatios: [-3, 0, 3.2, 2.35, 1.82, 1.48, 1.22, 1],
  idleRPM: 1e3,
  shiftRPM: 6500,
  downshiftRPM: 3600,
  limiterRPM: 6800,
  torqueCurve: [
    [1500, 420],
    [2500, 600],
    [5e3, 600],
    [6e3, 525],
    [6800, 430]
  ],
  engine: combustion(3, 850, 0.26),
  brakeTorque: 8e3,
  aero: { clA: 0.9, cdA: 0.82, balance: 0.45 },
  tireFamily: "slick",
  tireGrip: 0.79,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(50, 0.35, 0.2) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  ai: {
    lateralBase: 11.55,
    lateralAero: 109e-5,
    brakingBase: 12.87,
    brakingAero: 111e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 72,
    lineScale: 0.8
  },
  bands: {
    accel0to100: [3.6, 5],
    topSpeed: [245, 280],
    braking100Distance: [28, 40],
    lateral80G: [1.15, 1.5]
  }
});

// actual-source:src/simulation/vehicle-catalogue/formula.ts
var JUNIOR_FORMULA = defineVehicle({
  id: "jf2",
  name: "JF-2 JUNIOR FORMULA",
  classId: "formula-junior",
  brief: "Feeder single-seater: 3.4 L turbo V6, 456 kW, 790 kg with driver, two-thirds of the APX-01 downforce, no hybrid, DRS. Intended skill: intermediate. Strengths: stable braking, forgiving rear. Weaknesses: tyre overheating, less high-speed grip than APX-01.",
  mass: 790,
  frontWeight: 0.45,
  cogHeight: 0.46,
  wheelbase: 3.135,
  trackFront: 1.5,
  trackRear: 1.46,
  width: 1.9,
  height: 0.98,
  overhangFront: 1.08,
  overhangRear: 0.78,
  groundClearance: 0.045,
  wheelRadius: 0.33,
  wheelInertia: 1.6,
  linkCentreHeight: 0.22,
  maxSteer: 0.38,
  finalDrive: 3,
  gearRatios: [-3, 0, 3.05, 2.35, 1.9, 1.6, 1.38, 1.21],
  idleRPM: 3e3,
  shiftRPM: 9200,
  downshiftRPM: 5800,
  limiterRPM: 9600,
  torqueCurve: [
    [3500, 330],
    [5e3, 450],
    [6500, 540],
    [8e3, 520],
    [8750, 498],
    [9600, 420]
  ],
  engine: combustion(3.4, 900, 0.22),
  brakeTorque: 11e3,
  aero: { clA: 4.4, cdA: 1.05, balance: 0.42 },
  tireFamily: "formula-slick",
  tireGrip: 0.95,
  rearGrip: 1.04,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.35, 0.25) },
  drs: true,
  setupKeys: KEYS.winged,
  ai: {
    lateralBase: 14.49,
    lateralAero: 437e-5,
    brakingBase: 16.81,
    brakingAero: 521e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.62,
    brakingMargin: 0.74,
    topSpeed: 86
  },
  bands: {
    accel0to100: [2.6, 3.5],
    topSpeed: [295, 340],
    braking100Distance: [18, 34],
    lateral80G: [1.6, 2.4]
  }
});
var HISTORIC_FORMULA = defineVehicle({
  id: "hf67",
  name: "HF-67 HISTORIC FORMULA",
  classId: "historic",
  brief: "A 1967-style cigar-tube single-seater: 3.0 L V8, 306 kW, 595 kg with driver, narrow cross-ply tyres, no wings and no downforce. Intended skill: intermediate\u2013expert. Strengths: light, agile, high power-to-weight. Weaknesses: wheelspin, long braking, snap oversteer at the limit; slipstream matters.",
  mass: 595,
  frontWeight: 0.4,
  cogHeight: 0.4,
  wheelbase: 2.4,
  trackFront: 1.4,
  trackRear: 1.42,
  width: 1.6,
  height: 0.86,
  overhangFront: 0.8,
  overhangRear: 0.55,
  groundClearance: 0.1,
  wheelRadius: 0.3,
  wheelInertia: 1,
  linkCentreHeight: 0.2,
  maxSteer: 0.4,
  finalDrive: 3.72,
  gearRatios: [-2.9, 0, 2.6, 1.85, 1.45, 1.2, 1.03],
  idleRPM: 2e3,
  shiftRPM: 9300,
  downshiftRPM: 5500,
  limiterRPM: 9800,
  torqueCurve: [
    [3e3, 200],
    [5e3, 280],
    [7e3, 330],
    [8500, 330],
    [9e3, 325],
    [9800, 270]
  ],
  engine: combustion(3, 700, 0.2),
  brakeTorque: 3800,
  aero: { clA: 0, cdA: 0.7, balance: 0.5 },
  tireFamily: "historic",
  tireGrip: 0.6,
  rearGrip: 1.1,
  drivetrain: "rwd",
  driveline: { rear: lsd(30, 0.25, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 7e4, rearSpring: 8e4, frontARB: 9e3, rearARB: 6e3 },
  setupLimits: { frontARB: [0, 25e3], rearARB: [0, 25e3] },
  elementMass: [2, 2],
  ai: {
    lateralBase: 9.58,
    lateralAero: 0,
    brakingBase: 11.13,
    brakingAero: 0,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 76
  },
  bands: {
    accel0to100: [3.4, 5.2],
    topSpeed: [265, 315],
    braking100Distance: [32, 52],
    lateral80G: [0.95, 1.35]
  }
});

// actual-source:src/simulation/vehicle-catalogue/endurance.ts
var HYPERCAR = defineVehicle({
  id: "hy9",
  name: "HY-9 HYPERCAR",
  classId: "hypercar",
  brief: "Top-class endurance prototype: twin-turbo V6 (460 kW) driving the rear axle plus a 150 kW front-axle motor that may deploy only above 190 km/h, 1030 kg, efficient low-drag aero (L/D \u2248 4). Intended skill: intermediate\u2013expert. Strengths: traction out of fast corners, braking stability, energy recovery. Weaknesses: weight, rear-drive launch, energy management over a stint.",
  mass: 1030,
  frontWeight: 0.47,
  cogHeight: 0.42,
  wheelbase: 3.1,
  trackFront: 1.7,
  trackRear: 1.66,
  width: 2,
  height: 1.15,
  overhangFront: 1.15,
  overhangRear: 0.85,
  groundClearance: 0.055,
  wheelRadius: 0.355,
  wheelInertia: 1.9,
  linkCentreHeight: 0.22,
  maxSteer: 0.36,
  finalDrive: 3,
  gearRatios: [-2.8, 0, 2.9, 2.2, 1.8, 1.53, 1.35, 1.21, 1.1],
  idleRPM: 1800,
  shiftRPM: 7900,
  downshiftRPM: 4300,
  limiterRPM: 8400,
  torqueCurve: [
    [2500, 420],
    [4e3, 640],
    [5500, 690],
    [6500, 660],
    [7500, 586],
    [8400, 470]
  ],
  engine: combustion(3, 1e3, 0.25),
  hybrid: { motorPowerW: 15e4, regenPowerW: 2e5, batteryJ: 28e5, frontAxleAbove: 190 / 3.6 },
  brakeTorque: 13500,
  aero: { clA: 3.6, cdA: 0.92, balance: 0.44 },
  tireFamily: "slick",
  tireGrip: 0.92,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(100, 0.4, 0.25) },
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 13.44,
    lateralAero: 321e-5,
    brakingBase: 15.73,
    brakingAero: 351e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 93
  },
  bands: {
    accel0to100: [2.6, 3.8],
    topSpeed: [315, 355],
    braking100Distance: [20, 36],
    lateral80G: [1.45, 2.2]
  }
});
var PROTOTYPE = defineVehicle({
  id: "pr2",
  name: "PR-2 PROTOTYPE",
  classId: "prototype",
  brief: "Second-tier spec prototype: naturally aspirated 4.2 L V8, 440 kW, 950 kg, high downforce kit, no hybrid. Intended skill: intermediate. Strengths: cornering grip and a predictable rear. Weaknesses: straight-line speed against hypercars, traffic.",
  mass: 950,
  frontWeight: 0.45,
  cogHeight: 0.41,
  wheelbase: 3.01,
  trackFront: 1.6,
  trackRear: 1.56,
  width: 1.9,
  height: 1.05,
  overhangFront: 1.05,
  overhangRear: 0.69,
  groundClearance: 0.055,
  wheelRadius: 0.345,
  wheelInertia: 1.8,
  linkCentreHeight: 0.22,
  maxSteer: 0.36,
  finalDrive: 3.15,
  gearRatios: [-2.9, 0, 2.85, 2.15, 1.75, 1.47, 1.28, 1.125],
  idleRPM: 2200,
  shiftRPM: 8700,
  downshiftRPM: 5200,
  limiterRPM: 9e3,
  torqueCurve: [
    [3e3, 380],
    [5e3, 500],
    [6500, 560],
    [7500, 540],
    [8400, 500],
    [9e3, 440]
  ],
  engine: combustion(4.2, 900, 0.24),
  brakeTorque: 12500,
  aero: { clA: 3.9, cdA: 0.98, balance: 0.43 },
  tireFamily: "slick",
  tireGrip: 0.9,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(90, 0.4, 0.25) },
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 13.28,
    lateralAero: 364e-5,
    brakingBase: 15.55,
    brakingAero: 407e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 87
  },
  bands: {
    accel0to100: [2.7, 3.9],
    topSpeed: [300, 345],
    braking100Distance: [20, 36],
    lateral80G: [1.45, 2.2]
  }
});

// actual-source:src/simulation/vehicle-catalogue/dirt.ts
var RALLY_CAR = defineVehicle({
  id: "rl2",
  name: "RL-2 RALLY",
  classId: "rally",
  brief: "Second-tier rally car: restricted 1.6 L turbo four, 213 kW, 1330 kg with crew, permanent four-wheel drive with no centre differential (fixed 50:50), front and rear clutch-pack differentials, gravel tyres. Intended skill: intermediate. Strengths: traction on any surface, short gearing. Weaknesses: understeer on asphalt, low top speed, high centre of gravity.",
  mass: 1330,
  frontWeight: 0.56,
  cogHeight: 0.52,
  wheelbase: 2.5,
  trackFront: 1.56,
  trackRear: 1.56,
  width: 1.82,
  height: 1.45,
  overhangFront: 0.9,
  overhangRear: 0.7,
  groundClearance: 0.14,
  wheelRadius: 0.32,
  wheelInertia: 1.4,
  restLength: 0.28,
  linkCentreHeight: 0.28,
  maxSteer: 0.5,
  finalDrive: 4,
  gearRatios: [-3, 0, 2.9, 2, 1.55, 1.25, 1.01],
  idleRPM: 1100,
  shiftRPM: 6200,
  downshiftRPM: 3300,
  limiterRPM: 6500,
  torqueCurve: [
    [1500, 250],
    [2500, 400],
    [4e3, 430],
    [5e3, 407],
    [6e3, 330],
    [6500, 280]
  ],
  engine: combustion(1.6, 700, 0.18),
  brakeTorque: 8e3,
  aero: { clA: 0.45, cdA: 0.88, balance: 0.45 },
  tireFamily: "gravel",
  tireGrip: 0.7,
  drivetrain: "awd",
  driveline: {
    centre: { ...LOCKED, frontShare: 0.5 },
    front: lsd(80, 0.4, 0.2),
    rear: lsd(80, 0.5, 0.3)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 9e4, rearSpring: 9e4, frontARB: 18e3, rearARB: 14e3 },
  elementMass: [3, 4],
  ai: {
    lateralBase: 10.24,
    lateralAero: 64e-5,
    brakingBase: 11.36,
    brakingAero: 64e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 53
  },
  bands: {
    accel0to100: [3.5, 5],
    topSpeed: [180, 210],
    braking100Distance: [30, 46],
    lateral80G: [0.95, 1.35]
  }
});
var RALLYCROSS_CAR = defineVehicle({
  id: "rcx6",
  name: "RCX-6 RALLYCROSS",
  classId: "rallycross",
  brief: "Rallycross supercar: 2.0 L turbo four with anti-lag, 440 kW and 880 N m, 1300 kg, four-wheel drive through a limited-slip centre differential. Intended skill: intermediate\u2013expert. Strengths: launches, short sprints, mixed surfaces. Weaknesses: abrupt power, short gearing caps top speed, contact-heavy racing.",
  mass: 1300,
  frontWeight: 0.55,
  cogHeight: 0.5,
  wheelbase: 2.55,
  trackFront: 1.6,
  trackRear: 1.6,
  width: 1.92,
  height: 1.4,
  overhangFront: 0.95,
  overhangRear: 0.75,
  groundClearance: 0.12,
  wheelRadius: 0.325,
  wheelInertia: 1.45,
  restLength: 0.27,
  linkCentreHeight: 0.27,
  maxSteer: 0.5,
  finalDrive: 3.68,
  gearRatios: [-3, 0, 3, 2.15, 1.65, 1.35, 1.15, 1],
  idleRPM: 1500,
  shiftRPM: 6900,
  downshiftRPM: 3600,
  limiterRPM: 7200,
  torqueCurve: [
    [2e3, 500],
    [3500, 800],
    [4500, 880],
    [5500, 820],
    [6500, 646],
    [7200, 520]
  ],
  engine: combustion(2, 1150, 0.2),
  brakeTorque: 9e3,
  aero: { clA: 0.8, cdA: 0.95, balance: 0.42 },
  tireFamily: "gravel",
  tireGrip: 0.72,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(150, 0.5, 0.2), frontShare: 0.45 },
    front: lsd(100, 0.45, 0.2),
    rear: lsd(100, 0.55, 0.3)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 95e3, rearSpring: 95e3, frontARB: 2e4, rearARB: 16e3 },
  elementMass: [3, 5],
  ai: {
    lateralBase: 10.46,
    lateralAero: 85e-5,
    brakingBase: 11.68,
    brakingAero: 87e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 66
  },
  bands: {
    accel0to100: [2, 3],
    topSpeed: [220, 255],
    braking100Distance: [28, 44],
    lateral80G: [1, 1.4]
  }
});
var TROPHY_TRUCK = defineVehicle({
  id: "dx8",
  name: "DX-8 TROPHY TRUCK",
  classId: "offroad",
  brief: "Desert trophy truck: 7.4 L V8, 630 kW, 2720 kg, rear drive through a high-preload differential, three-speed gearbox, 37-inch all-terrain tyres. Intended skill: intermediate. Strengths: power, durability, loose surfaces. Weaknesses: mass, high centre of gravity, long braking, body roll; suspension travel is limited by the current solver (see CONTENT_PIPELINE.md \xA71.3).",
  mass: 2720,
  frontWeight: 0.5,
  cogHeight: 0.85,
  wheelbase: 3.45,
  trackFront: 2.1,
  trackRear: 2.08,
  width: 2.3,
  height: 2,
  overhangFront: 1.1,
  overhangRear: 1.2,
  groundClearance: 0.4,
  wheelRadius: 0.47,
  wheelInertia: 6,
  restLength: 0.45,
  linkCentreHeight: 0.45,
  maxSteer: 0.5,
  finalDrive: 4.8,
  gearRatios: [-2.9, 0, 2.5, 1.6, 1.2],
  idleRPM: 900,
  shiftRPM: 6700,
  downshiftRPM: 3200,
  limiterRPM: 7e3,
  torqueCurve: [
    [2e3, 700],
    [3500, 920],
    [5e3, 1020],
    [6e3, 990],
    [6500, 925],
    [7e3, 800]
  ],
  engine: combustion(7.4, 1500, 0.45),
  brakeTorque: 16e3,
  aero: { clA: 0, cdA: 1.8, balance: 0.5 },
  tireFamily: "all-terrain",
  tireGrip: 0.64,
  drivetrain: "rwd",
  driveline: { rear: lsd(250, 0.6, 0.3) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 12e4, rearSpring: 13e4, frontARB: 14e3, rearARB: 9e3 },
  elementMass: [8, 8],
  ai: {
    lateralBase: 9.18,
    lateralAero: 0,
    brakingBase: 9.55,
    brakingAero: 0,
    lateralMargin: 0.72,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 58
  },
  bands: {
    accel0to100: [4.2, 6.5],
    topSpeed: [195, 230],
    braking100Distance: [38, 62],
    lateral80G: [0.7, 1.05]
  }
});

// actual-source:src/simulation/vehicle-catalogue/single-seaters.ts
var FORMULA_FX26 = defineVehicle({
  id: "fx26",
  name: "FX-26 FORMULA",
  classId: "formula",
  brief: "Top-tier single-seater to an electrified rule set, distinct from APX-01: a 1.6 L turbo V6 limited to about 400 kW plus a 350 kW crankshaft motor (4 MJ store), 768 kg with driver, a smaller, narrower car with about a quarter less downforce and less drag than APX-01, DRS (active rear-wing opening). Intended skill: expert. Strengths: deployment out of slow corners, top speed while the store lasts, braking. Weaknesses: energy clipping on long straights, less high-speed grip than APX-01, wake sensitivity. Targets: 0\u2013100 about 2.6 s, peak 335\u2013360 km/h with full deployment, 100\u20130 under 30 m, about 2 g at 80 km/h.",
  mass: 768,
  frontWeight: 0.45,
  cogHeight: 0.44,
  wheelbase: 3.4,
  trackFront: 1.6,
  trackRear: 1.56,
  width: 1.9,
  height: 0.97,
  overhangFront: 1.08,
  overhangRear: 0.74,
  groundClearance: 0.04,
  wheelRadius: 0.36,
  wheelInertia: 1.8,
  linkCentreHeight: 0.22,
  maxSteer: 0.38,
  finalDrive: 3.3,
  gearRatios: [-3, 0, 3.3, 2.75, 2.33, 2.02, 1.79, 1.61, 1.47, 1.36],
  idleRPM: 4e3,
  shiftRPM: 12200,
  downshiftRPM: 7600,
  limiterRPM: 13e3,
  torqueCurve: [
    [5e3, 300],
    [7e3, 340],
    [9e3, 360],
    [10500, 364],
    [11500, 340],
    [12500, 300],
    [13e3, 272]
  ],
  engine: combustion(1.6, 760, 0.2),
  // A 5 MJ store starts a session at 80%: the 4 MJ the brief names.
  hybrid: { motorPowerW: 35e4, regenPowerW: 35e4, batteryJ: 5e6 },
  brakeTorque: 13e3,
  aero: { clA: 6.4, cdA: 1.02, balance: 0.44 },
  tireFamily: "formula-slick",
  tireGrip: 1,
  rearGrip: 1.05,
  drivetrain: "rwd",
  driveline: { rear: lsd(80, 0.4, 0.25) },
  drs: true,
  setupKeys: KEYS.winged,
  elementMass: [4.5, 6],
  ai: {
    lateralBase: 15,
    lateralAero: 626e-5,
    brakingBase: 18.09,
    brakingAero: 69e-4,
    lateralMargin: 0.72,
    slowLateralMargin: 0.62,
    brakingMargin: 0.72,
    topSpeed: 95
  },
  bands: {
    accel0to100: [2.2, 3.1],
    topSpeed: [325, 365],
    braking100Distance: [15, 30],
    lateral80G: [1.75, 2.6]
  }
});
var FEEDER_FR3 = defineVehicle({
  id: "fr3",
  name: "FR-3 FEEDER FORMULA",
  classId: "formula-feeder",
  brief: "Third-rung spec single-seater: naturally aspirated 3.4 L V6, about 280 kW, 675 kg with driver, simple two-element wings and a flat floor, DRS, steel-carbon brakes. Intended skill: novice\u2013intermediate on the Formula ladder. Strengths: honest balance, tow-heavy pack racing. Weaknesses: modest power, front-wing wake loss in traffic. Targets: 0\u2013100 about 3.2 s, 265\u2013285 km/h, about 1.7 g at 80 km/h.",
  mass: 675,
  frontWeight: 0.44,
  cogHeight: 0.42,
  wheelbase: 2.95,
  trackFront: 1.55,
  trackRear: 1.5,
  width: 1.85,
  height: 0.95,
  overhangFront: 0.95,
  overhangRear: 0.65,
  groundClearance: 0.045,
  wheelRadius: 0.32,
  wheelInertia: 1.4,
  linkCentreHeight: 0.21,
  maxSteer: 0.38,
  finalDrive: 3.4,
  gearRatios: [-2.9, 0, 2.9, 2.2, 1.8, 1.52, 1.29, 1.1],
  idleRPM: 2500,
  shiftRPM: 8200,
  downshiftRPM: 5200,
  limiterRPM: 8500,
  torqueCurve: [
    [2e3, 150],
    [3500, 290],
    [5e3, 370],
    [6e3, 400],
    [7e3, 375],
    [8e3, 330],
    [8500, 290]
  ],
  engine: combustion(3.4, 650, 0.18),
  brakeTorque: 7e3,
  aero: { clA: 3, cdA: 0.95, balance: 0.42 },
  tireFamily: "formula-slick",
  tireGrip: 0.92,
  rearGrip: 1.04,
  drivetrain: "rwd",
  driveline: { rear: lsd(50, 0.35, 0.2) },
  drs: true,
  setupKeys: KEYS.winged,
  elementMass: [3, 4],
  ai: {
    lateralBase: 14.06,
    lateralAero: 385e-5,
    brakingBase: 16.32,
    brakingAero: 452e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.63,
    brakingMargin: 0.74,
    topSpeed: 74
  },
  bands: {
    accel0to100: [2.8, 3.8],
    topSpeed: [255, 295],
    braking100Distance: [18, 34],
    lateral80G: [1.5, 2.2]
  }
});
var ENTRY_FE4 = defineVehicle({
  id: "fe4",
  name: "FE-4 ENTRY FORMULA",
  classId: "formula-entry",
  brief: "First single-seater rung: 1.4 L turbo four, 120 kW, 570 kg with driver, halo, small single-element wings, steel brakes, no DRS. Intended skill: novice. Strengths: low inertia and a forgiving limit that teaches braking points. Weaknesses: little power to correct mistakes, slipstream decides races. Targets: 0\u2013100 about 4 s, 210\u2013230 km/h, about 1.5 g at 80 km/h.",
  mass: 570,
  frontWeight: 0.42,
  cogHeight: 0.4,
  wheelbase: 2.75,
  trackFront: 1.5,
  trackRear: 1.45,
  width: 1.75,
  height: 0.95,
  overhangFront: 0.85,
  overhangRear: 0.55,
  groundClearance: 0.05,
  wheelRadius: 0.3,
  wheelInertia: 1.1,
  linkCentreHeight: 0.2,
  maxSteer: 0.4,
  finalDrive: 3.6,
  gearRatios: [-2.9, 0, 2.9, 2.1, 1.65, 1.36, 1.16, 1],
  idleRPM: 1500,
  shiftRPM: 6500,
  downshiftRPM: 3800,
  limiterRPM: 6750,
  torqueCurve: [
    [2e3, 160],
    [3e3, 230],
    [4500, 240],
    [6e3, 200],
    [6500, 180],
    [6750, 165]
  ],
  engine: combustion(1.4, 400, 0.12),
  brakeTorque: 3400,
  aero: { clA: 1.5, cdA: 0.8, balance: 0.42 },
  tireFamily: "formula-slick",
  tireGrip: 0.9,
  rearGrip: 1.03,
  drivetrain: "rwd",
  driveline: { rear: lsd(30, 0.3, 0.15) },
  setupKeys: KEYS.winged,
  elementMass: [2.5, 3],
  ai: {
    lateralBase: 14.06,
    lateralAero: 277e-5,
    brakingBase: 17.27,
    brakingAero: 98e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 58
  },
  bands: {
    accel0to100: [3.4, 4.8],
    topSpeed: [200, 235],
    braking100Distance: [22, 36],
    lateral80G: [1.35, 1.9]
  }
});
var HISTORIC_HF76 = defineVehicle({
  id: "hf76",
  name: "HF-76 HISTORIC FORMULA",
  classId: "historic-aero",
  brief: "A 1976-style winged single-seater: 3.0 L V8, about 360 kW at 10 500 rpm, 650 kg with driver, tall airbox, wedge nose with front wings, a big rear wing on a central pylon, wide bias-ply slicks, steel brakes, five-speed. Intended skill: intermediate\u2013expert. Strengths: power and mechanical grip from the wide rears. Weaknesses: draggy, steel brakes fade and lock, slides at the limit. Targets: 0\u2013100 about 3.4 s, about 285 km/h, about 1.5 g at 80 km/h.",
  mass: 650,
  frontWeight: 0.38,
  cogHeight: 0.42,
  wheelbase: 2.6,
  trackFront: 1.45,
  trackRear: 1.55,
  width: 2,
  height: 1.2,
  overhangFront: 0.9,
  overhangRear: 0.75,
  groundClearance: 0.06,
  wheelRadius: 0.33,
  wheelInertia: 1.4,
  linkCentreHeight: 0.21,
  maxSteer: 0.4,
  finalDrive: 4.4,
  gearRatios: [-2.9, 0, 2.25, 1.75, 1.42, 1.2, 1.05],
  idleRPM: 3e3,
  shiftRPM: 10700,
  downshiftRPM: 7200,
  limiterRPM: 11e3,
  torqueCurve: [
    [5e3, 230],
    [7e3, 300],
    [8500, 330],
    [9500, 335],
    [10500, 325],
    [11e3, 300]
  ],
  engine: combustion(3, 700, 0.17),
  brakeTorque: 6e3,
  aero: { clA: 2.6, cdA: 1.05, balance: 0.4 },
  tireFamily: "historic-slick",
  tireGrip: 0.76,
  rearGrip: 1.12,
  drivetrain: "rwd",
  driveline: { rear: lsd(30, 0.25, 0.15) },
  setupKeys: KEYS.winged,
  setupLimits: { frontRide: [0.05, 0.1], rearRide: [0.055, 0.11] },
  setupDefaults: { frontRide: 0.07, rearRide: 0.08 },
  elementMass: [3, 5],
  ai: {
    lateralBase: 11.5,
    lateralAero: 34e-4,
    brakingBase: 14.53,
    brakingAero: 364e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.65,
    brakingMargin: 0.74,
    topSpeed: 79
  },
  bands: {
    accel0to100: [2.9, 4.2],
    topSpeed: [265, 310],
    braking100Distance: [24, 40],
    lateral80G: [1.25, 1.8]
  }
});
var HISTORIC_HF86 = defineVehicle({
  id: "hf86",
  name: "HF-86 TURBO FORMULA",
  classId: "historic-turbo",
  brief: "A 1986-style turbo-era single-seater: 1.5 L turbo V6 in race trim, about 600 kW with a boost-driven torque curve that arrives late, 620 kg with driver, flat bottom, small front wings and a large multi-element rear wing, radial slicks, carbon brakes, six-speed manual. Intended skill: expert. Strengths: enormous straight-line speed. Weaknesses: turbo lag and wheelspin out of slow corners, rear-heavy aero balance, snap oversteer. Targets: 0\u2013100 about 3 s (traction-limited), 315\u2013340 km/h, about 1.6 g at 80 km/h.",
  mass: 620,
  frontWeight: 0.4,
  cogHeight: 0.4,
  wheelbase: 2.8,
  trackFront: 1.8,
  trackRear: 1.65,
  width: 2.1,
  height: 1,
  overhangFront: 1,
  overhangRear: 0.65,
  groundClearance: 0.05,
  wheelRadius: 0.33,
  wheelInertia: 1.4,
  linkCentreHeight: 0.21,
  maxSteer: 0.4,
  finalDrive: 3.8,
  gearRatios: [-2.9, 0, 2.85, 2.1, 1.7, 1.45, 1.28, 1.17],
  idleRPM: 3500,
  shiftRPM: 11600,
  // The 1->2 step is 1.357, so a shift at 11 600 rpm lands at 8 550 rpm, and the launch wheelspin
  // that triggers it collapses once the torque is cut: road-coupled RPM in 2nd falls to about
  // 7 900. A downshift point of 8 000 sent the box back to 1st at once and it hunted at 124 km/h
  // for ever; 7 200 keeps the same 1.19 margin the other single-seaters have.
  downshiftRPM: 7200,
  limiterRPM: 12e3,
  torqueCurve: [
    [4e3, 180],
    [6e3, 330],
    [8e3, 500],
    [9500, 540],
    [10500, 530],
    [11500, 480],
    [12e3, 420]
  ],
  engine: combustion(1.5, 900, 0.12),
  // Boost arrives late: lift and it dumps, open up and it takes most of a
  // second to build again. The spool threshold sits below the working range,
  // so the steady full-load curve is unchanged; the lag is the transient.
  turbo: { boostShare: 0.55, spoolTime: 0.8, dumpFraction: 0.35, spoolRPM: [1e3, 2e3] },
  brakeTorque: 8500,
  aero: { clA: 3.2, cdA: 1.15, balance: 0.38 },
  tireFamily: "historic-slick",
  tireGrip: 0.86,
  rearGrip: 1.15,
  drivetrain: "rwd",
  driveline: { rear: lsd(50, 0.35, 0.2) },
  setupKeys: KEYS.winged,
  elementMass: [3, 6],
  ai: {
    lateralBase: 12.58,
    lateralAero: 439e-5,
    brakingBase: 16.16,
    brakingAero: 566e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.63,
    brakingMargin: 0.74,
    topSpeed: 89
  },
  bands: {
    accel0to100: [2.5, 3.6],
    topSpeed: [305, 345],
    braking100Distance: [20, 36],
    lateral80G: [1.4, 2]
  }
});

// actual-source:src/simulation/vehicle-catalogue/prototypes.ts
var HYPERCAR_HY11 = defineVehicle({
  id: "hy11",
  name: "HY-11 HYPERCAR",
  classId: "hypercar",
  brief: "Top-class endurance prototype built around a spec hybrid, unlike the front-axle HY-9: a 4.0 L twin-turbo V8 (about 470 kW) driving the rear wheels with a 50 kW crankshaft motor-generator, 1030 kg, more downforce and drag than HY-9 (L/D about 3.9). Intended skill: intermediate\u2013expert. Strengths: cornering grip, torque, braking stability. Weaknesses: rear-drive traction from slow corners, less straight-line speed than HY-9, small energy store. Targets: 0\u2013100 about 3.1 s, 315\u2013340 km/h, about 1.6 g at 80 km/h.",
  mass: 1030,
  frontWeight: 0.47,
  cogHeight: 0.43,
  wheelbase: 3.15,
  trackFront: 1.7,
  trackRear: 1.66,
  width: 2,
  height: 1.06,
  overhangFront: 1.12,
  overhangRear: 0.88,
  groundClearance: 0.055,
  wheelRadius: 0.355,
  wheelInertia: 1.9,
  linkCentreHeight: 0.22,
  maxSteer: 0.36,
  finalDrive: 3,
  gearRatios: [-2.8, 0, 2.95, 2.25, 1.82, 1.53, 1.33, 1.18, 1.07],
  idleRPM: 1600,
  shiftRPM: 7600,
  downshiftRPM: 4200,
  limiterRPM: 8e3,
  torqueCurve: [
    [2500, 520],
    [4e3, 720],
    [5500, 740],
    [6500, 690],
    [7500, 590],
    [8e3, 520]
  ],
  engine: combustion(4, 1100, 0.26),
  hybrid: { motorPowerW: 5e4, regenPowerW: 15e4, batteryJ: 15e5 },
  brakeTorque: 13500,
  aero: { clA: 3.9, cdA: 1, balance: 0.45 },
  tireFamily: "slick",
  tireGrip: 0.92,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(100, 0.4, 0.25) },
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 13.33,
    lateralAero: 325e-5,
    brakingBase: 15.74,
    brakingAero: 362e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 88
  },
  bands: {
    accel0to100: [2.7, 3.8],
    topSpeed: [310, 345],
    braking100Distance: [20, 36],
    lateral80G: [1.45, 2.2]
  }
});
var PROTOTYPE_PR3 = defineVehicle({
  id: "pr3",
  name: "PR-3 OPEN PROTOTYPE",
  classId: "prototype",
  brief: "Open-cockpit second-tier prototype (a barchetta, against the closed PR-2): 3.5 L twin-turbo V6, about 400 kW, 930 kg, high-downforce kit with a short tail. Intended skill: intermediate. Strengths: turbo torque, low-speed downforce, light weight. Weaknesses: draggy at speed, turbo response at corner exit, an open cockpit gives the driver no shelter in rain. Targets: 0\u2013100 about 3.2 s, about 300 km/h, about 1.6 g at 80 km/h.",
  mass: 930,
  frontWeight: 0.44,
  cogHeight: 0.4,
  wheelbase: 2.95,
  trackFront: 1.62,
  trackRear: 1.58,
  width: 1.95,
  height: 0.98,
  overhangFront: 1,
  overhangRear: 0.72,
  groundClearance: 0.055,
  wheelRadius: 0.34,
  wheelInertia: 1.75,
  linkCentreHeight: 0.22,
  maxSteer: 0.36,
  finalDrive: 3.1,
  gearRatios: [-2.9, 0, 2.45, 2, 1.68, 1.44, 1.24, 1.06],
  idleRPM: 1800,
  shiftRPM: 7700,
  downshiftRPM: 4400,
  limiterRPM: 8e3,
  torqueCurve: [
    [2500, 420],
    [4e3, 580],
    [5500, 620],
    [6500, 590],
    [7500, 510],
    [8e3, 450]
  ],
  engine: combustion(3.5, 950, 0.22),
  turbo: { boostShare: 0.4, spoolTime: 0.3, dumpFraction: 0.3, spoolRPM: [1e3, 2e3] },
  brakeTorque: 12e3,
  aero: { clA: 4.2, cdA: 1.05, balance: 0.42 },
  tireFamily: "slick",
  tireGrip: 0.9,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(90, 0.4, 0.25) },
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 13.08,
    lateralAero: 378e-5,
    brakingBase: 15.56,
    brakingAero: 439e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 82
  },
  bands: {
    accel0to100: [2.8, 4],
    topSpeed: [280, 320],
    braking100Distance: [20, 36],
    lateral80G: [1.45, 2.2]
  }
});
var HISTORIC_SP71 = defineVehicle({
  id: "sp71",
  name: "SP-71 LONG-TAIL PROTOTYPE",
  classId: "historic-prototype",
  brief: "A 1971-style long-tail sports prototype: air-cooled 4.9 L flat-12 behind the driver, about 440 kW, 860 kg with driver, a spaceframe under a low-drag long tail with almost no downforce, bias-ply slicks, steel brakes, five-speed. Intended skill: expert. Strengths: very high top speed, a tractable flat-12. Weaknesses: light and nervous at speed, long braking zones, rear weight bias (38/62) snaps on lift-off. Targets: 0\u2013100 about 3.8 s, 330\u2013360 km/h, about 1.2 g at 80 km/h.",
  mass: 860,
  frontWeight: 0.38,
  cogHeight: 0.42,
  wheelbase: 2.3,
  trackFront: 1.56,
  trackRear: 1.54,
  width: 2.03,
  height: 0.94,
  overhangFront: 1,
  overhangRear: 1.4,
  groundClearance: 0.08,
  wheelRadius: 0.33,
  wheelInertia: 1.5,
  linkCentreHeight: 0.21,
  maxSteer: 0.4,
  finalDrive: 3.2,
  gearRatios: [-2.8, 0, 2.1, 1.6, 1.28, 1.08, 0.96],
  idleRPM: 1500,
  shiftRPM: 8300,
  downshiftRPM: 4500,
  limiterRPM: 8600,
  torqueCurve: [
    [3e3, 350],
    [5e3, 480],
    [6500, 540],
    [7500, 530],
    [8300, 500],
    [8600, 460]
  ],
  engine: combustion(4.9, 900, 0.2),
  brakeTorque: 7e3,
  aero: { clA: 0.25, cdA: 0.68, balance: 0.35 },
  tireFamily: "historic-slick",
  tireGrip: 0.69,
  rearGrip: 1.25,
  drivetrain: "rwd",
  driveline: { rear: lsd(20, 0.2, 0.1) },
  setupKeys: KEYS.closed,
  setupDefaults: { frontSpring: 9e4, rearSpring: 1e5, frontARB: 12e3, rearARB: 8e3 },
  elementMass: [3, 4],
  ai: {
    lateralBase: 10.33,
    lateralAero: 74e-5,
    brakingBase: 13.04,
    brakingAero: 74e-5,
    lateralMargin: 0.66,
    slowLateralMargin: 0.6,
    brakingMargin: 0.66,
    topSpeed: 93,
    lineScale: 0.75
  },
  bands: {
    accel0to100: [3, 4.6],
    topSpeed: [320, 365],
    braking100Distance: [28, 44],
    lateral80G: [1.05, 1.45]
  }
});

// actual-source:src/simulation/vehicle-catalogue/gt-layouts.ts
var GT_REAR_FLAT6 = defineVehicle({
  id: "gt6r",
  name: "GT-6R REAR-ENGINE GT",
  classId: "gt",
  brief: "Rear-engined GT: 4.2 L naturally aspirated flat-six behind the rear axle, about 380 kW at 8750 rpm, 1270 kg, 39/61 weight split on staggered slicks, swan-neck wing. Intended skill: intermediate\u2013expert. Strengths: traction and braking (the weight sits over the rears), a high-revving engine. Weaknesses: a light nose that understeers on entry and a pendulum on lift-off; rear tyre wear. Targets: 0\u2013100 about 3.4 s, 280\u2013290 km/h, about 1.35 g at 80 km/h.",
  mass: 1270,
  frontWeight: 0.39,
  cogHeight: 0.44,
  wheelbase: 2.46,
  trackFront: 1.62,
  trackRear: 1.6,
  width: 2,
  height: 1.25,
  overhangFront: 1.05,
  overhangRear: 1,
  groundClearance: 0.07,
  wheelRadius: 0.345,
  wheelInertia: 2,
  linkCentreHeight: 0.23,
  maxSteer: 0.42,
  finalDrive: 3.4,
  gearRatios: [-2.9, 0, 3.1, 2.3, 1.85, 1.55, 1.35, 1.2],
  idleRPM: 1300,
  shiftRPM: 9e3,
  downshiftRPM: 5200,
  limiterRPM: 9300,
  torqueCurve: [
    [3e3, 360],
    [5e3, 440],
    [6500, 470],
    [7500, 455],
    [8750, 416],
    [9300, 360]
  ],
  engine: combustion(4.2, 800, 0.22),
  brakeTorque: 9500,
  aero: { clA: 2.4, cdA: 0.9, balance: 0.38 },
  tireFamily: "slick",
  tireGrip: 0.86,
  rearGrip: 1.12,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.45, 0.3) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  elementMass: [4, 5],
  ai: {
    lateralBase: 11.89,
    lateralAero: 2e-3,
    brakingBase: 15.46,
    brakingAero: 142e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.65,
    brakingMargin: 0.74,
    topSpeed: 81
  },
  bands: GT_BANDS
});
var GT_FRONT_I6 = defineVehicle({
  id: "gt6s",
  name: "GT-6S STRAIGHT-SIX GT",
  classId: "gt",
  brief: "Front-engined GT on a long wheelbase: 3.0 L twin-turbo straight-six ahead of the driver, about 400 kW with a flat torque plateau, 1340 kg, 52/48 split, pedestal wing. Intended skill: novice\u2013intermediate. Strengths: stability at high speed and under braking, turbo torque out of slow corners. Weaknesses: the longest, heaviest car in the class, slow direction changes, nose-heavy understeer. Targets: 0\u2013100 about 3.5 s, about 280 km/h, about 1.33 g at 80 km/h.",
  mass: 1340,
  frontWeight: 0.52,
  cogHeight: 0.47,
  wheelbase: 2.86,
  trackFront: 1.66,
  trackRear: 1.64,
  width: 2.04,
  height: 1.25,
  overhangFront: 1.15,
  overhangRear: 0.95,
  groundClearance: 0.075,
  wheelRadius: 0.345,
  wheelInertia: 2,
  linkCentreHeight: 0.24,
  maxSteer: 0.42,
  finalDrive: 3.3,
  gearRatios: [-2.9, 0, 3.1, 2.2, 1.72, 1.4, 1.16, 1],
  idleRPM: 1100,
  shiftRPM: 7e3,
  downshiftRPM: 3800,
  limiterRPM: 7300,
  torqueCurve: [
    [1800, 520],
    [3e3, 650],
    [5e3, 650],
    [6e3, 600],
    [7e3, 545],
    [7300, 500]
  ],
  engine: combustion(3, 1e3, 0.24),
  brakeTorque: 9800,
  aero: { clA: 2.3, cdA: 0.92, balance: 0.44 },
  tireFamily: "slick",
  tireGrip: 0.86,
  // The brief asks for a stable, nose-heavy car, but at 1.07 it measured a lower understeer
  // gradient (1.95 deg/g) than the front-mid V8 (2.38) and spun on full throttle just like it.
  // More rear grip makes it the understeering, stable one (2.5 deg/g, 40 deg of throttle spin).
  rearGrip: 1.14,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.45, 0.3) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  elementMass: [4, 5],
  ai: {
    lateralBase: 12.68,
    lateralAero: 122e-5,
    brakingBase: 14.04,
    brakingAero: 205e-5,
    lateralMargin: 0.73,
    slowLateralMargin: 0.65,
    brakingMargin: 0.74,
    topSpeed: 78
  },
  bands: GT_BANDS
});
var GT_SPORT_MID_V6 = defineVehicle({
  id: "gs6m",
  name: "GS-6M MID-ENGINE GT SPORT",
  classId: "gt-sport",
  brief: "Mid-engined entry GT: 3.8 L naturally aspirated V6 behind the driver, about 300 kW, 1400 kg, 43/57 split, small fixed wing, harder slicks. Intended skill: novice\u2013intermediate. Strengths: rotation and a linear throttle, a lighter nose than the front-engined GS-4. Weaknesses: less torque than GS-4, snap oversteer on lift-off, low top speed. Targets: 0\u2013100 about 4.2 s, about 255 km/h, about 1.25 g at 80 km/h.",
  mass: 1400,
  frontWeight: 0.43,
  cogHeight: 0.47,
  wheelbase: 2.58,
  trackFront: 1.6,
  trackRear: 1.58,
  width: 1.92,
  height: 1.2,
  overhangFront: 0.98,
  overhangRear: 0.85,
  groundClearance: 0.09,
  wheelRadius: 0.33,
  wheelInertia: 1.8,
  linkCentreHeight: 0.24,
  maxSteer: 0.44,
  finalDrive: 3.6,
  gearRatios: [-3, 0, 3.2, 2.3, 1.8, 1.47, 1.24, 1.04],
  idleRPM: 1e3,
  shiftRPM: 7600,
  downshiftRPM: 4200,
  limiterRPM: 7900,
  torqueCurve: [
    [2e3, 330],
    [4e3, 420],
    [5500, 440],
    [6500, 425],
    [7500, 382],
    [7900, 340]
  ],
  engine: combustion(3.8, 700, 0.22),
  brakeTorque: 8e3,
  aero: { clA: 0.9, cdA: 0.84, balance: 0.42 },
  tireFamily: "slick",
  tireGrip: 0.78,
  rearGrip: 1.08,
  drivetrain: "rwd",
  driveline: { rear: lsd(50, 0.35, 0.2) },
  setupKeys: KEYS.closed,
  setupLimits: GT_LIMITS,
  ai: {
    lateralBase: 11.07,
    lateralAero: 101e-5,
    brakingBase: 12.91,
    brakingAero: 99e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 71,
    lineScale: 0.8
  },
  bands: {
    accel0to100: [3.6, 5],
    topSpeed: [240, 275],
    braking100Distance: [28, 40],
    lateral80G: [1.15, 1.5]
  }
});

// actual-source:src/simulation/vehicle-catalogue/touring-club-2.ts
var TOURING_TC3 = defineVehicle({
  id: "tc3",
  name: "TC-3 AWD TOURING",
  classId: "touring",
  brief: "All-wheel-drive touring saloon: 2.0 L turbo four, about 290 kW, 1300 kg (a weight penalty for the driveline), centre clutch-pack differential sending 40% forward, small splitter and wing. Intended skill: novice\u2013intermediate. Strengths: launches, traction in the wet and out of slow corners. Weaknesses: weight, power understeer on entry, the front tyres do two jobs. Shares the touring grid with TC-1 (front drive) and TC-2 (rear drive). Targets: 0\u2013100 about 4.0 s, about 240 km/h, about 1.3 g at 80 km/h.",
  mass: 1300,
  frontWeight: 0.56,
  cogHeight: 0.48,
  wheelbase: 2.7,
  trackFront: 1.58,
  trackRear: 1.58,
  width: 1.9,
  height: 1.32,
  overhangFront: 0.95,
  overhangRear: 0.85,
  groundClearance: 0.08,
  wheelRadius: 0.325,
  wheelInertia: 1.5,
  linkCentreHeight: 0.25,
  maxSteer: 0.46,
  finalDrive: 3.7,
  gearRatios: [-3.2, 0, 2.75, 2.1, 1.7, 1.4, 1.17, 1],
  idleRPM: 1400,
  shiftRPM: 7200,
  downshiftRPM: 4e3,
  limiterRPM: 7500,
  torqueCurve: [
    [2e3, 320],
    [3e3, 450],
    [5500, 470],
    [6500, 420],
    [7200, 375],
    [7500, 330]
  ],
  engine: combustion(2, 800, 0.2),
  brakeTorque: 9e3,
  aero: { clA: 0.6, cdA: 0.8, balance: 0.42 },
  tireFamily: "slick",
  tireGrip: 0.82,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(120, 0.4, 0.2), frontShare: 0.4 },
    front: lsd(60, 0.3, 0.15),
    rear: lsd(70, 0.4, 0.25)
  },
  setupKeys: KEYS.closed,
  ai: {
    lateralBase: 11.71,
    lateralAero: 83e-5,
    brakingBase: 13.08,
    brakingAero: 78e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 68
  },
  bands: {
    accel0to100: [3.4, 4.8],
    topSpeed: [225, 265],
    braking100Distance: [26, 40],
    lateral80G: [1.15, 1.5]
  }
});
var HOT_HATCH_HH2 = defineVehicle({
  id: "hh2",
  name: "HH-2 HOT-HATCH RACER",
  classId: "club",
  brief: "Front-drive hot-hatch club racer: 2.0 L turbo four, about 200 kW, 1180 kg with driver, roll cage, semi-slicks, front clutch-pack differential. Intended skill: novice. Strengths: braking stability, torque, forgiving lift-off rotation. Weaknesses: front tyre overload and torque steer, high centre of gravity, no downforce. Races the CR-1 roadster in the club class: more power, more mass. Targets: 0\u2013100 about 5.4 s, about 230 km/h, about 1.2 g at 80 km/h.",
  mass: 1180,
  frontWeight: 0.62,
  cogHeight: 0.5,
  wheelbase: 2.63,
  trackFront: 1.56,
  trackRear: 1.54,
  width: 1.84,
  height: 1.42,
  overhangFront: 0.92,
  overhangRear: 0.72,
  groundClearance: 0.1,
  wheelRadius: 0.315,
  wheelInertia: 1.3,
  linkCentreHeight: 0.24,
  maxSteer: 0.48,
  finalDrive: 4,
  gearRatios: [-3.3, 0, 2.7, 1.98, 1.54, 1.23, 1.02, 0.875],
  idleRPM: 900,
  shiftRPM: 6600,
  downshiftRPM: 3600,
  limiterRPM: 6900,
  torqueCurve: [
    [1800, 240],
    [2500, 320],
    [3500, 380],
    [5e3, 380],
    [6e3, 330],
    [6600, 290],
    [6900, 250]
  ],
  engine: combustion(2, 600, 0.18),
  brakeTorque: 6500,
  aero: { clA: 0.3, cdA: 0.78, balance: 0.55 },
  tireFamily: "semi-slick",
  tireGrip: 0.74,
  drivetrain: "fwd",
  driveline: { front: lsd(50, 0.4, 0.2) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 8e4, rearSpring: 7e4, frontARB: 16e3, rearARB: 22e3 },
  elementMass: [2, 2],
  ai: {
    lateralBase: 11.38,
    lateralAero: 16e-5,
    brakingBase: 12.01,
    brakingAero: 76e-5,
    lateralMargin: 0.75,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 64
  },
  bands: {
    accel0to100: [4.6, 6.4],
    topSpeed: [215, 245],
    braking100Distance: [28, 42],
    lateral80G: [1.1, 1.4]
  }
});
var VINTAGE_VC62 = defineVehicle({
  id: "vc62",
  name: "VC-62 VINTAGE ROADSTER",
  classId: "vintage",
  brief: "A 1962-style vintage club roadster: 1.6 L naturally aspirated four on twin carburettors, about 100 kW, 760 kg with driver, four-speed, cross-ply tyres on wire wheels, front discs and rear drums, no aerodynamics to speak of. Intended skill: novice\u2013intermediate. Strengths: balance, low speeds that forgive mistakes, close slipstream racing. Weaknesses: little grip, long braking, body roll, front lift at speed. Targets: 0\u2013100 about 7 s, about 195 km/h, about 1.0 g at 80 km/h.",
  mass: 760,
  frontWeight: 0.5,
  cogHeight: 0.45,
  wheelbase: 2.3,
  trackFront: 1.3,
  trackRear: 1.3,
  width: 1.55,
  height: 1.2,
  overhangFront: 0.75,
  overhangRear: 0.7,
  groundClearance: 0.12,
  wheelRadius: 0.3,
  wheelInertia: 1,
  linkCentreHeight: 0.22,
  maxSteer: 0.5,
  finalDrive: 4.1,
  gearRatios: [-3.2, 0, 2.5, 1.75, 1.3, 1],
  idleRPM: 900,
  shiftRPM: 6900,
  downshiftRPM: 3800,
  limiterRPM: 7200,
  torqueCurve: [
    [2e3, 120],
    [3500, 150],
    [5e3, 160],
    [6e3, 155],
    [6800, 140],
    [7200, 120]
  ],
  engine: combustion(1.6, 300, 0.14),
  brakeTorque: 3200,
  aero: { clA: 0, cdA: 0.75, balance: 0.5 },
  tireFamily: "historic",
  tireGrip: 0.62,
  drivetrain: "rwd",
  driveline: { rear: lsd(25, 0.25, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: {
    frontSpring: 5e4,
    rearSpring: 5e4,
    frontARB: 1e4,
    rearARB: 4e3,
    frontRide: 0.08,
    rearRide: 0.09
  },
  setupLimits: { frontARB: [0, 25e3], rearARB: [0, 15e3] },
  elementMass: [2, 2],
  ai: {
    lateralBase: 10.15,
    lateralAero: 0,
    brakingBase: 10.43,
    brakingAero: 0,
    lateralMargin: 0.75,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 54
  },
  bands: {
    accel0to100: [6, 8.5],
    topSpeed: [180, 210],
    braking100Distance: [34, 50],
    lateral80G: [0.9, 1.15]
  }
});

// actual-source:src/simulation/vehicle-catalogue/dirt-2.ts
var CLASSIC_RALLY_RL7 = defineVehicle({
  id: "rl7",
  name: "RL-7 CLASSIC RALLY",
  classId: "historic-rally",
  brief: "A 1970s-style rear-drive rally saloon: 2.0 L sixteen-valve four, about 180 kW at 8500 rpm, 1100 kg with crew, five-speed dog box with short gearing, clutch-pack rear differential, gravel tyres. Intended skill: intermediate. Strengths: light, agile, drives on the throttle, cheap to repair. Weaknesses: rear-drive traction on loose ground, narrow power band, low top speed. Targets: 0\u2013100 about 5.5 s, about 185 km/h, about 1.1 g at 80 km/h on asphalt.",
  mass: 1100,
  frontWeight: 0.53,
  cogHeight: 0.5,
  wheelbase: 2.4,
  trackFront: 1.38,
  trackRear: 1.4,
  width: 1.7,
  height: 1.4,
  overhangFront: 0.85,
  overhangRear: 0.85,
  groundClearance: 0.15,
  wheelRadius: 0.31,
  wheelInertia: 1.2,
  restLength: 0.28,
  linkCentreHeight: 0.27,
  maxSteer: 0.5,
  finalDrive: 5.1,
  gearRatios: [-3, 0, 2.6, 1.85, 1.45, 1.22, 1.09],
  idleRPM: 1100,
  shiftRPM: 8700,
  downshiftRPM: 5e3,
  limiterRPM: 9e3,
  torqueCurve: [
    [3e3, 170],
    [5e3, 215],
    [6500, 235],
    [7500, 228],
    [8500, 205],
    [9e3, 180]
  ],
  engine: combustion(2, 450, 0.16),
  brakeTorque: 6e3,
  aero: { clA: 0, cdA: 0.85, balance: 0.5 },
  tireFamily: "gravel",
  tireGrip: 0.68,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.5, 0.3) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 75e3, rearSpring: 7e4, frontARB: 14e3, rearARB: 8e3 },
  elementMass: [3, 3],
  ai: {
    lateralBase: 10.7,
    lateralAero: 0,
    brakingBase: 11.15,
    brakingAero: 0,
    lateralMargin: 0.74,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 51
  },
  bands: {
    accel0to100: [4.6, 6.4],
    topSpeed: [175, 200],
    braking100Distance: [32, 48],
    lateral80G: [0.95, 1.25]
  }
});
var GROUP_RALLY_GB4 = defineVehicle({
  id: "gb4",
  name: "GB-4 GROUP RALLY",
  classId: "historic-rally",
  brief: "A mid-1980s group-supercar rally car: 2.1 L turbocharged five mounted behind the crew, about 370 kW, 1120 kg, permanent four-wheel drive with a clutch-pack centre differential sending 35% forward, gravel tyres, big rear wing. Intended skill: expert. Strengths: violent acceleration and traction everywhere. Weaknesses: turbo lag, mid-engine snap on lift-off, heavy steering at the limit, unforgiving in contact. Targets: 0\u2013100 about 3.2 s on asphalt, about 220 km/h, about 1.15 g at 80 km/h.",
  mass: 1120,
  frontWeight: 0.42,
  cogHeight: 0.5,
  wheelbase: 2.45,
  trackFront: 1.5,
  trackRear: 1.5,
  width: 1.85,
  height: 1.38,
  overhangFront: 0.85,
  overhangRear: 0.75,
  groundClearance: 0.14,
  wheelRadius: 0.32,
  wheelInertia: 1.35,
  restLength: 0.28,
  linkCentreHeight: 0.27,
  maxSteer: 0.5,
  finalDrive: 4.4,
  gearRatios: [-3, 0, 2.5, 1.85, 1.43, 1.17, 0.98],
  idleRPM: 1200,
  shiftRPM: 7700,
  downshiftRPM: 4200,
  limiterRPM: 8e3,
  torqueCurve: [
    [2500, 300],
    [3500, 500],
    [5e3, 600],
    [6500, 540],
    [7500, 450],
    [8e3, 390]
  ],
  engine: combustion(2.1, 900, 0.19),
  turbo: { boostShare: 0.5, spoolTime: 0.5, dumpFraction: 0.3, spoolRPM: [1e3, 2e3] },
  brakeTorque: 8500,
  aero: { clA: 0.5, cdA: 0.95, balance: 0.35 },
  tireFamily: "gravel",
  tireGrip: 0.72,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(150, 0.4, 0.2), frontShare: 0.35 },
    front: lsd(60, 0.3, 0.15),
    rear: lsd(100, 0.5, 0.3)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 9e4, rearSpring: 95e3, frontARB: 18e3, rearARB: 12e3 },
  elementMass: [3, 5],
  ai: {
    lateralBase: 10.65,
    lateralAero: 8e-4,
    brakingBase: 11.81,
    brakingAero: 82e-5,
    lateralMargin: 0.68,
    slowLateralMargin: 0.6,
    brakingMargin: 0.7,
    topSpeed: 61,
    lineScale: 0.8
  },
  bands: {
    accel0to100: [2.6, 3.8],
    topSpeed: [205, 235],
    braking100Distance: [30, 46],
    lateral80G: [1, 1.35]
  }
});
var ELECTRIC_RALLYCROSS_RXE = defineVehicle({
  id: "rxe",
  name: "RX-E ELECTRIC RALLYCROSS",
  classId: "rallycross",
  brief: "Electric rallycross car: one motor per axle modelled as one equivalent drive (500 kW, 880 N m at the motor, single reduction) coupled front to rear at a fixed 50:50 split, 1490 kg with the battery, gravel tyres. Intended skill: intermediate. Strengths: instant torque, the best launch on the grid, no gear changes. Weaknesses: 190 kg more than RCX-6, heavy in direction changes, single-speed top end. Known limit: energy is drawn from the shared fuel-mass proxy. Targets: 0\u2013100 about 2.3 s, about 230 km/h, about 1.15 g at 80 km/h.",
  mass: 1490,
  frontWeight: 0.5,
  cogHeight: 0.48,
  wheelbase: 2.6,
  trackFront: 1.62,
  trackRear: 1.62,
  width: 1.95,
  height: 1.4,
  overhangFront: 0.95,
  overhangRear: 0.8,
  groundClearance: 0.12,
  wheelRadius: 0.325,
  wheelInertia: 1.45,
  restLength: 0.27,
  linkCentreHeight: 0.27,
  maxSteer: 0.5,
  finalDrive: 7.5,
  gearRatios: [-1, 0, 1],
  idleRPM: 300,
  shiftRPM: 13900,
  downshiftRPM: 400,
  limiterRPM: 14e3,
  torqueCurve: [
    [300, 880],
    [5400, 880],
    [8e3, 597],
    [1e4, 477],
    [12e3, 398],
    [14e3, 341]
  ],
  engine: {
    frictionBase: 2,
    frictionPerRad: 4e-3,
    inertia: 0.12,
    idleTorque: 100,
    clutchCapacity: 1400
  },
  brakeTorque: 9500,
  aero: { clA: 0.7, cdA: 0.95, balance: 0.42 },
  tireFamily: "gravel",
  tireGrip: 0.72,
  drivetrain: "awd",
  driveline: {
    centre: { ...LOCKED, frontShare: 0.5 },
    front: lsd(80, 0.3, 0.2),
    rear: lsd(80, 0.35, 0.2)
  },
  powertrain: "electric",
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 1e5, rearSpring: 1e5, frontARB: 2e4, rearARB: 16e3 },
  elementMass: [3, 4],
  ai: {
    lateralBase: 10.38,
    lateralAero: 67e-5,
    brakingBase: 11.39,
    brakingAero: 75e-5,
    lateralMargin: 0.74,
    slowLateralMargin: 0.68,
    brakingMargin: 0.74,
    topSpeed: 63
  },
  bands: {
    accel0to100: [1.9, 2.8],
    topSpeed: [215, 245],
    braking100Distance: [28, 44],
    lateral80G: [1, 1.4]
  }
});
var DESERT_BUGGY_BG2 = defineVehicle({
  id: "bg2",
  name: "BG-2 DESERT BUGGY",
  classId: "offroad",
  brief: "Mid-engined desert buggy: 3.5 L twin-turbo V6 behind the crew, about 300 kW, 1650 kg, tube frame with minimal body panels, rear drive through a high-preload differential, four-speed sequential, 35-inch all-terrain tyres. Intended skill: intermediate. Strengths: lighter and quicker to turn than the DX-8 truck, traction from the rear weight bias. Weaknesses: tall and narrow-tracked for its height, little top speed, long braking; suspension travel is limited by the current solver (as DX-8). Targets: 0\u2013100 about 5 s, about 190 km/h, about 0.95 g at 80 km/h.",
  mass: 1650,
  frontWeight: 0.42,
  cogHeight: 0.65,
  wheelbase: 3.05,
  trackFront: 1.95,
  trackRear: 1.95,
  width: 2.15,
  height: 1.75,
  overhangFront: 0.85,
  overhangRear: 0.75,
  groundClearance: 0.32,
  wheelRadius: 0.42,
  wheelInertia: 4.5,
  restLength: 0.38,
  linkCentreHeight: 0.38,
  maxSteer: 0.5,
  finalDrive: 5.4,
  gearRatios: [-2.9, 0, 2.6, 1.7, 1.25, 0.98],
  idleRPM: 900,
  shiftRPM: 6200,
  downshiftRPM: 3200,
  limiterRPM: 6500,
  torqueCurve: [
    [2e3, 480],
    [3e3, 600],
    [4500, 640],
    [5500, 560],
    [6200, 470],
    [6500, 420]
  ],
  engine: combustion(3.5, 1e3, 0.26),
  brakeTorque: 7200,
  aero: { clA: 0, cdA: 1.4, balance: 0.5 },
  tireFamily: "all-terrain",
  tireGrip: 0.66,
  drivetrain: "rwd",
  driveline: { rear: lsd(150, 0.5, 0.3) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 9e4, rearSpring: 1e5, frontARB: 1e4, rearARB: 7e3 },
  elementMass: [5, 5],
  ai: {
    lateralBase: 9.48,
    lateralAero: 0,
    brakingBase: 10.37,
    brakingAero: 0,
    lateralMargin: 0.68,
    slowLateralMargin: 0.62,
    brakingMargin: 0.7,
    topSpeed: 53,
    lineScale: 0.78
  },
  bands: {
    accel0to100: [4, 6],
    topSpeed: [180, 205],
    braking100Distance: [36, 56],
    lateral80G: [0.8, 1.1]
  }
});

// actual-source:src/simulation/vehicle-catalogue/experimental.ts
var FAN_CAR_XF2 = defineVehicle({
  id: "xf2",
  name: "XF-2 FAN PROTOTYPE",
  classId: "experimental",
  brief: "Fan-assisted downforce prototype: an auxiliary engine drives two fans that evacuate a skirted floor, about 7 kN of suction at any road speed, on a 780 kg closed car with a 3.0 L V8 (about 390 kW) and almost no wings (low drag). Intended skill: expert. Strengths: cornering and braking grip that does not wait for speed, low drag on the straights. Weaknesses: suction is lost when the skirts lift (crests, kerbs, a spin), stiff ride, a failure hands the car back its 780 kg of mechanical grip. Targets: 0\u2013100 about 2.8 s, about 310 km/h, 100\u20130 under 24 m, well over 2 g at 80 km/h.",
  mass: 780,
  frontWeight: 0.42,
  cogHeight: 0.42,
  wheelbase: 2.8,
  trackFront: 1.65,
  trackRear: 1.6,
  width: 2,
  height: 1.05,
  overhangFront: 1,
  overhangRear: 0.8,
  groundClearance: 0.05,
  wheelRadius: 0.34,
  wheelInertia: 1.7,
  linkCentreHeight: 0.22,
  maxSteer: 0.4,
  finalDrive: 3.9,
  gearRatios: [-2.9, 0, 2.8, 2.1, 1.7, 1.42, 1.22, 1.08],
  idleRPM: 3e3,
  shiftRPM: 10700,
  downshiftRPM: 7e3,
  limiterRPM: 11e3,
  torqueCurve: [
    [4e3, 280],
    [6e3, 350],
    [8e3, 380],
    [9500, 375],
    [10500, 355],
    [11e3, 330]
  ],
  engine: combustion(3, 700, 0.18),
  brakeTorque: 11e3,
  aero: { clA: 1.2, cdA: 0.85, balance: 0.45 },
  fan: { force: 7e3, z: -0.1 },
  tireFamily: "slick",
  tireGrip: 0.9,
  rearGrip: 1.06,
  drivetrain: "rwd",
  driveline: { rear: lsd(70, 0.4, 0.25) },
  setupKeys: KEYS.closed,
  setupDefaults: { frontSpring: 16e4, rearSpring: 17e4, frontARB: 3e4, rearARB: 24e3 },
  elementMass: [3, 4],
  ai: {
    lateralBase: 20.64,
    lateralAero: 324e-5,
    brakingBase: 27.82,
    brakingAero: 198e-5,
    // The fan's share of the bases (fan-on fit less fan-off fit): lost with
    // the floor, so a damaged XF-2's AI plans on its mechanical grip.
    fanBase: { lateral: 7.58, braking: 12.18 },
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 88
  },
  bands: {
    accel0to100: [2.4, 3.4],
    topSpeed: [290, 335],
    braking100Distance: [13, 24],
    lateral80G: [2, 3]
  }
});
var ELECTRIC_TIME_ATTACK_XE1 = defineVehicle({
  id: "xe1",
  name: "XE-1 ELECTRIC TIME ATTACK",
  classId: "experimental",
  brief: "Electric time-attack prototype: two motors (about 500 kW together, modelled as one equivalent drive at 850 N m, single reduction) through a clutch-pack centre coupling sending 45% forward, 1000 kg with driver, enormous wings and diffuser on wide single-seater-construction slicks. Intended skill: intermediate\u2013expert. Strengths: launches, downforce in medium and fast corners, no gear changes. Weaknesses: drag caps top speed, battery mass, a short single-lap energy budget (fuel-mass proxy). Targets: 0\u2013100 about 2.2 s, about 265 km/h, 100\u20130 about 22 m, about 2 g at 80 km/h.",
  mass: 1e3,
  frontWeight: 0.45,
  cogHeight: 0.34,
  wheelbase: 2.85,
  trackFront: 1.88,
  trackRear: 1.82,
  width: 2.2,
  height: 1.15,
  overhangFront: 1.25,
  overhangRear: 1,
  groundClearance: 0.05,
  wheelRadius: 0.35,
  wheelInertia: 1.9,
  linkCentreHeight: 0.22,
  maxSteer: 0.4,
  finalDrive: 6.1,
  gearRatios: [-1, 0, 1],
  idleRPM: 300,
  shiftRPM: 11900,
  downshiftRPM: 400,
  limiterRPM: 12e3,
  torqueCurve: [
    [300, 850],
    [5600, 850],
    [7e3, 682],
    [9e3, 531],
    [10500, 455],
    [12e3, 398]
  ],
  engine: {
    frictionBase: 2,
    frictionPerRad: 4e-3,
    inertia: 0.12,
    idleTorque: 100,
    clutchCapacity: 2e3
  },
  brakeTorque: 14e3,
  aero: { clA: 7.5, cdA: 1.6, balance: 0.42 },
  tireFamily: "formula-slick",
  tireGrip: 1,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(400, 0.3, 0.3), frontShare: 0.45 },
    front: lsd(100, 0.3, 0.2),
    rear: lsd(100, 0.35, 0.2)
  },
  powertrain: "electric",
  setupKeys: KEYS.winged,
  elementMass: [6, 8],
  ai: {
    lateralBase: 14.31,
    lateralAero: 533e-5,
    brakingBase: 16.93,
    brakingAero: 695e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 71
  },
  bands: {
    accel0to100: [1.9, 2.8],
    topSpeed: [245, 280],
    braking100Distance: [16, 28],
    lateral80G: [1.7, 2.6]
  }
});
var HYDROGEN_XH3 = defineVehicle({
  id: "xh3",
  name: "XH-3 HYDROGEN PROTOTYPE",
  classId: "experimental",
  brief: "Hydrogen endurance prototype concept: a fuel-cell stack and buffer battery feeding front and rear motors (about 480 kW, modelled as one equivalent electric drive through a centre coupling sending 35% forward), 1250 kg with the pressure tanks, efficient low-drag endurance aero. Intended skill: intermediate. Strengths: traction, efficient at speed, silent but for compressor and inverter whine. Weaknesses: tank mass, a single reduction gives up acceleration at the top. Known limit: hydrogen is drawn from the shared fuel-mass proxy, and the fuel-cell power curve is a static map. Targets: 0\u2013100 about 2.8 s, about 320 km/h, about 1.6 g at 80 km/h.",
  mass: 1250,
  frontWeight: 0.46,
  cogHeight: 0.43,
  wheelbase: 3.15,
  trackFront: 1.7,
  trackRear: 1.66,
  width: 2,
  height: 1.12,
  overhangFront: 1.25,
  overhangRear: 0.95,
  groundClearance: 0.055,
  wheelRadius: 0.355,
  wheelInertia: 1.95,
  linkCentreHeight: 0.22,
  maxSteer: 0.36,
  finalDrive: 5.86,
  gearRatios: [-1, 0, 1],
  idleRPM: 300,
  shiftRPM: 13900,
  downshiftRPM: 400,
  limiterRPM: 14e3,
  torqueCurve: [
    [300, 800],
    [5730, 800],
    [8e3, 573],
    [1e4, 458],
    [12e3, 382],
    [14e3, 327]
  ],
  engine: {
    frictionBase: 2,
    frictionPerRad: 4e-3,
    inertia: 0.13,
    idleTorque: 100,
    clutchCapacity: 1800
  },
  brakeTorque: 14e3,
  aero: { clA: 3.6, cdA: 0.82, balance: 0.45 },
  tireFamily: "slick",
  tireGrip: 0.92,
  rearGrip: 1.05,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(300, 0.3, 0.3), frontShare: 0.35 },
    front: lsd(100, 0.3, 0.2),
    rear: lsd(150, 0.4, 0.25)
  },
  powertrain: "electric",
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 12.6,
    lateralAero: 292e-5,
    brakingBase: 15.2,
    brakingAero: 282e-5,
    lateralMargin: 0.72,
    slowLateralMargin: 0.64,
    brakingMargin: 0.74,
    topSpeed: 88
  },
  bands: {
    accel0to100: [2.4, 3.4],
    topSpeed: [300, 335],
    braking100Distance: [20, 34],
    lateral80G: [1.4, 2.1]
  }
});
var TRACK_HYPERCAR_XT1 = defineVehicle({
  id: "xt1",
  name: "XT-1 TRACK HYPERCAR",
  classId: "experimental",
  brief: "Track-only hypercar outside any rule book: 6.5 L naturally aspirated V12 revving to 11 100 rpm, about 750 kW, 1120 kg with driver, slicks, a race-car wing and diffuser, seven-speed sequential. Intended skill: expert. Strengths: power everywhere, downforce at speed, a progressive engine. Weaknesses: rear-drive traction on 750 kW, heavier than a prototype, brake heat. Targets: 0\u2013100 about 2.7 s, about 350 km/h, about 1.6 g at 80 km/h.",
  mass: 1120,
  frontWeight: 0.43,
  cogHeight: 0.42,
  wheelbase: 2.75,
  trackFront: 1.72,
  trackRear: 1.66,
  width: 2.07,
  height: 1.1,
  overhangFront: 1.15,
  overhangRear: 0.95,
  groundClearance: 0.06,
  wheelRadius: 0.355,
  wheelInertia: 2,
  linkCentreHeight: 0.22,
  maxSteer: 0.42,
  finalDrive: 3.8,
  gearRatios: [-2.9, 0, 3, 2.25, 1.8, 1.5, 1.3, 1.15, 1.04],
  idleRPM: 1500,
  shiftRPM: 10800,
  downshiftRPM: 6500,
  limiterRPM: 11100,
  torqueCurve: [
    [4e3, 560],
    [6e3, 640],
    [8e3, 700],
    [9500, 720],
    [10500, 680],
    [11100, 620]
  ],
  engine: combustion(6.5, 1200, 0.3),
  brakeTorque: 15e3,
  aero: { clA: 4, cdA: 1.15, balance: 0.43 },
  tireFamily: "slick",
  // 0.90 measured 1.47 g at 80 km/h against the brief's 1.6 g (and the lowest margin to its
  // 1.45 g band floor); 0.94 puts it at the brief's number.
  tireGrip: 0.94,
  rearGrip: 1.14,
  drivetrain: "rwd",
  driveline: { rear: lsd(100, 0.45, 0.3) },
  setupKeys: KEYS.winged,
  elementMass: [5, 6],
  ai: {
    lateralBase: 13.14,
    lateralAero: 332e-5,
    brakingBase: 16.33,
    brakingAero: 367e-5,
    lateralMargin: 0.7,
    slowLateralMargin: 0.62,
    brakingMargin: 0.72,
    topSpeed: 99,
    lineScale: 0.8
  },
  bands: {
    accel0to100: [2.3, 3.2],
    topSpeed: [330, 370],
    braking100Distance: [18, 32],
    lateral80G: [1.45, 2.2]
  }
});
var DIRECT_KART_DK100 = defineVehicle({
  id: "dk100",
  name: "DK-100 DIRECT-DRIVE KART",
  classId: "kart",
  brief: "Direct-drive sprint kart: 100 cc reed-valve two-stroke, about 23 kW at 16 500 rpm, one sprocket ratio and a centrifugal clutch, 155 kg with driver, a rear-axle brake only, harder sprint tyres. Intended skill: novice. Strengths: momentum and line discipline, cornering grip per kilogram. Weaknesses: slow to accelerate (no gears), rear-only brakes lock and slide, the locked axle understeers. Targets: 0\u2013100 about 8 s, about 115 km/h, about 2 g at 80 km/h.",
  mass: 155,
  frontWeight: 0.42,
  cogHeight: 0.27,
  wheelbase: 1.04,
  trackFront: 1.1,
  trackRear: 1.36,
  width: 1.38,
  height: 0.6,
  overhangFront: 0.45,
  overhangRear: 0.3,
  groundClearance: 0.03,
  wheelRadius: 0.137,
  wheelInertia: 0.06,
  restLength: 0.08,
  linkCentreHeight: 0.12,
  maxSteer: 0.45,
  inertia: [45, 55, 70],
  finalDrive: 7.8,
  gearRatios: [-1, 0, 1],
  idleRPM: 3e3,
  shiftRPM: 17800,
  downshiftRPM: 3500,
  limiterRPM: 18e3,
  torqueCurve: [
    [6e3, 6.5],
    [9e3, 10],
    [12e3, 13],
    [14500, 14.5],
    [16500, 13.2],
    [18e3, 11]
  ],
  fuelLoad: 5,
  engine: {
    frictionBase: 0.25,
    frictionPerRad: 8e-4,
    inertia: 6e-3,
    idleTorque: 4,
    // Centrifugal clutch: bites from about 8800 rpm and holds the engine near
    // 10 000 rpm until the axle catches up (full lock above 17 600 rpm).
    clutchCapacity: 60,
    engageRPM: 16e3,
    clutchCoupling: 0.15
  },
  brakeTorque: 520,
  aero: { clA: 0, cdA: 0.58, balance: 0.5 },
  tireFamily: "kart",
  tireGrip: 0.95,
  rearGrip: 1,
  drivetrain: "rwd",
  driveline: { rear: LOCKED },
  // Brakes act on the rear axle only, so the bias is fixed and not a setting.
  setupKeys: KEYS.fixedChassis.filter((key) => key !== "brakeBias"),
  setupDefaults: {
    frontSpring: 6e4,
    rearSpring: 7e4,
    frontARB: 0,
    rearARB: 12e3,
    frontRide: 0.065,
    rearRide: 0.075,
    brakeBias: 0
  },
  setupLimits: { frontARB: [0, 15e3], rearARB: [0, 25e3] },
  elementMass: [0.8, 0.8],
  ai: {
    lateralBase: 14.86,
    lateralAero: 0,
    brakingBase: 8.58,
    brakingAero: 0,
    lateralMargin: 0.72,
    slowLateralMargin: 0.66,
    brakingMargin: 0.74,
    topSpeed: 33,
    lineScale: 0.75,
    lookahead: [4, 0.32]
  },
  bands: {
    accel0to100: [6, 10.5],
    topSpeed: [105, 125],
    braking100Distance: [26, 44],
    lateral80G: [1.6, 2.5]
  }
});

// actual-source:src/simulation/vehicle-catalogue/road-festival.ts
var ROAD_AI = {
  lateralMargin: 0.74,
  slowLateralMargin: 0.66,
  brakingMargin: 0.74,
  lineScale: 0.8
};
var HOT_HATCH_RH3 = defineVehicle({
  id: "rh3",
  name: "RH-3 HOT HATCH",
  classId: "road",
  brief: "Road hot hatch: transverse 2.0 L turbo four, about 235 kW, 1500 kg with driver, front drive through a clutch-pack differential, six-speed. Intended skill: novice. Strengths: usable torque, stable under braking, rotates on a lift. Weaknesses: front tyres saturate on power out of slow corners, high centre of gravity, soft road springs. Targets: 0\u2013100 about 5.7 s, about 255 km/h, about 1.05 g at 80 km/h.",
  mass: 1500,
  frontWeight: 0.62,
  cogHeight: 0.53,
  wheelbase: 2.64,
  trackFront: 1.58,
  trackRear: 1.56,
  width: 1.82,
  height: 1.44,
  overhangFront: 0.92,
  overhangRear: 0.76,
  groundClearance: 0.12,
  wheelRadius: 0.335,
  wheelInertia: 1.5,
  linkCentreHeight: 0.2,
  maxSteer: 0.5,
  finalDrive: 3.9,
  gearRatios: [-3.3, 0, 3.3, 2.05, 1.46, 1.13, 0.95, 0.83],
  idleRPM: 850,
  shiftRPM: 6600,
  downshiftRPM: 2800,
  limiterRPM: 6800,
  torqueCurve: [
    [1800, 380],
    [2500, 420],
    [5e3, 420],
    [6e3, 370],
    [6500, 340],
    [6800, 300]
  ],
  engine: combustion(2, 650, 0.2),
  brakeTorque: 8e3,
  aero: { clA: 0.15, cdA: 0.74, balance: 0.5 },
  tireFamily: "road",
  tireGrip: 0.72,
  drivetrain: "fwd",
  driveline: { front: lsd(40, 0.35, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 75e3, rearSpring: 7e4, frontARB: 2e4, rearARB: 18e3 },
  ai: {
    ...ROAD_AI,
    lateralBase: 10.7,
    lateralAero: 11e-5,
    brakingBase: 11.75,
    brakingAero: 25e-5,
    topSpeed: 72
  },
  bands: {
    accel0to100: [5, 6.6],
    topSpeed: [245, 275],
    braking100Distance: [30, 42],
    lateral80G: [0.95, 1.2]
  }
});
var SPORTS_SEDAN_RS5 = defineVehicle({
  id: "rs5",
  name: "RS-5 SPORTS SEDAN",
  classId: "road",
  brief: "Four-door sports sedan: 3.0 L twin-turbo straight-six, about 375 kW, 1820 kg, rear-biased all-wheel drive (30% forward through a clutch-pack centre), electronic rear differential, seven-speed automatic. Intended skill: novice\u2013intermediate. Strengths: launch, torque, all-weather traction. Weaknesses: mass in braking zones and direction changes, body roll. Targets: 0\u2013100 about 3.7 s, about 300 km/h, about 1.1 g at 80 km/h.",
  mass: 1820,
  frontWeight: 0.53,
  cogHeight: 0.52,
  wheelbase: 2.86,
  trackFront: 1.62,
  trackRear: 1.6,
  width: 1.9,
  height: 1.43,
  overhangFront: 0.95,
  overhangRear: 1,
  groundClearance: 0.12,
  wheelRadius: 0.35,
  wheelInertia: 2,
  linkCentreHeight: 0.2,
  maxSteer: 0.5,
  finalDrive: 3.2,
  gearRatios: [-3.4, 0, 3.6, 2.5, 1.82, 1.44, 1.2, 1.06, 0.97],
  idleRPM: 750,
  shiftRPM: 7e3,
  downshiftRPM: 2800,
  limiterRPM: 7200,
  torqueCurve: [
    [1800, 520],
    [2500, 620],
    [5800, 650],
    [6500, 560],
    [7e3, 500],
    [7200, 460]
  ],
  engine: combustion(3, 1e3, 0.24),
  brakeTorque: 11e3,
  aero: { clA: 0.2, cdA: 0.78, balance: 0.45 },
  tireFamily: "road",
  tireGrip: 0.75,
  rearGrip: 1.08,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(150, 0.3, 0.3), frontShare: 0.3 },
    front: lsd(30, 0.2, 0.1),
    rear: lsd(80, 0.4, 0.25)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 95e3, rearSpring: 1e5, frontARB: 26e3, rearARB: 2e4 },
  ai: {
    ...ROAD_AI,
    lateralBase: 10.31,
    lateralAero: 59e-5,
    brakingBase: 11.59,
    brakingAero: 47e-5,
    topSpeed: 84,
    lateralMargin: 0.7,
    slowLateralMargin: 0.62,
    brakingMargin: 0.7,
    lineScale: 0.75
  },
  bands: {
    accel0to100: [3.3, 4.3],
    topSpeed: [285, 310],
    braking100Distance: [31, 40],
    lateral80G: [1, 1.25]
  }
});
var MUSCLE_COUPE_RM8 = defineVehicle({
  id: "rm8",
  name: "RM-8 MUSCLE COUPE",
  classId: "road",
  brief: "Front-engined muscle coupe: 5.0 L naturally aspirated cross-plane V8, about 340 kW at 7000 rpm, 1820 kg, rear drive through a clutch-pack differential, six-speed manual. Intended skill: intermediate. Strengths: torque, a long-legged top gear, rear-drive drifts on demand. Weaknesses: weight and a nose-heavy balance, wheelspin from rest, brakes that fade. Targets: 0\u2013100 about 4.6 s, about 280 km/h, about 1.05 g at 80 km/h.",
  mass: 1820,
  frontWeight: 0.53,
  cogHeight: 0.53,
  wheelbase: 2.72,
  trackFront: 1.6,
  trackRear: 1.62,
  width: 1.92,
  height: 1.38,
  overhangFront: 1.05,
  overhangRear: 1.05,
  groundClearance: 0.12,
  wheelRadius: 0.35,
  wheelInertia: 2,
  linkCentreHeight: 0.2,
  maxSteer: 0.5,
  finalDrive: 3.55,
  gearRatios: [-3, 0, 3, 2.1, 1.6, 1.25, 1, 0.75],
  idleRPM: 700,
  shiftRPM: 7300,
  downshiftRPM: 3e3,
  limiterRPM: 7500,
  torqueCurve: [
    [1500, 420],
    [3e3, 500],
    [4500, 540],
    [5500, 530],
    [7e3, 465],
    [7500, 420]
  ],
  engine: combustion(5, 900, 0.3),
  brakeTorque: 1e4,
  aero: { clA: 0.05, cdA: 0.86, balance: 0.4 },
  tireFamily: "road",
  tireGrip: 0.73,
  rearGrip: 1.08,
  drivetrain: "rwd",
  driveline: { rear: lsd(60, 0.4, 0.2) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 9e4, rearSpring: 85e3, frontARB: 24e3, rearARB: 14e3 },
  ai: {
    ...ROAD_AI,
    lateralBase: 10.36,
    lateralAero: 0,
    brakingBase: 11.31,
    brakingAero: 0,
    topSpeed: 82,
    lateralMargin: 0.7,
    slowLateralMargin: 0.62,
    brakingMargin: 0.7,
    lineScale: 0.75
  },
  bands: {
    accel0to100: [4, 5.4],
    topSpeed: [265, 300],
    braking100Distance: [32, 42],
    lateral80G: [0.95, 1.2]
  }
});
var CLASSIC_GT_RG63 = defineVehicle({
  id: "rg63",
  name: "RG-63 CLASSIC GRAND TOURER",
  classId: "road",
  brief: "A 1963-style front-engined grand tourer: 3.0 L V12 on six carburettors, about 220 kW at 7500 rpm, 1250 kg with driver, five-speed, cross-ply tyres on wire wheels, discs all round, no aerodynamic downforce. Intended skill: intermediate. Strengths: a sweet, high-revving engine and a long-legged top speed. Weaknesses: narrow tyres, long braking, roll, front lift at speed. Targets: 0\u2013100 about 6.5 s, about 265 km/h, about 0.95 g at 80 km/h.",
  mass: 1250,
  frontWeight: 0.5,
  cogHeight: 0.5,
  wheelbase: 2.4,
  trackFront: 1.36,
  trackRear: 1.36,
  width: 1.7,
  height: 1.25,
  overhangFront: 0.95,
  overhangRear: 0.95,
  groundClearance: 0.13,
  wheelRadius: 0.32,
  wheelInertia: 1.4,
  linkCentreHeight: 0.22,
  maxSteer: 0.5,
  finalDrive: 3.6,
  gearRatios: [-3, 0, 2.3, 1.65, 1.25, 1.06, 0.95],
  idleRPM: 800,
  shiftRPM: 7600,
  downshiftRPM: 3600,
  limiterRPM: 7800,
  torqueCurve: [
    [2e3, 220],
    [4e3, 290],
    [5500, 310],
    [6500, 300],
    [7500, 280],
    [7800, 250]
  ],
  engine: combustion(3, 500, 0.2),
  brakeTorque: 4200,
  aero: { clA: 0, cdA: 0.72, balance: 0.5 },
  tireFamily: "historic",
  tireGrip: 0.62,
  rearGrip: 1.08,
  drivetrain: "rwd",
  driveline: { rear: lsd(40, 0.3, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: {
    frontSpring: 6e4,
    rearSpring: 6e4,
    frontARB: 14e3,
    rearARB: 6e3,
    brakeBias: 0.62
  },
  ai: {
    ...ROAD_AI,
    lateralBase: 9.21,
    lateralAero: 0,
    brakingBase: 10.29,
    brakingAero: 0,
    topSpeed: 74,
    lateralMargin: 0.68,
    slowLateralMargin: 0.6,
    brakingMargin: 0.68,
    lineScale: 0.75
  },
  bands: {
    accel0to100: [5.6, 7.6],
    topSpeed: [250, 285],
    braking100Distance: [36, 52],
    lateral80G: [0.85, 1.1]
  }
});
var PICKUP_RP6 = defineVehicle({
  id: "rp6",
  name: "RP-6 DESERT PICKUP",
  classId: "road",
  brief: "High-performance pickup truck: 3.5 L twin-turbo V6, about 335 kW, 2650 kg, full-time four-wheel drive (40% forward through a clutch-pack centre, open front, locking rear), long-travel springs, 35-inch all-terrain tyres. Intended skill: novice. Strengths: goes anywhere, torque, the ride over rough ground. Weaknesses: mass, a very high centre of gravity and body roll, long braking, gearing-limited top speed. Targets: 0\u2013100 about 6 s, about 180 km/h, about 0.85 g at 80 km/h.",
  mass: 2650,
  frontWeight: 0.56,
  cogHeight: 0.78,
  wheelbase: 3.7,
  trackFront: 1.75,
  trackRear: 1.75,
  width: 2.2,
  height: 1.98,
  overhangFront: 1,
  overhangRear: 1.35,
  groundClearance: 0.3,
  wheelRadius: 0.43,
  wheelInertia: 5,
  restLength: 0.4,
  linkCentreHeight: 0.38,
  maxSteer: 0.5,
  finalDrive: 4.1,
  gearRatios: [-3.2, 0, 3.5, 2.5, 1.88, 1.56, 1.4, 1.3],
  idleRPM: 700,
  shiftRPM: 6e3,
  downshiftRPM: 2500,
  limiterRPM: 6200,
  torqueCurve: [
    [1500, 450],
    [3e3, 700],
    [4500, 760],
    [5500, 600],
    [6e3, 530],
    [6200, 480]
  ],
  engine: combustion(3.5, 1100, 0.3),
  brakeTorque: 14e3,
  aero: { clA: 0, cdA: 1.55, balance: 0.5 },
  tireFamily: "all-terrain",
  tireGrip: 0.62,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(200, 0.4, 0.3), frontShare: 0.4 },
    front: OPEN,
    rear: lsd(150, 0.5, 0.3)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 11e4, rearSpring: 12e4, frontARB: 18e3, rearARB: 1e4 },
  elementMass: [6, 6],
  ai: {
    ...ROAD_AI,
    lateralBase: 8.66,
    lateralAero: 0,
    brakingBase: 9.12,
    brakingAero: 0,
    topSpeed: 52,
    lineScale: 0.75
  },
  bands: {
    accel0to100: [5, 7],
    topSpeed: [170, 190],
    braking100Distance: [38, 54],
    lateral80G: [0.75, 0.98]
  }
});
var RALLY_ROAD_RR4 = defineVehicle({
  id: "rr4",
  name: "RR-4 RALLY-BRED ROAD CAR",
  classId: "road",
  brief: "Rally-bred road car (a homologation special): 2.5 L turbocharged flat-four, about 228 kW, 1600 kg, permanent four-wheel drive with a clutch-pack centre sending 41% forward, bonnet scoop and rear wing, six-speed. Intended skill: novice\u2013intermediate. Strengths: traction on any surface, adjustable on the brakes, sturdy suspension. Weaknesses: turbo lag, understeer on power, modest top speed. Targets: 0\u2013100 about 5 s, about 255 km/h, about 1.05 g at 80 km/h.",
  mass: 1600,
  frontWeight: 0.58,
  cogHeight: 0.52,
  wheelbase: 2.65,
  trackFront: 1.53,
  trackRear: 1.55,
  width: 1.8,
  height: 1.47,
  overhangFront: 0.95,
  overhangRear: 0.86,
  groundClearance: 0.14,
  wheelRadius: 0.33,
  wheelInertia: 1.5,
  restLength: 0.27,
  linkCentreHeight: 0.22,
  maxSteer: 0.5,
  finalDrive: 3.9,
  gearRatios: [-3.4, 0, 3.6, 2.2, 1.52, 1.16, 0.97, 0.78],
  idleRPM: 800,
  shiftRPM: 6500,
  downshiftRPM: 3e3,
  limiterRPM: 6700,
  torqueCurve: [
    [2e3, 330],
    [3500, 420],
    [4500, 420],
    [5500, 380],
    [6400, 340],
    [6700, 300]
  ],
  engine: combustion(2.5, 650, 0.2),
  turbo: { boostShare: 0.4, spoolTime: 0.45, dumpFraction: 0.3, spoolRPM: [800, 1600] },
  brakeTorque: 9e3,
  aero: { clA: 0.1, cdA: 0.8, balance: 0.5 },
  tireFamily: "road",
  tireGrip: 0.74,
  drivetrain: "awd",
  driveline: {
    centre: { ...lsd(100, 0.4, 0.3), frontShare: 0.41 },
    front: lsd(30, 0.25, 0.1),
    rear: lsd(80, 0.4, 0.25)
  },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 85e3, rearSpring: 85e3, frontARB: 2e4, rearARB: 18e3 },
  ai: {
    ...ROAD_AI,
    lateralBase: 10.41,
    lateralAero: 49e-5,
    brakingBase: 11.34,
    brakingAero: 48e-5,
    topSpeed: 74
  },
  bands: {
    accel0to100: [4.4, 5.8],
    topSpeed: [240, 270],
    braking100Distance: [32, 42],
    lateral80G: [0.95, 1.2]
  }
});
var LUXURY_GT_LX12 = defineVehicle({
  id: "lx12",
  name: "LX-12 LUXURY GT",
  classId: "road",
  brief: "Luxury grand tourer: 5.2 L twin-turbo V12, about 470 kW and 900 N m, 2080 kg, rear drive with an electronic differential, eight-speed automatic, a long 2+2 cabin. Intended skill: novice. Strengths: effortless torque and top speed, stability. Weaknesses: mass in every corner, wheelspin from rest, long braking. Targets: 0\u2013100 about 3.7 s, about 325 km/h, about 1.05 g at 80 km/h.",
  mass: 2080,
  frontWeight: 0.47,
  cogHeight: 0.5,
  wheelbase: 2.95,
  trackFront: 1.68,
  trackRear: 1.66,
  width: 1.98,
  height: 1.29,
  overhangFront: 1,
  overhangRear: 1.05,
  groundClearance: 0.12,
  wheelRadius: 0.36,
  wheelInertia: 2.2,
  linkCentreHeight: 0.2,
  maxSteer: 0.48,
  finalDrive: 2.93,
  gearRatios: [-3.3, 0, 4.7, 2.95, 2.05, 1.62, 1.27, 1, 0.84, 0.67],
  idleRPM: 650,
  shiftRPM: 6800,
  downshiftRPM: 2600,
  limiterRPM: 7e3,
  torqueCurve: [
    [1500, 700],
    [2e3, 900],
    [5e3, 900],
    [6e3, 750],
    [6500, 680],
    [7e3, 600]
  ],
  engine: combustion(5.2, 1300, 0.32),
  brakeTorque: 8200,
  aero: { clA: 0.15, cdA: 0.88, balance: 0.45 },
  tireFamily: "road",
  tireGrip: 0.69,
  rearGrip: 1.25,
  drivetrain: "rwd",
  driveline: { rear: lsd(70, 0.35, 0.2) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 1e5, rearSpring: 105e3, frontARB: 26e3, rearARB: 18e3 },
  ai: {
    ...ROAD_AI,
    lateralBase: 9.51,
    lateralAero: 42e-5,
    brakingBase: 10.95,
    brakingAero: 17e-5,
    topSpeed: 92
  },
  bands: {
    accel0to100: [3.2, 4.2],
    topSpeed: [310, 345],
    braking100Distance: [32, 40],
    lateral80G: [0.95, 1.2]
  }
});
var ROADSTER_RD2 = defineVehicle({
  id: "rd2",
  name: "RD-2 ROADSTER",
  classId: "road",
  brief: "Light front-mid-engined road roadster: 2.0 L naturally aspirated four, about 135 kW at 7000 rpm, 1110 kg, rear drive through a clutch-pack differential, six-speed manual, soft top. Intended skill: novice. Strengths: balance, steering feel, low running cost, easy drifts. Weaknesses: modest power and top speed, roll on road springs. Targets: 0\u2013100 about 6.8 s, about 225 km/h, about 1.05 g at 80 km/h.",
  mass: 1110,
  frontWeight: 0.5,
  cogHeight: 0.46,
  wheelbase: 2.31,
  trackFront: 1.5,
  trackRear: 1.5,
  width: 1.73,
  height: 1.23,
  overhangFront: 0.8,
  overhangRear: 0.8,
  groundClearance: 0.13,
  wheelRadius: 0.31,
  wheelInertia: 1.1,
  linkCentreHeight: 0.2,
  maxSteer: 0.5,
  finalDrive: 3.6,
  gearRatios: [-3.4, 0, 3.8, 2.3, 1.55, 1.2, 1, 0.84],
  idleRPM: 800,
  shiftRPM: 7300,
  downshiftRPM: 3200,
  limiterRPM: 7500,
  torqueCurve: [
    [2e3, 170],
    [4e3, 200],
    [5e3, 205],
    [6e3, 195],
    [7e3, 184],
    [7500, 160]
  ],
  engine: combustion(2, 400, 0.16),
  brakeTorque: 4200,
  aero: { clA: 0, cdA: 0.68, balance: 0.5 },
  tireFamily: "road",
  tireGrip: 0.72,
  drivetrain: "rwd",
  driveline: { rear: lsd(30, 0.3, 0.15) },
  setupKeys: KEYS.fixedChassis,
  setupDefaults: { frontSpring: 65e3, rearSpring: 6e4, frontARB: 16e3, rearARB: 8e3 },
  ai: {
    ...ROAD_AI,
    lateralBase: 11.2,
    lateralAero: 0,
    brakingBase: 11.06,
    brakingAero: 0,
    topSpeed: 65
  },
  bands: {
    accel0to100: [6, 7.6],
    topSpeed: [210, 240],
    braking100Distance: [32, 42],
    lateral80G: [0.95, 1.2]
  }
});

// actual-source:src/simulation/vehicle-catalogue/index.ts
var BUILT = catalogue([
  JUNIOR_FORMULA,
  HISTORIC_FORMULA,
  HYPERCAR,
  PROTOTYPE,
  GT_FRONT_V8,
  GT_MID_V10,
  GT_SPORT,
  TOURING_TC2,
  CLUB_ROADSTER,
  RALLY_CAR,
  RALLYCROSS_CAR,
  TROPHY_TRUCK,
  SHIFTER_KART,
  ELECTRIC_HYPERCAR,
  SUPERCAR,
  // Catalogue growth (CONTENT_PIPELINE.md §1.3): appended in this order.
  FORMULA_FX26,
  FEEDER_FR3,
  ENTRY_FE4,
  HISTORIC_HF76,
  HISTORIC_HF86,
  HYPERCAR_HY11,
  PROTOTYPE_PR3,
  HISTORIC_SP71,
  GT_REAR_FLAT6,
  GT_FRONT_I6,
  GT_SPORT_MID_V6,
  TOURING_TC3,
  HOT_HATCH_HH2,
  VINTAGE_VC62,
  CLASSIC_RALLY_RL7,
  GROUP_RALLY_GB4,
  ELECTRIC_RALLYCROSS_RXE,
  DESERT_BUGGY_BG2,
  DIRECT_KART_DK100,
  FAN_CAR_XF2,
  ELECTRIC_TIME_ATTACK_XE1,
  HYDROGEN_XH3,
  TRACK_HYPERCAR_XT1,
  HOT_HATCH_RH3,
  SPORTS_SEDAN_RS5,
  MUSCLE_COUPE_RM8,
  CLASSIC_GT_RG63,
  PICKUP_RP6,
  RALLY_ROAD_RR4,
  LUXURY_GT_LX12,
  ROADSTER_RD2
]);
var CATALOGUE = BUILT.definitions;
var CATALOGUE_BANDS = BUILT.bands;
var CATALOGUE_BRIEFS = BUILT.briefs;

// actual-source:src/simulation/offroad/dirt-bikes.ts
var MX_AIR = Object.freeze({
  progression: 2.2,
  forkDamping: 1400,
  shockDamping: 1600,
  damperKnee: 2.2,
  pitchInertia: 105,
  spinInertia: 0.62,
  spinUp: 95,
  spinBrake: 260,
  bodyTorque: 85,
  noseDownLimit: 0.46,
  noseUpLimit: 0.62,
  bottomOutSpeed: 7,
  dabSpeed: 6.5,
  dabLean: 0.42
});
var MX450 = Object.freeze({
  riderMass: 75,
  fuel: 5.5,
  cgHeight: 0.86,
  cgToFront: 0.75,
  cgToRear: 0.73,
  frontWheelRadius: 0.355,
  rearWheelRadius: 0.345,
  crownRadius: 0.062,
  maxSteer: 0.72,
  steerRate: 3.4,
  maxLean: 0.95,
  mu: 1.12,
  frontBrake: 2300,
  rearBrake: 950,
  drag: 0.4,
  tuckDrag: 0.02,
  downforce: 0,
  downforceFront: 0.5,
  rolling: 0.024,
  riderOffsetMax: 0.12,
  drivelineEfficiency: 0.9,
  gearbox: "quickshifter",
  shiftCut: 0.06,
  launchRPM: 7e3,
  wheelieLimit: 0.2,
  stoppieMargin: 0.86,
  forkTravel: 0.3,
  forkRate: 9400,
  shockTravel: 0.3,
  shockRate: 9800,
  // Bar-to-bar contact and soft tyre walls are part of racing in the dirt.
  crashEnergy: 3200,
  offroad: MX_AIR
});
var MX250 = Object.freeze({
  ...MX450,
  riderMass: 75,
  fuel: 6,
  cgHeight: 0.85,
  cgToFront: 0.75,
  cgToRear: 0.73,
  mu: 1.12,
  frontBrake: 2200,
  rearBrake: 900,
  launchRPM: 9e3,
  forkRate: 9e3,
  shockRate: 9400,
  offroad: Object.freeze({ ...MX_AIR, pitchInertia: 98, spinInertia: 0.52, spinUp: 120 })
});
var SM450 = Object.freeze({
  ...MX450,
  fuel: 6,
  cgHeight: 0.82,
  cgToFront: 0.73,
  cgToRear: 0.72,
  frontWheelRadius: 0.3,
  rearWheelRadius: 0.31,
  crownRadius: 0.075,
  maxSteer: 0.62,
  maxLean: 0.98,
  mu: 1.38,
  frontBrake: 3300,
  rearBrake: 1e3,
  drag: 0.36,
  forkTravel: 0.27,
  forkRate: 11500,
  shockTravel: 0.28,
  shockRate: 12e3,
  wheelieLimit: 0.15,
  stoppieMargin: 0.9,
  offroad: Object.freeze({ ...MX_AIR, noseDownLimit: 0.4, bottomOutSpeed: 6.5 })
});
function dirtEnvelope(b, wheelbase, mass, top) {
  return Object.freeze({
    ...bikeEnvelope(b, wheelbase, mass, top),
    brakingMargin: 0.5,
    lateralMargin: 0.8,
    slowLateralMargin: 0.74
  });
}
var stations = Object.freeze({
  floorY: -0.6,
  damageZ: 0.62,
  frontElement: Object.freeze([1, 0.5]),
  rearElement: Object.freeze([-1, 0.6]),
  jackZ: Object.freeze([-0.8, 0.7]),
  jackX: 0.1
});
var wheels2 = (b) => Object.freeze([
  Object.freeze([0, b.frontWheelRadius - b.cgHeight, b.cgToFront]),
  Object.freeze([0, b.frontWheelRadius - b.cgHeight, b.cgToFront]),
  Object.freeze([0, b.rearWheelRadius - b.cgHeight, -b.cgToRear]),
  Object.freeze([0, b.rearWheelRadius - b.cgHeight, -b.cgToRear])
]);
var curve = (points) => Object.freeze(points.map((p) => Object.freeze(p)));
var MX_450 = Object.freeze({
  id: "mx450",
  version: 1,
  name: "MX-450 MOTOCROSS",
  classId: "motocross",
  dynamicsKind: "bike",
  spec: Object.freeze({
    dryMass: 104 + MX450.riderMass,
    wheelRadius: MX450.rearWheelRadius,
    wheelInertia: 0.7,
    wheelbase: 1.48,
    track: 0,
    inertia: Object.freeze([60, 52, 22]),
    restLength: 0.3,
    linkCentreHeight: 0.3,
    travel: MX450.forkTravel,
    maxSteer: MX450.maxSteer,
    finalDrive: 4,
    // Fifth is long enough to reach a 450's real top end (about 140 km/h on a long straight): the
    // old 3.12 capped it at 125 km/h against the rev limiter, below the 250 two-stroke. First to
    // fourth, where every moto and jump is ridden, are unchanged (a longer fourth changed which
    // riders fell in the seeded Valley Ridge moto, which never reaches fifth).
    gearRatios: Object.freeze([0, 0, 7.8, 5.73, 4.53, 3.72, 2.78]),
    idleRPM: 1800,
    shiftRPM: 11300,
    downshiftRPM: 6200,
    limiterRPM: 12e3,
    maxBatteryJ: 0,
    motorPowerW: 47e3,
    regenPowerW: 0,
    brakeTorque: MX450.frontBrake * MX450.frontWheelRadius,
    airDensity: 1.225,
    torqueCurve: curve([
      [3e3, 30],
      [5e3, 42],
      [7e3, 49],
      [8500, 50],
      [9500, 47],
      [10500, 41],
      [12e3, 31]
    ])
  }),
  wheelPositions: wheels2(MX450),
  drivetrain: "rwd",
  aero: Object.freeze({ downforce: 0, drag: 1, frontZ: 0.55, rearZ: -0.55 }),
  halfExtents: Object.freeze([0.42, 0.62, 1.08]),
  stations,
  tireGrip: 1,
  tireFamily: "knobby",
  hybrid: false,
  drs: false,
  setupKeys: BIKE_SETUP_KEYS.offroad,
  ai: dirtEnvelope(MX450, 1.48, 104 + 75 + 5.5, 34),
  bike: MX450
});
var MX_250 = Object.freeze({
  ...MX_450,
  id: "mx250",
  name: "MX-250 TWO-STROKE",
  spec: Object.freeze({
    ...MX_450.spec,
    dryMass: 97 + MX250.riderMass,
    wheelInertia: 0.65,
    finalDrive: 4.3,
    gearRatios: Object.freeze([0, 0, 7.7, 5.75, 4.6, 3.8, 3.2]),
    idleRPM: 2200,
    shiftRPM: 12900,
    downshiftRPM: 8200,
    limiterRPM: 13600,
    motorPowerW: 36e3,
    brakeTorque: MX250.frontBrake * MX250.frontWheelRadius,
    torqueCurve: curve([
      [4e3, 14],
      [7e3, 22],
      [9e3, 29],
      [10500, 31],
      [11500, 30],
      [12500, 25],
      [13600, 18]
    ])
  }),
  wheelPositions: wheels2(MX250),
  ai: dirtEnvelope(MX250, 1.48, 97 + 75 + 6, 33),
  bike: MX250
});
var SM_450 = Object.freeze({
  ...MX_450,
  id: "sm450",
  name: "SM-450 SUPERMOTO",
  classId: "supermoto",
  spec: Object.freeze({
    ...MX_450.spec,
    dryMass: 108 + SM450.riderMass,
    wheelRadius: SM450.rearWheelRadius,
    wheelInertia: 0.75,
    wheelbase: 1.45,
    travel: SM450.forkTravel,
    maxSteer: SM450.maxSteer,
    finalDrive: 3.4,
    gearRatios: Object.freeze([0, 0, 7.4, 5.5, 4.4, 3.65, 3.1, 2.75]),
    brakeTorque: SM450.frontBrake * SM450.frontWheelRadius
  }),
  wheelPositions: wheels2(SM450),
  halfExtents: Object.freeze([0.42, 0.6, 1.06]),
  tireFamily: "supermoto",
  ai: dirtEnvelope(SM450, 1.45, 108 + 75 + 6, 41),
  bike: SM450
});
var DIRT_BIKES = Object.freeze({
  mx450: MX_450,
  mx250: MX_250,
  sm450: SM_450
});

// actual-source:src/simulation/vehicles.ts
var FORMULA_SPEC = Object.freeze({
  dryMass: 770,
  wheelRadius: 0.335,
  wheelInertia: 1.8,
  wheelbase: 3.44,
  track: 1.66,
  inertia: [510, 1220, 1080],
  restLength: 0.25,
  /** Height above the contact patch where tread forces enter the chassis (m). */
  linkCentreHeight: 0.26,
  travel: 0.17,
  maxSteer: 0.38,
  finalDrive: 3.7,
  gearRatios: [-3.1, 0, 3.3, 2.8, 2.35, 2.02, 1.78, 1.59, 1.44, 1.31],
  idleRPM: 4200,
  shiftRPM: 12300,
  downshiftRPM: 6900,
  limiterRPM: 13700,
  maxBatteryJ: 4e6,
  motorPowerW: 1e5,
  regenPowerW: 7e4,
  brakeTorque: 13200,
  airDensity: 1.225,
  torqueCurve: [
    [4e3, 360],
    [6500, 460],
    [9e3, 510],
    [11e3, 490],
    [12500, 450],
    [13700, 360]
  ]
});
var FORMULA_WHEELS = Object.freeze([
  Object.freeze([-0.83, 0.05, 1.82]),
  Object.freeze([0.83, 0.05, 1.82]),
  Object.freeze([-0.83, 0.05, -1.62]),
  Object.freeze([0.83, 0.05, -1.62])
]);
var FORMULA_ENVELOPE = Object.freeze({
  lateralBase: 15.95,
  lateralAero: 548e-5,
  brakingBase: 19.9,
  brakingAero: 56e-4,
  lateralMargin: 0.72,
  slowLateralMargin: 0.62,
  brakingMargin: 0.55,
  topSpeed: 92,
  referenceMu: 1.82,
  downforceReference: 794
});
var FORMULA_APX01 = Object.freeze({
  id: "apx01",
  version: 1,
  name: "APX-01 FORMULA",
  classId: "formula",
  dynamicsKind: "four-wheel",
  spec: FORMULA_SPEC,
  wheelPositions: FORMULA_WHEELS,
  drivetrain: "rwd",
  aero: Object.freeze({ downforce: 1, drag: 1, frontZ: 1.7, rearZ: -1.6 }),
  halfExtents: Object.freeze([0.94, 0.38, 2.5]),
  stations: Object.freeze({
    floorY: -0.43,
    damageZ: 1.35,
    frontElement: Object.freeze([2.5, 4.5]),
    rearElement: Object.freeze([-2.1, 6]),
    jackZ: Object.freeze([-1.4, 1.5]),
    jackX: 0.38
  }),
  tireGrip: 1,
  hybrid: true,
  drs: true,
  setupKeys: Object.freeze([
    "frontWing",
    "rearWing",
    "brakeBias",
    "diffPower",
    "diffCoast",
    "frontSpring",
    "rearSpring",
    "frontARB",
    "rearARB",
    "frontRide",
    "rearRide",
    "frontPressure",
    "rearPressure",
    "frontCamber",
    "rearCamber",
    "frontToe",
    "rearToe"
  ]),
  ai: FORMULA_ENVELOPE
});
var TOURING_TC1 = Object.freeze({
  id: "tc1",
  version: 1,
  name: "TC-1 TOURING",
  classId: "touring",
  dynamicsKind: "four-wheel",
  spec: Object.freeze({
    dryMass: 1265,
    wheelRadius: 0.318,
    wheelInertia: 1.35,
    wheelbase: 2.7,
    track: 1.56,
    inertia: Object.freeze([560, 2150, 1950]),
    restLength: 0.25,
    linkCentreHeight: 0.34,
    travel: 0.17,
    maxSteer: 0.48,
    finalDrive: 4.1,
    gearRatios: Object.freeze([-3.2, 0, 3.2, 2.3, 1.78, 1.43, 1.19, 1]),
    idleRPM: 1600,
    shiftRPM: 7600,
    downshiftRPM: 3900,
    limiterRPM: 8100,
    maxBatteryJ: 0,
    motorPowerW: 0,
    regenPowerW: 0,
    brakeTorque: 9200,
    airDensity: 1.225,
    torqueCurve: Object.freeze([
      Object.freeze([1500, 215]),
      Object.freeze([3e3, 305]),
      Object.freeze([4500, 350]),
      Object.freeze([6e3, 335]),
      Object.freeze([7200, 305]),
      Object.freeze([8100, 250])
    ])
  }),
  wheelPositions: Object.freeze([
    Object.freeze([-0.78, 0.05, 1.12]),
    Object.freeze([0.78, 0.05, 1.12]),
    Object.freeze([-0.78, 0.05, -1.58]),
    Object.freeze([0.78, 0.05, -1.58])
  ]),
  drivetrain: "fwd",
  aero: Object.freeze({ downforce: 0.08, drag: 0.62, frontZ: 1.3, rearZ: -1.7 }),
  halfExtents: Object.freeze([0.9, 0.55, 2.25]),
  stations: Object.freeze({
    floorY: -0.4,
    damageZ: 1.25,
    frontElement: Object.freeze([2.2, 3.5]),
    rearElement: Object.freeze([-2.2, 4]),
    jackZ: Object.freeze([-1.3, 1]),
    jackX: 0.45
  }),
  tireGrip: 0.8,
  hybrid: false,
  drs: false,
  setupKeys: Object.freeze([
    "brakeBias",
    "diffPower",
    "diffCoast",
    "frontSpring",
    "rearSpring",
    "frontARB",
    "rearARB",
    "frontRide",
    "rearRide",
    "frontPressure",
    "rearPressure",
    "frontCamber",
    "rearCamber",
    "frontToe",
    "rearToe"
  ]),
  ai: Object.freeze({
    lateralBase: 12.7,
    lateralAero: 0,
    brakingBase: 13.4,
    brakingAero: 0,
    lateralMargin: 0.74,
    slowLateralMargin: 0.66,
    brakingMargin: 0.6,
    topSpeed: 66,
    referenceMu: 1.82,
    downforceReference: 0
  })
});
var VEHICLES = Object.freeze({
  apx01: FORMULA_APX01,
  tc1: TOURING_TC1,
  ...BIKE_VEHICLES,
  ...CATALOGUE,
  ...BIKE_ADDITIONS,
  // Off-road motorcycles (WP39), appended after the catalogue and bikes.
  ...DIRT_BIKES
});
var VEHICLE_IDS = Object.freeze(Object.keys(VEHICLES));
var VEHICLE_INDICES = new Map(VEHICLE_IDS.map((id, index) => [id, index]));

// actual-source:src/simulation/protocol.ts
var HEADER = 24;
var CAR_STRIDE = 331;
var WHEEL_BASE = 96;
var WHEEL_STRIDE = 26;
var DEBRIS_BASE = 200;
var DEBRIS_STRIDE = 8;
var SKID_BASE = 232;
var SKID_STRIDE = 17;
var RACE_BASE = 249;
var RACE_STRIDE = 8;
var BIKE_BASE = 257;
var BIKE_STRIDE = 20;
var OFFROAD_BASE = 277;
var OFFROAD_STRIDE = 16;
var WHEEL_MOTION_BASE = 293;
var WHEEL_MOTION_STRIDE = 5;
var WHEEL_CONTACT_BASE = 298;
var WHEEL_CONTACT_STRIDE = 8;
var WHEEL_CONTACT_SIZE = 1 + 4 * WHEEL_CONTACT_STRIDE;
var PROTOCOL_VERSION = 17;
var MX_FOOT = {
  ANGLE: WHEEL_CONTACT_BASE + 1,
  COVER: WHEEL_CONTACT_BASE + 2,
  CLEAR: WHEEL_CONTACT_BASE + 3
};
var R = {
  DRS: 0,
  DRS_ELIGIBLE: 1,
  TYRE_AGE_LAPS: 2,
  NEXT_COMPOUND: 3,
  OVERTAKE: 4,
  SECTOR_STATUS: 5,
  DRS_FLAP: 6,
  /** Vehicle definition index (vehicles.ts VEHICLE_IDS); 0 is the Formula APX-01. */
  VEHICLE: 7
};
var B = {
  LEAN: 0,
  LEAN_RATE: 1,
  /** Handlebar steer angle (rad). */
  STEER: 2,
  /** Rider hang-off from the bike centreline (m, + left). */
  RIDER_OFFSET: 3,
  /** BIKE_STATES index: riding, lowside, highside, separated, remount. */
  STATE: 4,
  STATE_CLOCK: 5,
  FRONT_LOAD: 6,
  REAR_LOAD: 7,
  /** Wheelie (+) / stoppie (-) pitch (rad). */
  PITCH: 8,
  FORK: 9,
  SHOCK: 10,
  RIDER_X: 11,
  RIDER_Y: 12,
  RIDER_Z: 13,
  /** Rider tuck behind the screen, 0..1. */
  TUCK: 14,
  REAR_BRAKE: 15,
  CRASHES: 16,
  /** Traction/wheelie-control intervention 0..1. */
  INTERVENTION: 17,
  /** Separated rider's heading and tumble, or upright MX stride phase (rad). */
  RIDER_HEADING: 18,
  RIDER_TUMBLE: 19
};
var O = {
  /** 1 while no wheel carries load (flight). */
  AIRBORNE: 0,
  /** Seconds of the current (or last) flight. */
  AIR_TIME: 1,
  /** Rider standing on the pegs, or rising to their feet after an MX fall, 0..1. */
  STANDING: 2,
  /** Foot dab: -1 right foot .. +1 left foot down, 0 both on the pegs. */
  DAB: 3,
  /** Suspension bottoming intensity 0..1 (decays after the event). */
  BOTTOM: 4,
  /** Pitch error of the last landing against the ground slope (rad, nose-up +). */
  LANDING_PITCH: 5,
  /** Normal impact speed of the last landing (m/s). */
  LANDING_SPEED: 6,
  /** Rider body position fore/aft, -1 back .. +1 forward. */
  BODY: 7,
  /** Mud carried by machine and rider, 0 clean .. 1 caked. */
  MUD: 8,
  /** Rut depth under the front / rear contact (m). */
  RUT_FRONT: 9,
  RUT_REAR: 10,
  /** Soil moisture under the machine 0..1. */
  MOISTURE: 11,
  /** Joker laps taken (rallycross). */
  JOKERS: 12,
  /** Start state: 0 none, 1 held at the gate/control, 2 released, 3 jump start. */
  START: 13,
  /** Gate slot + 1 (gate starts) or start order + 1 (staggered stage starts). */
  SLOT: 14,
  /** Holeshot taken (1) / stage time so far or final (s) for stages (negative: not started). */
  FORMAT: 15
};
var WHEEL_NAMES = ["FR", "FL", "RR", "RL"];
var K = {
  CONTACTS: 0,
  LOAD: 1,
  SLIDE_POWER: 2,
  DAMPING_POWER: 3,
  SPARK_POWER: 4,
  SPARK_X: 5,
  SPARK_Y: 6,
  SPARK_Z: 7,
  NORMAL_X: 8,
  NORMAL_Y: 9,
  NORMAL_Z: 10,
  VELOCITY_X: 11,
  VELOCITY_Y: 12,
  VELOCITY_Z: 13,
  SLIDE_WORK: 14,
  SPARK_WORK: 15,
  TOTAL_WORK: 16
};
var H = {
  TIME: 0,
  PHASE: 1,
  RACE_TIME: 2,
  LIGHTS: 3,
  RAIN: 4,
  CLOUD: 5,
  /** Air temperature in C; also the precipitation phase (see above). */
  AMBIENT: 6,
  FLAG: 7,
  STEP_MS: 8,
  DROPPED: 9,
  WATER: 10,
  TICK: 11,
  CARS: 12,
  LENGTH: 13,
  WIND_X: 14,
  WIND_Z: 15,
  /** 0 none, 1 VSC, 2 safety car deployed, 3 safety car in this lap. */
  SC_PHASE: 16,
  SC_S: 17,
  SC_SPEED: 18,
  DRS_ENABLED: 19,
  LAP_LEADER: 20,
  FORMATION: 21,
  /** Particulate (fog, mist, dust) extinction per km BEYOND clear air, from
   * the weather's visibility (weather.ts particulateExtinctionPerKm); 0 for
   * clear air, so every older recording reads as clear. Rain's own extinction
   * is added by the consumer from H.RAIN. */
  EXTINCTION: 22,
  /** Share of that extinction that is mineral dust (0 droplets .. 1 dust). */
  DUST: 23
};
var F = {
  X: 0,
  Y: 1,
  Z: 2,
  QX: 3,
  QY: 4,
  QZ: 5,
  QW: 6,
  VX: 7,
  VY: 8,
  VZ: 9,
  WX: 10,
  WY: 11,
  WZ: 12,
  SPEED: 13,
  STEER: 14,
  RPM: 15,
  GEAR: 16,
  THROTTLE: 17,
  BRAKE: 18,
  FUEL: 19,
  BATTERY: 20,
  AERO_FRONT: 21,
  AERO_REAR: 22,
  DRAG: 23,
  FRONT_HEALTH: 24,
  FLOOR_HEALTH: 25,
  REAR_HEALTH: 26,
  S: 27,
  LATERAL: 28,
  LAPS: 29,
  LAP_TIME: 30,
  BEST_LAP: 31,
  LAST_LAP: 32,
  PENALTY: 33,
  PIT_PHASE: 34,
  IN_PIT: 35,
  AI_TARGET: 36,
  G_LONG: 37,
  G_LAT: 38,
  G_VERT: 39,
  RANK: 40,
  FINISH: 41,
  WAKE: 42,
  SLIP_ENERGY: 43,
  BOTTOM_ENERGY: 44,
  IMPACT: 45,
  COMPOUND: 46,
  PIT_STOPS: 47,
  MOTOR_POWER: 48,
  REGEN_POWER: 49,
  FRONT_RIDE: 50,
  REAR_RIDE: 51,
  BRAKE_BIAS: 52,
  DIFF_POWER: 53,
  DIFF_COAST: 54,
  ERS_MODE: 55,
  JACK_HEIGHT: 56,
  SIDEPOD_HEALTH: 57,
  LOST_MASS: 58,
  SUSPENSION_DAMAGE: 59,
  SECTOR: 60,
  SECTOR_1: 61,
  SECTOR_2: 62,
  SECTOR_3: 63,
  LAP_VALID: 64,
  WARNINGS: 65,
  PIT_YIELDING: 66,
  RETIRED: 67,
  MASS: 68,
  CLUTCH_PEDAL: 69,
  CLUTCH_ENGAGEMENT: 70,
  CLUTCH_TORQUE: 71,
  CLUTCH_SLIP_POWER: 72,
  ENGINE_TORQUE: 73,
  LOCAL_FLAG: 74,
  CAUTION_DISTANCE: 75,
  CAUTION_SPEED: 76,
  BLUE_CAR: 77,
  CONTROL_SEQUENCE: 78,
  CONTROL_PENALTIES: 79,
  PIT_CLOCK: 80,
  LAP_DELTA: 81,
  DELTA_VALID: 82,
  AI_STRESS: 83,
  AI_TIRE_CARE: 84,
  AI_ERROR_COUNT: 85,
  AI_STEER_ERROR: 86,
  AI_PEDAL_ERROR: 87,
  AI_DEFENDING: 88,
  AI_PACE: 89,
  MARBLE_PICKUP_FR: 90,
  MARBLE_PICKUP_FL: 91,
  MARBLE_PICKUP_RR: 92,
  MARBLE_PICKUP_RL: 93,
  // Previously reserved chassis slots. Persist exact crossing eligibility.
  LAST_LAP_VALID: 94,
  LAST_LAP_ASSISTED: 95
};
var W = {
  OMEGA: 0,
  LOAD: 1,
  FX: 2,
  FY: 3,
  SLIP: 4,
  ANGLE: 5,
  SURFACE_TEMP: 6,
  CARCASS_TEMP: 7,
  WEAR: 8,
  DIRT: 9,
  COMPRESSION: 10,
  DISC_TEMP: 11,
  WATER: 12,
  SURFACE: 13,
  ROTATION: 14,
  FLAT: 15,
  PRESSURE: 16,
  RADIUS: 17,
  BLISTERING: 18,
  GRAINING: 19,
  PUNCTURED: 20,
  SUSPENSION_DAMAGE: 21,
  SLIP_POWER: 22,
  LENGTH: 23,
  STEER: 24,
  CAMBER: 25
};
var carBase = (id) => HEADER + id * CAR_STRIDE;
var SNAPSHOT_SCHEMA = Object.freeze({
  version: PROTOCOL_VERSION,
  header: HEADER,
  carStride: CAR_STRIDE,
  entities: Object.freeze(["four-wheel", "bike"]),
  blocks: Object.freeze([
    { name: "chassis", offset: 0, stride: 1, count: WHEEL_BASE },
    { name: "wheels", offset: WHEEL_BASE, stride: WHEEL_STRIDE, count: 4 },
    { name: "debris", offset: DEBRIS_BASE, stride: DEBRIS_STRIDE, count: 4 },
    { name: "skid", offset: SKID_BASE, stride: SKID_STRIDE, count: 1 },
    { name: "race", offset: RACE_BASE, stride: RACE_STRIDE, count: 1 },
    { name: "bike", offset: BIKE_BASE, stride: BIKE_STRIDE, count: 1 },
    { name: "offroad", offset: OFFROAD_BASE, stride: OFFROAD_STRIDE, count: 1 },
    { name: "wheel-motion", offset: WHEEL_MOTION_BASE, stride: WHEEL_MOTION_STRIDE, count: 1 },
    { name: "wheel-contact", offset: WHEEL_CONTACT_BASE, stride: WHEEL_CONTACT_SIZE, count: 1 }
  ])
});

// actual-source:src/storage/telemetry-schema.ts
var priority = [
  F.SPEED,
  F.THROTTLE,
  F.BRAKE,
  F.STEER,
  F.GEAR,
  F.RPM,
  F.G_LONG,
  F.G_LAT,
  F.FUEL,
  F.BATTERY,
  F.AERO_FRONT,
  F.AERO_REAR,
  F.DRAG,
  F.FRONT_HEALTH,
  F.REAR_HEALTH,
  F.FLOOR_HEALTH,
  F.WAKE
];
var MARBLE_FIELDS = [
  F.MARBLE_PICKUP_FR,
  F.MARBLE_PICKUP_FL,
  F.MARBLE_PICKUP_RR,
  F.MARBLE_PICKUP_RL
];
var LAP_EVIDENCE_FIELDS = [F.LAST_LAP_VALID, F.LAST_LAP_ASSISTED];
var TELEMETRY_FIELDS = [
  ...priority,
  ...Object.values(F).filter(
    (field) => field !== F.S && field !== F.LAPS && !priority.includes(field) && !MARBLE_FIELDS.includes(field) && !LAP_EVIDENCE_FIELDS.includes(field)
  )
];
var units = {
  X: "m",
  Y: "m",
  Z: "m",
  VX: "mps",
  VY: "mps",
  VZ: "mps",
  WX: "radps",
  WY: "radps",
  WZ: "radps",
  SPEED: "mps",
  STEER: "rad",
  RPM: "rpm",
  FUEL: "kg",
  BATTERY: "J",
  AERO_FRONT: "N",
  AERO_REAR: "N",
  DRAG: "N",
  S: "m",
  LATERAL: "m",
  LAP_TIME: "s",
  BEST_LAP: "s",
  LAST_LAP: "s",
  PENALTY: "s",
  AI_TARGET: "mps",
  G_LONG: "g",
  G_LAT: "g",
  G_VERT: "g",
  FINISH: "s",
  SLIP_ENERGY: "W",
  BOTTOM_ENERGY: "W",
  MOTOR_POWER: "W",
  REGEN_POWER: "W",
  FRONT_RIDE: "m",
  REAR_RIDE: "m",
  JACK_HEIGHT: "m",
  LOST_MASS: "kg",
  MASS: "kg",
  CLUTCH_TORQUE: "Nm",
  CLUTCH_SLIP_POWER: "W",
  ENGINE_TORQUE: "Nm",
  CAUTION_DISTANCE: "m",
  CAUTION_SPEED: "mps",
  PIT_CLOCK: "s",
  LAP_DELTA: "s",
  AI_DEFENDING: "m",
  MARBLE_PICKUP_FR: "tread_covers",
  MARBLE_PICKUP_FL: "tread_covers",
  MARBLE_PICKUP_RR: "tread_covers",
  MARBLE_PICKUP_RL: "tread_covers",
  SECTOR_1: "s",
  SECTOR_2: "s",
  SECTOR_3: "s"
};
var wheelUnits = {
  OMEGA: "radps",
  LOAD: "N",
  FX: "N",
  FY: "N",
  ANGLE: "rad",
  SURFACE_TEMP: "C",
  CARCASS_TEMP: "C",
  COMPRESSION: "m",
  DISC_TEMP: "C",
  WATER: "mm",
  ROTATION: "rad",
  PRESSURE: "kPa",
  RADIUS: "m",
  SLIP_POWER: "W",
  LENGTH: "m",
  STEER: "rad",
  CAMBER: "rad"
};
var nameOf = (key, unit) => key.toLowerCase() + (unit ? `_${unit}` : "");
var ALIGNMENT_FIELDS = [W.STEER, W.CAMBER];
var WHEEL_FIELDS = Object.values(W).filter((field) => !ALIGNMENT_FIELDS.includes(field));
var HEADER_FIELDS = [
  H.TIME,
  H.TICK,
  H.PHASE,
  H.LIGHTS,
  H.RAIN,
  H.CLOUD,
  H.AMBIENT,
  H.FLAG,
  H.STEP_MS,
  H.DROPPED,
  H.WIND_X,
  H.WIND_Z
];
var skidUnits = {
  LOAD: "N",
  SLIDE_POWER: "W",
  DAMPING_POWER: "W",
  SPARK_POWER: "W",
  SPARK_X: "m",
  SPARK_Y: "m",
  SPARK_Z: "m",
  VELOCITY_X: "mps",
  VELOCITY_Y: "mps",
  VELOCITY_Z: "mps",
  SLIDE_WORK: "J",
  SPARK_WORK: "J",
  TOTAL_WORK: "J"
};
var SKID_FIELDS = Object.values(K);
var CHANNELS = [
  "time_s",
  "distance_m",
  "lap",
  ...TELEMETRY_FIELDS.map((field) => {
    const key = Object.entries(F).find(([, value]) => field === value)[0];
    return nameOf(key, units[key]);
  }),
  ...WHEEL_NAMES.flatMap(
    (wheel) => Object.entries(W).filter(([, field]) => !ALIGNMENT_FIELDS.includes(field)).map(([key]) => `${wheel}_${nameOf(key, wheelUnits[key])}`)
  ),
  "session_time_s",
  "tick",
  "session_phase",
  "start_lights",
  "rain_rate_mmph",
  "cloud_cover",
  "ambient_C",
  "flag",
  "physics_step_ms",
  "dropped_wall_time_s",
  "wind_x_mps",
  "wind_z_mps",
  ...MARBLE_FIELDS.map((field) => {
    const key = Object.entries(F).find(([, value]) => field === value)[0];
    return nameOf(key, units[key]);
  }),
  ...WHEEL_NAMES.flatMap((wheel) => ["steer_rad", "camber_rad"].map((key) => `${wheel}_${key}`)),
  ...Object.keys(K).map((key) => `skid_${nameOf(key, skidUnits[key])}`)
];
var TELEMETRY_STRIDE = CHANNELS.length;
function packTelemetry(frame, out, offset) {
  const base = carBase(0);
  out[offset++] = frame[H.RACE_TIME];
  out[offset++] = frame[base + F.S];
  out[offset++] = frame[base + F.LAP_TIME] > 0 ? frame[base + F.LAPS] : -1;
  for (const field of TELEMETRY_FIELDS) out[offset++] = frame[base + field];
  for (let wheel = 0; wheel < 4; wheel++)
    for (const field of WHEEL_FIELDS)
      out[offset++] = frame[base + WHEEL_BASE + wheel * WHEEL_STRIDE + field];
  for (const field of HEADER_FIELDS) out[offset++] = frame[field];
  for (const field of MARBLE_FIELDS) out[offset++] = frame[base + field];
  for (let wheel = 0; wheel < 4; wheel++)
    for (const field of ALIGNMENT_FIELDS)
      out[offset++] = frame[base + WHEEL_BASE + wheel * WHEEL_STRIDE + field];
  for (const field of SKID_FIELDS) out[offset++] = frame[base + SKID_BASE + field];
}
function telemetryCsv(values, count) {
  if (!Number.isSafeInteger(count) || count < 0 || count * TELEMETRY_STRIDE !== values.length)
    throw new Error("Invalid telemetry export shape");
  const chunks = [CHANNELS.join(",") + "\n"];
  for (let start = 0; start < count; start += 500) {
    const rows = [];
    for (let row = start; row < Math.min(count, start + 500); row++) {
      const columns2 = [];
      for (let field = 0; field < TELEMETRY_STRIDE; field++) {
        const value = values[row * TELEMETRY_STRIDE + field];
        if (!Number.isFinite(value))
          throw new Error(`Non-finite telemetry at row ${row}, channel ${CHANNELS[field]}`);
        columns2.push(String(value));
      }
      rows.push(columns2.join(","));
    }
    chunks.push(new Blob([rows.join("\n") + "\n"]));
  }
  return new Blob(chunks, { type: "text/csv;charset=utf-8" });
}

// actual-source:src/storage/telemetry-plots.ts
var TELEMETRY_VIEWS = {
  driver: {
    title: "Driver inputs",
    plots: [
      {
        title: "Speed",
        unit: "km/h",
        minimum: 0,
        maximum: 320,
        traces: [{ channel: "speed_mps", label: "Speed", factor: 3.6 }]
      },
      {
        title: "Pedals",
        unit: "%",
        minimum: 0,
        maximum: 100,
        traces: [
          { channel: "throttle", label: "Throttle", factor: 100 },
          { channel: "brake", label: "Brake", factor: 100 },
          { channel: "clutch_pedal", label: "Clutch", factor: 100 }
        ]
      },
      {
        title: "Steering",
        unit: "degrees \xB7 left +",
        minimum: -25,
        maximum: 25,
        traces: [{ channel: "steer_rad", label: "Wheel steer", factor: 180 / Math.PI }]
      },
      {
        title: "Power unit",
        unit: "RPM / gear \xD7 1000",
        minimum: 0,
        maximum: 14e3,
        traces: [
          { channel: "rpm_rpm", label: "RPM" },
          { channel: "gear", label: "Gear \xD7 1000", factor: 1e3 }
        ]
      }
    ]
  },
  balance: {
    title: "Chassis and aerodynamics",
    plots: [
      {
        title: "Acceleration",
        unit: "g",
        minimum: -6,
        maximum: 6,
        traces: [
          { channel: "g_long_g", label: "Longitudinal" },
          { channel: "g_lat_g", label: "Lateral" },
          { channel: "g_vert_g", label: "Vertical" }
        ]
      },
      {
        title: "Aerodynamic load",
        unit: "N",
        minimum: 0,
        maximum: 18e3,
        traces: [
          { channel: "aero_front_N", label: "Front" },
          { channel: "aero_rear_N", label: "Rear" },
          { channel: "drag_N", label: "Drag" }
        ]
      },
      {
        title: "Ride height",
        unit: "mm",
        minimum: 0,
        maximum: 150,
        traces: [
          { channel: "front_ride_m", label: "Front", factor: 1e3 },
          { channel: "rear_ride_m", label: "Rear", factor: 1e3 }
        ]
      },
      {
        title: "Aerodynamic balance / wake",
        unit: "%",
        minimum: 0,
        maximum: 100,
        traces: [
          { channel: "wake", label: "Wake", factor: 100 },
          {
            channel: "aero_front_N",
            label: "Front share",
            factor: 100,
            denominator: ["aero_front_N", "aero_rear_N"]
          }
        ]
      }
    ]
  },
  tires: { title: "Tire temperature and load", plots: [] },
  slip: { title: "Tire slip and forces", plots: [] },
  brakes: { title: "Brakes and wear", plots: [] },
  suspension: { title: "Suspension travel", plots: [] },
  clutch: {
    title: "Clutch and engine coupling",
    plots: [
      {
        title: "Clutch pedal / engagement",
        unit: "%",
        minimum: 0,
        maximum: 100,
        traces: [
          { channel: "clutch_pedal", label: "Pedal", factor: 100 },
          { channel: "clutch_engagement", label: "Engagement", factor: 100 }
        ]
      },
      {
        title: "Shaft torque",
        unit: "Nm",
        minimum: -800,
        maximum: 800,
        traces: [
          { channel: "clutch_torque_Nm", label: "Clutch" },
          { channel: "engine_torque_Nm", label: "Combustion" }
        ]
      },
      {
        title: "Clutch slip heating",
        unit: "kW",
        minimum: 0,
        maximum: 200,
        traces: [{ channel: "clutch_slip_power_W", label: "Dissipated", factor: 1e-3 }]
      },
      {
        title: "Engine speed",
        unit: "RPM",
        minimum: 0,
        maximum: 14e3,
        traces: [{ channel: "rpm_rpm", label: "Crankshaft" }]
      }
    ]
  },
  hybrid: {
    title: "Hybrid and fuel",
    plots: [
      {
        title: "Power",
        unit: "kW",
        minimum: 0,
        maximum: 120,
        traces: [
          { channel: "motor_power_W", label: "Motor", factor: 1e-3 },
          { channel: "regen_power_W", label: "Recovered", factor: 1e-3 }
        ]
      },
      {
        title: "Stored energy",
        unit: "MJ",
        minimum: 0,
        maximum: 4,
        traces: [{ channel: "battery_J", label: "Battery", factor: 1e-6 }]
      },
      {
        title: "Mass",
        unit: "kg",
        minimum: 0,
        maximum: 40,
        traces: [
          { channel: "fuel_kg", label: "Fuel" },
          { channel: "lost_mass_kg", label: "Detached", factor: 1 }
        ]
      },
      {
        title: "Control settings",
        unit: "%",
        minimum: 0,
        maximum: 100,
        traces: [
          { channel: "brake_bias", label: "Front bias", factor: 100 },
          { channel: "diff_power", label: "Power differential", factor: 100 },
          { channel: "diff_coast", label: "Coast differential", factor: 100 }
        ]
      }
    ]
  }
};
var wheels3 = ["FL", "FR", "RL", "RR"];
var wheelTraces = (field, factor = 1) => wheels3.map((wheel) => ({ channel: `${wheel}_${field}`, label: wheel, factor }));
TELEMETRY_VIEWS.tires.plots = [
  {
    title: "Carcass temperature",
    unit: "\xB0C",
    minimum: 20,
    maximum: 150,
    traces: wheelTraces("carcass_temp_C")
  },
  {
    title: "Surface temperature",
    unit: "\xB0C",
    minimum: 20,
    maximum: 180,
    traces: wheelTraces("surface_temp_C")
  },
  { title: "Contact load", unit: "N", minimum: 0, maximum: 9e3, traces: wheelTraces("load_N") },
  { title: "Pressure", unit: "kPa", minimum: 0, maximum: 200, traces: wheelTraces("pressure_kPa") }
];
TELEMETRY_VIEWS.slip.plots = [
  {
    title: "Longitudinal slip",
    unit: "ratio",
    minimum: -1,
    maximum: 1,
    traces: wheelTraces("slip")
  },
  {
    title: "Slip angle",
    unit: "degrees",
    minimum: -20,
    maximum: 20,
    traces: wheelTraces("angle_rad", 180 / Math.PI)
  },
  {
    title: "Longitudinal tire force",
    unit: "N",
    minimum: -12e3,
    maximum: 12e3,
    traces: wheelTraces("fx_N")
  },
  {
    title: "Lateral tire force",
    unit: "N",
    minimum: -12e3,
    maximum: 12e3,
    traces: wheelTraces("fy_N")
  }
];
TELEMETRY_VIEWS.brakes.plots = [
  {
    title: "Brake disc temperature",
    unit: "\xB0C",
    minimum: 20,
    maximum: 1200,
    traces: wheelTraces("disc_temp_C")
  },
  { title: "Wear", unit: "% used", minimum: 0, maximum: 100, traces: wheelTraces("wear", 100) },
  {
    title: "Flat spots",
    unit: "% severity",
    minimum: 0,
    maximum: 100,
    traces: wheelTraces("flat", 100)
  },
  { title: "Contamination", unit: "%", minimum: 0, maximum: 100, traces: wheelTraces("dirt", 100) }
];
TELEMETRY_VIEWS.suspension.plots = [
  {
    title: "Compression",
    unit: "mm",
    minimum: 0,
    maximum: 170,
    traces: wheelTraces("compression_m", 1e3)
  },
  {
    title: "Suspension length",
    unit: "mm",
    minimum: 50,
    maximum: 320,
    traces: wheelTraces("length_m", 1e3)
  },
  { title: "Contact load", unit: "N", minimum: 0, maximum: 9e3, traces: wheelTraces("load_N") },
  {
    title: "Corner damage",
    unit: "%",
    minimum: 0,
    maximum: 100,
    traces: wheelTraces("suspension_damage", 100)
  }
];
var columns = new Map(CHANNELS.map((name, i) => [name, i]));
function channelIndex(name) {
  const value = columns.get(name);
  if (value === void 0) throw new Error(`Unknown telemetry channel ${name}`);
  return value;
}
function traceValue(data, row, trace) {
  const value = data.at(row, channelIndex(trace.channel)) * (trace.factor ?? 1);
  if (!trace.denominator) return value;
  const total = trace.denominator.reduce((sum, name) => sum + data.at(row, channelIndex(name)), 0);
  return total > 1e-8 ? value / total : 0;
}
function completeLaps(data, length) {
  const result2 = [];
  let start = 0;
  const valid = channelIndex("lap_valid");
  for (let i = 1; i < data.count; i++) {
    const previous = Math.round(data.at(i - 1, 2)), current = Math.round(data.at(i, 2));
    if (current === previous) continue;
    if (previous >= 0 && current === previous + 1 && data.at(start, 1) < 15 && data.at(i - 1, 1) > length - 15) {
      let clean = true, contiguous = true;
      for (let j = start; j < i; j++) {
        clean &&= data.at(j, valid) > 0.5;
        if (j > start && data.at(j, 0) - data.at(j - 1, 0) > 0.15) contiguous = false;
      }
      if (contiguous) result2.push({ lap: previous, start, end: i - 1, valid: clean });
    }
    start = i;
  }
  return result2;
}
var colors = ["#f4d4a0", "#64c8b7", "#ef7866", "#a6b7fa"];
var dashes = [[], [7, 3], [2, 3], [9, 3, 2, 3]];
function drawTelemetry(canvas, data, selected, comparison, length) {
  const view = TELEMETRY_VIEWS[selected] ?? TELEMETRY_VIEWS.driver;
  const c = canvas.getContext("2d");
  if (!c) return;
  const width = canvas.width, height = canvas.height;
  canvas.dataset.view = selected;
  canvas.setAttribute(
    "aria-label",
    `${view.title}. ${comparison ? "Two complete laps aligned by distance." : "Last 25 seconds."} ${view.plots.map((p) => `${p.title}, ${p.unit}`).join("; ")}`
  );
  c.fillStyle = "#141b1d";
  c.fillRect(0, 0, width, height);
  c.font = "13px monospace";
  c.fillStyle = "#d6dfdb";
  c.fillText(
    `${view.title.toUpperCase()} \xB7 ${comparison ? "DISTANCE-ALIGNED LAPS" : "ACTUAL SAMPLE TIME"} \xB7 DASHES IDENTIFY TRACES`,
    16,
    23
  );
  if (data.count < 2) {
    c.fillText("No recorded samples yet.", 25, 70);
    return;
  }
  const laps = comparison ? completeLaps(data, length).slice(-2) : [];
  if (comparison && laps.length < 2) {
    c.fillText("Two full laps must remain in the telemetry recording to compare.", 25, 70);
    return;
  }
  let start = data.count - 1;
  const endTime = data.at(start, 0);
  while (start > 0 && data.at(start - 1, 0) >= endTime - 25) start--;
  const ranges = comparison ? laps : [{ lap: -1, start, end: data.count - 1, valid: true }];
  const xStart = comparison ? 0 : data.at(start, 0), xEnd = comparison ? length : endTime;
  if (comparison)
    c.fillText(
      laps.map(
        (p) => `Lap ${p.lap + 1}${p.valid ? "" : " (INVALID)"} ${p === laps[0] ? "thin" : "bold"}`
      ).join("   /   "),
      16,
      44
    );
  const top = comparison ? 65 : 44, pane = (height - top - 30) / view.plots.length;
  view.plots.forEach((plot, p) => {
    const yTop = top + p * pane + 20, yBottom = top + (p + 1) * pane - 9;
    let minimum = plot.minimum, maximum = plot.maximum;
    for (const range of ranges)
      for (const trace of plot.traces) {
        for (let row = range.start; row <= range.end; row++) {
          const value = traceValue(data, row, trace);
          if (Number.isFinite(value)) {
            minimum = Math.min(minimum, value);
            maximum = Math.max(maximum, value);
          }
        }
      }
    const extent = Math.max(1e-8, maximum - minimum);
    const y = (value) => yBottom - (value - minimum) / extent * (yBottom - yTop);
    c.fillStyle = "#d6dfdb";
    c.fillText(`${plot.title} [${plot.unit}]`, 16, yTop - 5);
    c.fillStyle = "#93a4a3";
    c.fillText(maximum.toFixed(Math.abs(maximum) < 10 ? 2 : 0), 12, yTop + 13);
    c.fillText(minimum.toFixed(Math.abs(minimum) < 10 ? 2 : 0), 12, yBottom);
    c.strokeStyle = "#344447";
    c.lineWidth = 1;
    c.setLineDash([]);
    for (const level of [minimum, maximum, ...minimum < 0 && maximum > 0 ? [0] : []]) {
      c.beginPath();
      c.moveTo(64, y(level));
      c.lineTo(width - 20, y(level));
      c.stroke();
    }
    plot.traces.forEach((trace, traceIndex) => {
      c.fillStyle = colors[traceIndex % colors.length];
      c.fillText(trace.label, width - 480 + traceIndex * (460 / plot.traces.length), yTop - 5);
      ranges.forEach((range, rangeIndex) => {
        c.strokeStyle = colors[traceIndex % colors.length];
        c.lineWidth = comparison && rangeIndex === 0 ? 1 : 2;
        c.globalAlpha = comparison && rangeIndex === 0 ? 0.45 : 1;
        c.setLineDash(dashes[traceIndex % dashes.length]);
        c.beginPath();
        let started = false;
        const bucket = Math.max(1, Math.floor((range.end - range.start + 1) / (width - 90)));
        for (let row = range.start; row <= range.end; row += bucket) {
          let low = row, high = row;
          for (let j = row + 1; j <= Math.min(range.end, row + bucket - 1); j++) {
            if (data.at(j, 0) - data.at(j - 1, 0) > 0.15) started = false;
            if (traceValue(data, j, trace) < traceValue(data, low, trace)) low = j;
            if (traceValue(data, j, trace) > traceValue(data, high, trace)) high = j;
          }
          for (const point of low === high ? [low] : [low, high].sort((a, b) => a - b)) {
            const value = traceValue(data, point, trace);
            const xValue = data.at(point, comparison ? 1 : 0);
            const x = 64 + (xValue - xStart) / (xEnd - xStart || 1) * (width - 84);
            if (!Number.isFinite(value + x)) {
              started = false;
              continue;
            }
            if (row > range.start && data.at(row, 0) - data.at(row - 1, 0) > 0.15) started = false;
            if (started) c.lineTo(x, y(value));
            else {
              c.moveTo(x, y(value));
              started = true;
            }
          }
        }
        c.stroke();
        c.globalAlpha = 1;
      });
    });
  });
  c.setLineDash([]);
  c.fillStyle = "#b5c7c5";
  c.fillText(`${xStart.toFixed(1)} ${comparison ? "m" : "s"}`, 64, height - 8);
  c.fillText(`${xEnd.toFixed(1)} ${comparison ? "m" : "s"}`, width - 95, height - 8);
}

// actual-source:src/storage/recorders.ts
var REPLAY_FIELDS = [
  F.X,
  F.Y,
  F.Z,
  F.QX,
  F.QY,
  F.QZ,
  F.QW,
  F.VX,
  F.VY,
  F.VZ,
  F.SPEED,
  F.STEER,
  F.RPM,
  F.GEAR,
  F.THROTTLE,
  F.BRAKE,
  F.FUEL,
  F.BATTERY,
  F.FRONT_HEALTH,
  F.FLOOR_HEALTH,
  F.REAR_HEALTH,
  F.S,
  F.LAPS,
  F.LAP_TIME,
  F.BEST_LAP,
  F.LAST_LAP,
  F.LAST_LAP_VALID,
  F.LAST_LAP_ASSISTED,
  F.PENALTY,
  F.PIT_PHASE,
  F.IN_PIT,
  F.RANK,
  F.FINISH,
  F.G_LONG,
  F.G_LAT,
  F.G_VERT,
  F.IMPACT,
  F.COMPOUND,
  F.WAKE,
  F.PIT_STOPS,
  F.PIT_CLOCK,
  F.JACK_HEIGHT,
  RACE_BASE + R.VEHICLE,
  ...Object.values(B).map((field) => BIKE_BASE + field),
  ...Object.values(O).map((field) => OFFROAD_BASE + field)
];
var REPLAY_WHEELS = Object.values(W);
var REPLAY_SKID = Object.values(K);
var RC = REPLAY_FIELDS.length + REPLAY_WHEELS.length * 4 + REPLAY_SKID.length + WHEEL_MOTION_STRIDE + WHEEL_CONTACT_SIZE;
var TELEMETRY_SESSION_TIME = CHANNELS.indexOf("session_time_s");
var TELEMETRY_TICK = CHANNELS.indexOf("tick");
var TelemetryRecorder = class {
  stride = CHANNELS.length;
  capacity;
  data;
  constructor(seconds = 900) {
    if (!Number.isFinite(seconds) || seconds < 1 || seconds > 3600)
      throw new Error("Invalid telemetry capacity");
    this.capacity = Math.ceil(60 * seconds);
    this.data = new Float32Array(this.capacity * this.stride);
  }
  count = 0;
  head = 0;
  last = -1;
  append(frame) {
    if (frame[H.TICK] === this.last) return;
    this.last = frame[H.TICK];
    packTelemetry(frame, this.data, this.head * this.stride);
    this.head = (this.head + 1) % this.capacity;
    this.count = Math.min(this.count + 1, this.capacity);
  }
  offset(index) {
    return (this.head - this.count + index + this.capacity) % this.capacity * this.stride;
  }
  at(index, column) {
    return this.data[this.offset(index) + column];
  }
  appendBatch(batch, rows) {
    if (!Number.isInteger(rows) || rows < 0 || rows * this.stride > batch.length)
      throw new Error("Invalid telemetry batch");
    if (!rows) return;
    const retained = Math.min(rows, this.capacity);
    const skipped = rows - retained;
    const start = (this.head + skipped) % this.capacity;
    const first = Math.min(retained, this.capacity - start);
    const source = skipped * this.stride;
    const split = source + first * this.stride;
    this.data.set(batch.subarray(source, split), start * this.stride);
    if (first < retained) this.data.set(batch.subarray(split, rows * this.stride), 0);
    this.head = (this.head + rows) % this.capacity;
    this.count = Math.min(this.count + rows, this.capacity);
  }
  /** D31 flashback: drop rows after `time` in H.TIME session seconds. */
  truncate(time) {
    const cutoff = Math.fround(time);
    let removed = 0;
    while (this.count > 0 && this.at(this.count - 1, TELEMETRY_SESSION_TIME) > cutoff) {
      this.head = (this.head - 1 + this.capacity) % this.capacity;
      this.count--;
      removed++;
    }
    if (removed) this.last = this.count ? this.at(this.count - 1, TELEMETRY_TICK) : -1;
    return removed;
  }
  snapshot() {
    const values = new Float32Array(this.count * this.stride);
    if (!this.count) return values;
    const start = this.offset(0);
    const first = Math.min(values.length, this.data.length - start);
    values.set(this.data.subarray(start, start + first));
    if (first < values.length) values.set(this.data.subarray(0, values.length - first), first);
    return values;
  }
  csv() {
    return telemetryCsv(this.snapshot(), this.count);
  }
  draw(canvas, lapComparison = false, view = "driver", trackLength = 2973) {
    drawTelemetry(canvas, this, view, lapComparison, trackLength);
  }
};

// scripts/bench/engine-followup-telemetry.fixture.mjs
function fillCsvRows(values, start, rows, stride) {
  for (let row = 0; row < rows; row++)
    for (let column = 0; column < stride; column++)
      values[row * stride + column] = (((start + row) * 17 + column * 3) % 8192 - 4096) / 64;
  return values;
}
function appendCsvRows(recorder2, start, rows) {
  const batch = new Float32Array(60 * recorder2.stride);
  for (let offset = 0; offset < rows; offset += 60) {
    const count = Math.min(60, rows - offset);
    fillCsvRows(batch, start + offset, count, recorder2.stride);
    recorder2.appendBatch(batch, count);
  }
}
function* csvExpectedChunks(channels, start, count) {
  yield channels.join(",") + "\n";
  const stride = channels.length;
  for (let offset = 0; offset < count; offset += 500) {
    const rows = [];
    for (let row = offset; row < Math.min(count, offset + 500); row++) {
      const columns2 = [];
      for (let column = 0; column < stride; column++)
        columns2.push(
          String((((start + row) * 17 + column * 3) % 8192 - 4096) / 64)
        );
      rows.push(columns2.join(","));
    }
    yield rows.join("\n") + "\n";
  }
}
async function compareCsvStream(blob2, channels, start, count, consume = () => {
}) {
  const expected = csvExpectedChunks(channels, start, count);
  const encoder = new TextEncoder();
  let part = encoder.encode(expected.next().value);
  let cursor = 0;
  let compared = 0;
  let mismatches = 0;
  let firstMismatch = null;
  let expectedChunks = 1;
  for await (const bytes of blob2.stream()) {
    consume(bytes);
    for (let index = 0; index < bytes.length; index++) {
      if (cursor === part.length) {
        const next = expected.next();
        if (next.done)
          throw new Error("CSV contains unexpected trailing bytes");
        part = encoder.encode(next.value);
        cursor = 0;
        expectedChunks++;
      }
      if (bytes[index] !== part[cursor]) {
        mismatches++;
        firstMismatch ??= compared;
      }
      cursor++;
      compared++;
    }
  }
  if (cursor !== part.length || !expected.next().done)
    throw new Error("CSV ended before the independent expected output");
  if (compared !== blob2.size)
    throw new Error("Blob stream byte count mismatch");
  if (mismatches)
    throw new Error(
      `CSV differs at ${mismatches} bytes, first ${firstMismatch}`
    );
  return {
    comparedBytes: compared,
    differingBytes: mismatches,
    expectedChunks
  };
}

// scripts/bench/engine-followup-csv-memory.runner.mjs
var config = JSON.parse(readFileSync(process.argv[2], "utf8"));
assert.ok(["timing", "observe"].includes(config.kind));
assert.ok(config.capacity >= 600 && config.capacity <= 54e3);
assert.equal(typeof globalThis.gc, "function");
var memory = () => ({
  ...process.memoryUsage(),
  processMaxRssKiB: process.resourceUsage().maxRSS
});
var collect = () => {
  globalThis.gc();
  globalThis.gc();
};
var digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
var bytesOf = (values) => new Uint8Array(values.buffer, values.byteOffset, values.byteLength);
var recorder = config.capacity === 54e3 ? new TelemetryRecorder() : new TelemetryRecorder(config.capacity / 60);
assert.equal(recorder.capacity, config.capacity);
assert.equal(recorder.stride, 228);
appendCsvRows(recorder, 0, config.capacity + 243);
var input = recorder.snapshot();
var inputSha256 = digest(bytesOf(input));
var ringSha256 = digest(bytesOf(recorder.data));
var warmups = [];
for (let index = 0; index < config.warmups; index++) {
  const started = performance.now();
  const blob2 = telemetryCsv(input.subarray(0, 600 * recorder.stride), 600);
  warmups.push({ elapsedMs: performance.now() - started, bytes: blob2.size });
}
collect();
var constructorSamples = [];
var NativeBlob = globalThis.Blob;
if (config.kind === "observe") {
  globalThis.Blob = class ObservedBlob extends NativeBlob {
    constructor(parts = [], options) {
      const metadata = {
        index: constructorSamples.length,
        finalAssembly: options?.type === "text/csv;charset=utf-8",
        partCount: parts.length,
        stringPartCount: 0,
        stringCodeUnits: 0,
        largestStringCodeUnits: 0,
        blobPartCount: 0,
        blobBytes: 0
      };
      for (const part of parts) {
        if (typeof part === "string") {
          metadata.stringPartCount++;
          metadata.stringCodeUnits += part.length;
          metadata.largestStringCodeUnits = Math.max(metadata.largestStringCodeUnits, part.length);
        } else {
          assert.ok(part instanceof NativeBlob);
          metadata.blobPartCount++;
          metadata.blobBytes += part.size;
        }
      }
      const before = memory();
      super(parts, options);
      constructorSamples.push({ ...metadata, before, after: memory(), outputBytes: this.size });
    }
  };
}
var beforeExport = memory();
var blob;
var elapsedMs;
try {
  const started = performance.now();
  blob = telemetryCsv(input, config.capacity);
  elapsedMs = performance.now() - started;
} finally {
  globalThis.Blob = NativeBlob;
}
var immediatelyAfterExport = memory();
assert.equal(blob.type, "text/csv;charset=utf-8");
var outputBytes = blob.size;
collect();
var afterGcWithRingInputAndBlob = memory();
assert.equal(blob.size, outputBytes);
var startedVerification = performance.now();
var hash = createHash("sha256");
var exact = {
  ...await compareCsvStream(blob, CHANNELS, 243, config.capacity, (chunk) => hash.update(chunk)),
  sha256: hash.digest("hex")
};
if (config.capacity === 54e3) {
  assert.equal(exact.comparedBytes, 115038761);
  assert.equal(exact.sha256, "cfc38f4dd65c878d824866c817e65511b1287161c525e3c8cafaed9bf7ad0d9b");
}
var verificationMs = performance.now() - startedVerification;
var afterVerification = memory();
assert.equal(digest(bytesOf(input)), inputSha256);
assert.equal(digest(bytesOf(recorder.data)), ringSha256);
blob = null;
await setImmediate();
collect();
var afterBlobReleaseGc = memory();
var sampledMaxima = {};
var exportSamples = [beforeExport, immediatelyAfterExport];
for (const sample of constructorSamples) exportSamples.push(sample.before, sample.after);
for (const metric of [
  "rss",
  "heapUsed",
  "heapTotal",
  "external",
  "arrayBuffers",
  "processMaxRssKiB"
])
  sampledMaxima[metric] = Math.max(...exportSamples.map((sample) => sample[metric]));
var result = {
  role: config.role,
  kind: config.kind,
  measuredAt: (/* @__PURE__ */ new Date()).toISOString(),
  capacity: config.capacity,
  stride: recorder.stride,
  input: {
    startRow: 243,
    ringBytes: recorder.data.byteLength,
    snapshotBytes: input.byteLength,
    ringSha256,
    snapshotSha256: inputSha256,
    headerSha256: digest(CHANNELS.join(",") + "\n")
  },
  warmups,
  uninstrumentedElapsedMs: config.kind === "timing" ? elapsedMs : null,
  observedElapsedMsNotForLatencyComparison: config.kind === "observe" ? elapsedMs : null,
  outputBytes,
  mime: "text/csv;charset=utf-8",
  beforeExport,
  immediatelyAfterExport,
  afterGcWithRingInputAndBlob,
  constructorSamples,
  exportPhaseSampledMaxima: sampledMaxima,
  exact,
  verificationMs,
  afterVerification,
  afterBlobReleaseGc,
  processLifetimeMaxRssKiB: process.resourceUsage().maxRSS,
  retainedAtEnd: { ringBytes: recorder.data.byteLength, snapshotBytes: input.byteLength },
  limits: [
    "Node/V8 memory categories overlap; rss, heapUsed, external and arrayBuffers must not be added.",
    "Sampled memory maxima are not exact peak live memory; process max RSS is a process-lifetime high-water mark.",
    "The immediately-after-export process max RSS precedes verification, but includes fixture construction and 600-row warmups.",
    "Instrumented Blob-boundary samples are separate from uninstrumented latency comparisons.",
    "Completed Blob payload still scales with output size; no constant-memory or browser-memory claim."
  ]
};
writeFileSync(config.output, JSON.stringify(result, null, 2) + "\n");
process.stdout.write(
  JSON.stringify({
    role: result.role,
    kind: result.kind,
    ms: result.uninstrumentedElapsedMs,
    bytes: result.outputBytes,
    exportMaxRssKiB: immediatelyAfterExport.processMaxRssKiB
  }) + "\n"
);
