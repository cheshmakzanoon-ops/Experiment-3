import { createHash } from 'node:crypto';
import { closeSync, copyFileSync, existsSync, lstatSync, mkdirSync, openSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { arch, platform, release } from 'node:os';
import { performance } from 'node:perf_hooks';
import { setTimeout as delay } from 'node:timers/promises';
import { snapshotSource, changedSource } from './repo/scripts/source-stability.ts';

// Scratch-only orchestration. Execute only with root's exclusive COMPUTE/browser grant.
const root = '/tmp/engine-c71f32882729/repo';
const work = '/tmp/engine-c71f32882729';
const prefix = join(work, 'w09c');
const expectedHead = process.argv[2];
const expectedTree = process.argv[3];
const browserPath = join(work, 'browsers/chromium_headless_shell-1193/chrome-linux/headless_shell');
const baseURL = 'http://127.0.0.1:4173';
if (![expectedHead, expectedTree].every((value) => /^[a-f0-9]{40}$/.test(value ?? '')))
  throw new Error('Pass the root-granted frozen commit and tree explicitly.');
const hashBytes = (bytes) => createHash('sha256').update(bytes).digest('hex');
const hashFile = (path) => existsSync(path) ? hashBytes(readFileSync(path)) : null;
const json = (path, value) => writeFileSync(path, JSON.stringify(value, null, 2) + '\n');
const commandEnv = { ...process.env, GIT_NO_LAZY_FETCH: '1' };
const gitConfigCount = Number(commandEnv.GIT_CONFIG_COUNT ?? '0');
if (!Number.isSafeInteger(gitConfigCount) || gitConfigCount < 0)
  throw new Error('Invalid inherited Git configuration count.');
commandEnv['GIT_CONFIG_KEY_' + gitConfigCount] = 'protocol.allow';
commandEnv['GIT_CONFIG_VALUE_' + gitConfigCount] = 'never';
commandEnv.GIT_CONFIG_COUNT = String(gitConfigCount + 1);
const git = (...args) => {
  const result = spawnSync('git', ['-c', 'protocol.allow=never', ...args], {
    cwd: root, encoding: 'utf8', env: commandEnv,
  });
  if (result.status !== 0) throw new Error(result.stderr || 'Git read failed');
  return result.stdout.trimEnd();
};
const snapshotHash = (snapshot) => {
  const hash = createHash('sha256');
  for (const [path, value] of snapshot) hash.update(path + '\0' + value + '\n');
  return hash.digest('hex');
};
const snapshotDist = () => {
  const result = {};
  const visit = (relative = '') => {
    for (const entry of readdirSync(join(root, 'dist', relative), { withFileTypes: true })
      .sort((a, b) => a.name.localeCompare(b.name, 'en'))) {
      const path = relative ? relative + '/' + entry.name : entry.name;
      if (entry.isDirectory()) visit(path);
      else {
        const bytes = readFileSync(join(root, 'dist', path));
        result[path] = { bytes: bytes.length, sha256: hashBytes(bytes) };
      }
    }
  };
  visit();
  return result;
};
const changedDist = (before, after) => [...new Set([...Object.keys(before), ...Object.keys(after)])]
  .filter((path) => JSON.stringify(before[path]) !== JSON.stringify(after[path])).sort();
const sourceFingerprint = () => {
  const files = [];
  const visit = (path) => {
    if (lstatSync(path).isDirectory())
      for (const entry of readdirSync(path)) visit(join(path, entry));
    else files.push(path);
  };
  visit(join(root, 'src'));
  files.push(...['package-lock.json', 'index.html', 'vite.config.ts'].map((path) => join(root, path)));
  const hash = createHash('sha256');
  for (const path of files.sort()) {
    hash.update(path.slice(root.length + 1) + '\0');
    hash.update(readFileSync(path));
    hash.update('\0');
  }
  return hash.digest('hex');
};
const sourceReceipt = (snapshot) => ({
  head: git('rev-parse', 'HEAD'),
  tree: git('rev-parse', 'HEAD^{tree}'),
  gitStatus: git('status', '--porcelain=v1', '--untracked-files=all'),
  guardedInputCount: snapshot.size,
  guardedInputSha256: snapshotHash(snapshot),
  sourceFingerprint: sourceFingerprint(),
  lockfileSha256: hashFile(join(root, 'package-lock.json')),
  generatedPlayerLodsSha256: hashFile(join(root, 'public/models/supplied-player-lods.bin.gz')),
});
const buildManifestPath = join(work, 'w09b-work/w09b-static-build-manifest.json');
const buildManifest = JSON.parse(readFileSync(buildManifestPath, 'utf8'));
if (!buildManifest.passed || buildManifest.after.head !== expectedHead ||
    buildManifest.after.tree !== expectedTree)
  throw new Error('Worker50 did not pass the granted exact checkpoint.');
if (hashFile(buildManifest.distReceipt.path) !== buildManifest.distReceipt.sha256)
  throw new Error('Worker50 dist manifest no longer matches its receipt.');
const expectedDist = JSON.parse(readFileSync(buildManifest.distReceipt.path, 'utf8'));
const before = snapshotSource(root);
const beforeReceipt = sourceReceipt(before);
const distBefore = snapshotDist();
const identityPath = join(root, 'dist/BUILD_IDENTITY.json');
const identity = JSON.parse(readFileSync(identityPath, 'utf8'));
const specFiles = readdirSync(join(root, 'e2e')).filter((name) => /^engine-native-.*\.spec\.ts$/.test(name)).sort()
  .map((name) => 'e2e/' + name);
specFiles.push('e2e/replay-state.spec.ts');
if (specFiles.length !== 9 || beforeReceipt.head !== expectedHead || beforeReceipt.tree !== expectedTree ||
    beforeReceipt.guardedInputSha256 !== buildManifest.after.guardedInputSha256 ||
    changedDist(expectedDist, distBefore).length ||
    JSON.stringify(identity) !== JSON.stringify(buildManifest.buildIdentity) ||
    identity.commit !== expectedHead || identity.fingerprint !== beforeReceipt.sourceFingerprint ||
    identity.variant !== 'product' || identity.edition !== 'full')
  throw new Error('Final source, built files, selected files, or BUILD_IDENTITY differs from the granted build.');

const env = {
  ...commandEnv,
  NODE_OPTIONS: '--max-old-space-size=1024',
  APEX_BROWSER_BACKEND: 'swiftshader',
  PLAYWRIGHT_BROWSERS_PATH: join(work, 'browsers'),
  CHROMIUM_PATH: browserPath,
  PLAYWRIGHT_JSON_OUTPUT_FILE: prefix + '-browser-report.json',
  PLAYWRIGHT_HTML_OUTPUT_DIR: prefix + '-html-report',
  PLAYWRIGHT_HTML_OPEN: 'never',
};
// The unchanged standard config reuses our already verified owned preview.
// This avoids its npm preview path entirely, without altering its test settings.
delete env.CI;
const args = [
  '--experimental-transform-types', 'scripts/source-stability.ts', '--',
  process.execPath, 'node_modules/@playwright/test/cli.js', 'test', ...specFiles,
  '--config=playwright.config.ts', '--workers=1', '--retries=0', '--forbid-only',
  '--reporter=list,json,html,./scripts/browser-progress-reporter.mjs',
  '--output=' + prefix + '-results',
];
const version = spawnSync(browserPath, ['--version'], { encoding: 'utf8', env });
if (version.status !== 0) throw new Error('Installed Chromium executable failed its version invocation.');
const manifest = {
  schema: 1, worker: 51, startedAt: new Date().toISOString(), expectedHead, expectedTree,
  before: beforeReceipt,
  buildManifest: { path: buildManifestPath, sha256: hashFile(buildManifestPath) },
  distManifestFromWorker50: buildManifest.distReceipt,
  buildIdentity: identity,
  gitRestrictions: { noLazyFetch: '1', protocolAllow: 'never' },
  evidenceRunnerSha256: hashFile(join(work, 'w09c-native-final-gate.mjs')),
  standardConfigSha256: hashFile(join(root, 'playwright.config.ts')),
  sourceGuardSha256: hashFile(join(root, 'scripts/source-stability.ts')),
  guardedCommand: { executable: process.execPath, args, cwd: root },
  environment: {
    NODE_OPTIONS: env.NODE_OPTIONS, APEX_BROWSER_BACKEND: env.APEX_BROWSER_BACKEND,
    PLAYWRIGHT_BROWSERS_PATH: env.PLAYWRIGHT_BROWSERS_PATH, CHROMIUM_PATH: env.CHROMIUM_PATH,
    CI: null, PLAYWRIGHT_JSON_OUTPUT_FILE: env.PLAYWRIGHT_JSON_OUTPUT_FILE,
    PLAYWRIGHT_HTML_OUTPUT_DIR: env.PLAYWRIGHT_HTML_OUTPUT_DIR,
    PLAYWRIGHT_HTML_OPEN: env.PLAYWRIGHT_HTML_OPEN,
  },
  runtime: {
    node: process.version, v8: process.versions.v8, platform: platform(), release: release(), arch: arch(),
    browserVersion: version.stdout.trim(), browserExecutableSha256: hashFile(browserPath),
    playwright: JSON.parse(readFileSync(join(root, 'node_modules/@playwright/test/package.json'), 'utf8')).version,
  },
  unchangedTestContracts: {
    selectedCases: 37, selectedFiles: 9, workers: 1, retries: 0, forbidOnly: true,
    standardConfig: 'playwright.config.ts', replayDeadlineMs: 300000, expectTimeoutMs: 60000,
    replayStallMs: 8500, replayQuality: 'low (existing authored test setting)',
    replayMode: 'practice', replayOpponents: '0', replayWeather: 'rain', replayCompound: 'wet',
  },
  sourceGuardExcludedPaths: ['public/models/supplied-player-lods.bin.gz', 'browser-backend.json', 'browser-progress.json'],
  sourceDigestFormat: buildManifest.snapshotDigestFormat,
  passed: false,
};
json(prefix + '-source-before.json', Object.fromEntries(before));
json(prefix + '-dist-before.json', distBefore);
json(prefix + '-native-gate-manifest.json', manifest);
let server;
let serverFd;
let browserFd;
let heartbeat;
try {
  let occupied = false;
  try {
    await fetch(baseURL + '/BUILD_IDENTITY.json', { signal: AbortSignal.timeout(1500) });
    occupied = true;
  } catch {}
  if (occupied) throw new Error('Port 4173 is occupied by an unowned server; coordinate before proceeding.');
  serverFd = openSync(prefix + '-preview.log', 'w');
  const previewArgs = ['node_modules/vite/bin/vite.js', 'preview', '--host', '127.0.0.1', '--port', '4173', '--strictPort'];
  server = spawn(process.execPath, previewArgs, { cwd: root, env, stdio: ['ignore', serverFd, serverFd] });
  const previewStarted = performance.now();
  manifest.preview = { executable: process.execPath, args: previewArgs, pid: server.pid, owned: true };
  while (true) {
    if (server.exitCode !== null) throw new Error('Owned Vite preview exited before it became ready.');
    try {
      const response = await fetch(baseURL + '/BUILD_IDENTITY.json', { signal: AbortSignal.timeout(1000) });
      if (response.ok) {
        const observedIdentity = await response.json();
        if (JSON.stringify(observedIdentity) !== JSON.stringify(identity))
          throw new Error('Served BUILD_IDENTITY does not match the exact local production dist.');
        manifest.preview.servedBuildIdentity = observedIdentity;
        manifest.preview.verifiedAt = new Date().toISOString();
        break;
      }
    } catch (error) {
      if (String(error).includes('BUILD_IDENTITY')) throw error;
    }
    if (performance.now() - previewStarted >= 30000) throw new Error('Owned preview was not ready within 30 seconds.');
    await delay(100);
  }
  json(prefix + '-native-gate-manifest.json', manifest);
  console.log(JSON.stringify({ event: 'browser-start', at: new Date().toISOString(), identity, files: specFiles.length, expectedCases: 37 }));
  browserFd = openSync(prefix + '-browser.log', 'w');
  const started = performance.now();
  const child = spawn(process.execPath, args, { cwd: root, env, stdio: ['ignore', browserFd, browserFd] });
  heartbeat = setInterval(() => {
    const progressPath = join(root, 'browser-progress.json');
    try {
      const progress = JSON.parse(readFileSync(progressPath, 'utf8'));
      console.log(JSON.stringify({ event: 'browser-heartbeat', completed: progress.completed.length,
        active: progress.active.map((item) => ({ title: item.title, step: item.step })) }));
    } catch {}
  }, 30000);
  const outcome = await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (exitCode, signal) => resolve({ exitCode, signal }));
  });
  clearInterval(heartbeat);
  manifest.browser = { ...outcome, durationMs: +(performance.now() - started).toFixed(3), finishedAt: new Date().toISOString() };
  console.log(JSON.stringify({ event: 'browser-finish', ...manifest.browser }));
} catch (error) {
  manifest.failure = { message: String(error), stack: error.stack ?? null };
  console.error(error);
} finally {
  clearInterval(heartbeat);
  if (server && server.exitCode === null) {
    server.kill('SIGTERM');
    const closed = await Promise.race([
      new Promise((resolve) => server.once('exit', () => resolve(true))),
      delay(5000).then(() => false),
    ]);
    if (!closed) {
      server.kill('SIGKILL');
      await new Promise((resolve) => server.once('exit', resolve));
    }
  }
  if (manifest.preview) {
    manifest.preview.stoppedAt = new Date().toISOString();
    manifest.preview.exitCode = server?.exitCode ?? null;
    manifest.preview.signalCode = server?.signalCode ?? null;
  }
  if (browserFd !== undefined) closeSync(browserFd);
  if (serverFd !== undefined) closeSync(serverFd);
}
const after = snapshotSource(root);
const distAfter = snapshotDist();
manifest.after = sourceReceipt(after);
manifest.changedSourcePaths = changedSource(before, after);
manifest.changedDistPaths = changedDist(distBefore, distAfter);
manifest.changedDistFromBuildPaths = changedDist(expectedDist, distAfter);
json(prefix + '-source-after.json', Object.fromEntries(after));
json(prefix + '-dist-after.json', distAfter);
for (const receipt of ['browser-backend.json', 'browser-progress.json'])
  if (existsSync(join(root, receipt))) copyFileSync(join(root, receipt), prefix + '-' + receipt);
const reportPath = prefix + '-browser-report.json';
if (existsSync(reportPath)) {
  const report = JSON.parse(readFileSync(reportPath, 'utf8'));
  const cases = [];
  const collect = (suite) => {
    for (const spec of suite.specs ?? [])
      for (const test of spec.tests ?? [])
        cases.push({ file: spec.file ?? suite.file, title: spec.title, expectedStatus: test.expectedStatus,
          status: test.status, timeout: test.timeout,
          results: test.results.map((result) => ({ status: result.status, durationMs: result.duration,
            retry: result.retry, errors: result.errors ?? [], attachments: result.attachments ?? [] })) });
    for (const nested of suite.suites ?? []) collect(nested);
  };
  for (const suite of report.suites) collect(suite);
  const attachmentDir = prefix + '-attachments';
  mkdirSync(attachmentDir, { recursive: true });
  const retained = [];
  for (let i = 0; i < cases.length; i++)
    for (const result of cases[i].results)
      for (const attachment of result.attachments) {
        if (attachment.contentType === 'application/json' && attachment.body) {
          const name = String(i + 1).padStart(2, '0') + '-' + attachment.name.replaceAll(/[^a-zA-Z0-9._-]/g, '_');
          const destination = join(attachmentDir, name);
          writeFileSync(destination, Buffer.from(attachment.body, 'base64'));
          retained.push({ case: i + 1, title: cases[i].title, name: attachment.name, path: destination, sha256: hashFile(destination) });
        }
      }
  json(prefix + '-case-results.json', cases);
  json(prefix + '-attachment-manifest.json', retained);
  manifest.stats = report.stats;
  manifest.reportErrors = report.errors ?? [];
  manifest.caseCount = cases.length;
  manifest.suiteCounts = Object.fromEntries([...new Set(cases.map((test) => test.file))].sort()
    .map((file) => [file, cases.filter((test) => test.file === file).length]));
  manifest.allCasesPassedOnce = cases.length === 37 && Object.keys(manifest.suiteCounts).length === 9 &&
    cases.every((test) => test.expectedStatus === 'passed' && test.status === 'expected' &&
      test.results.length === 1 && test.results[0].status === 'passed' && test.results[0].retry === 0);
  const findAttachment = (name) => {
    const found = retained.find((attachment) => attachment.name === name);
    return found ? JSON.parse(readFileSync(found.path, 'utf8')) : null;
  };
  const stall = findAttachment('recording-stall-continuity.json');
  const replay = findAttachment('replay-ownership.json');
  const audio = findAttachment('native-preview-live-resume.json');
  const csvTransfer = findAttachment('native-telemetry-snapshot-transfer.json');
  const csvOwnership = findAttachment('native-telemetry-worker-ownership.json');
  manifest.keyEvidence = {
    replayStall: stall && { ...stall, replayGainSeconds: stall.replayAfter - stall.replayBefore,
      telemetryGainSamples: stall.telemetryAfter - stall.telemetryBefore },
    replaySeek: replay && {
      callbacks: replay.seekObservation.callbacks, framesBefore: replay.seekObservation.framesBefore,
      framesAfter: replay.sought.presentation.frames, observedPosition: replay.sought.replayPosition,
      presentationTime: replay.sought.presentation.time, replayStart: replay.sought.replayStart,
      presentationTimeErrorSeconds: replay.sought.presentation.time - (replay.sought.replayStart + 0.75),
      seekPending: replay.sought.replaySeekPending, replayPlaying: replay.sought.replayPlaying,
      endPausePosition: replay.endPause.paused.replayPosition, settledEndPosition: replay.settledEnd.replayPosition,
      restartFloor: replay.restartedEnd.floor, restartedPosition: replay.restartedEnd.after.replayPosition,
      finalPosition: replay.final.replayPosition, finalSurfaceTime: replay.final.replaySurfaceTime,
      finalRecordingWarnings: replay.final.recordingWarnings,
    },
    liveAudioResume: audio, csvTransfer, csvOwnership,
  };
}
const backendPath = prefix + '-browser-backend.json';
manifest.backend = existsSync(backendPath) ? JSON.parse(readFileSync(backendPath, 'utf8')) : null;
manifest.finishedAt = new Date().toISOString();
manifest.receiptHashes = Object.fromEntries(['browser.log', 'browser-report.json', 'browser-backend.json',
  'browser-progress.json', 'case-results.json', 'attachment-manifest.json', 'source-before.json',
  'source-after.json', 'dist-before.json', 'dist-after.json', 'preview.log'].map((suffix) =>
    [prefix + '-' + suffix, hashFile(prefix + '-' + suffix)]));
manifest.passed = !manifest.failure && manifest.browser?.exitCode === 0 && !manifest.browser?.signal &&
  manifest.allCasesPassedOnce && manifest.reportErrors?.length === 0 &&
  manifest.changedSourcePaths.length === 0 && manifest.changedDistPaths.length === 0 &&
  manifest.changedDistFromBuildPaths.length === 0 &&
  manifest.before.head === manifest.after.head && manifest.before.tree === manifest.after.tree &&
  manifest.before.guardedInputSha256 === manifest.after.guardedInputSha256 &&
  manifest.before.sourceFingerprint === manifest.after.sourceFingerprint &&
  manifest.before.lockfileSha256 === manifest.after.lockfileSha256 &&
  manifest.before.generatedPlayerLodsSha256 === manifest.after.generatedPlayerLodsSha256 &&
  manifest.backend?.requested === 'swiftshader' && /swiftshader/i.test(manifest.backend.renderer) &&
  manifest.backend.physicalHardwareValidated === false && manifest.backend.error === 0;
json(prefix + '-native-gate-manifest.json', manifest);
console.log(JSON.stringify({ event: 'complete', passed: manifest.passed, manifest: prefix + '-native-gate-manifest.json' }));
process.exitCode = manifest.passed ? 0 : 1;
