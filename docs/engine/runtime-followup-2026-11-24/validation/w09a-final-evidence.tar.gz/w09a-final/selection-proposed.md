# Final approved consolidated unit selection

**128 unique files / 1,852 expected cases**. Every engine-prefixed file and every changed test is included. Mandatory union: **52** (38 engine-prefixed plus 14 other changed files). Additional unique adjacent files: **76**.

The surface-channel file was added after a concrete broader-CI failure and exact-baseline comparison. All selection reason overlaps are deduplicated by physical path. The final run must wait for the published corrected checkpoint and explicit COMPUTE/source freeze grant.

## Exact file inventory

- `tests/airborne-clutch.test.ts`
- `tests/audio-unlock-lifetime.test.ts`
- `tests/audio-unlock.test.ts`
- `tests/bindings.test.ts`
- `tests/button-actions.test.ts`
- `tests/bvh-build-work.test.ts`
- `tests/bvh-traversal.test.ts`
- `tests/calibration.test.ts`
- `tests/canvas-texture-budget.test.ts`
- `tests/circuit-frame-transport.test.ts`
- `tests/circuit-preparation-lifetime.test.ts`
- `tests/circuit-startup-settlement.test.ts`
- `tests/client-command-retention.test.ts`
- `tests/clutch.test.ts`
- `tests/contact.test.ts`
- `tests/controller-buttons.test.ts`
- `tests/controller-replacement.test.ts`
- `tests/controller-session-ownership.test.ts`
- `tests/drivetrain.test.ts`
- `tests/engine-audio-input-composition.test.ts`
- `tests/engine-audio-preview-cancellation.test.ts`
- `tests/engine-bvh-scalar-bounds.test.ts`
- `tests/engine-circuit-worker-terminal.test.ts`
- `tests/engine-clock-accounting.test.ts`
- `tests/engine-clock-transfer-integration.test.ts`
- `tests/engine-contact-construction.test.ts`
- `tests/engine-contact-math-allocation.test.ts`
- `tests/engine-control-quantization.test.ts`
- `tests/engine-controller-shift-order.test.ts`
- `tests/engine-diagnostics-backpressure.test.ts`
- `tests/engine-export-host-ownership.test.ts`
- `tests/engine-festival-command-errors.test.ts`
- `tests/engine-festival-composition.test.ts`
- `tests/engine-festival-status-backpressure.test.ts`
- `tests/engine-flashback-state.test.ts`
- `tests/engine-ghost-bounds.test.ts`
- `tests/engine-host-failure-cleanup.test.ts`
- `tests/engine-input-audio-adversarial.test.ts`
- `tests/engine-loudness.test.ts`
- `tests/engine-network-adversarial.test.ts`
- `tests/engine-network-composition.test.ts`
- `tests/engine-network-integration.test.ts`
- `tests/engine-network-shift.test.ts`
- `tests/engine-persistence-integration.test.ts`
- `tests/engine-physics-adversarial.test.ts`
- `tests/engine-physics-invariants.test.ts`
- `tests/engine-recording-composition.test.ts`
- `tests/engine-renderer-exclusive-release.test.ts`
- `tests/engine-renderer-texture-composition.test.ts`
- `tests/engine-resource-adversarial.test.ts`
- `tests/engine-resource-integration.test.ts`
- `tests/engine-server-snapshot-lifetime.test.ts`
- `tests/engine-session-settlement.test.ts`
- `tests/engine-telemetry-chunk-storage.test.ts`
- `tests/engine-telemetry-time-ring.test.ts`
- `tests/engine-texture-budget-registration.test.ts`
- `tests/engine-worker-session-adversarial.test.ts`
- `tests/engineering.test.ts`
- `tests/environment-loader-lifecycle.test.ts`
- `tests/festival-fatal-worker.test.ts`
- `tests/festival-host-startup.test.ts`
- `tests/festival-renderer-loader-lifecycle.test.ts`
- `tests/festival-session-lifecycle.test.ts`
- `tests/festival-terrain-transport.test.ts`
- `tests/flashback-recording.test.ts`
- `tests/frame-buffer-pool.test.ts`
- `tests/ghost-lap.test.ts`
- `tests/ghost-vehicle.test.ts`
- `tests/imported-render-budget.test.ts`
- `tests/indexed-replay-store-lifetime.test.ts`
- `tests/input-controller-lifecycle.test.ts`
- `tests/input-pump.test.ts`
- `tests/input.test.ts`
- `tests/live-frame-clock.test.ts`
- `tests/motocross-body-input.test.ts`
- `tests/music-bus-lifetime.test.ts`
- `tests/net-authority.test.ts`
- `tests/net-client-lifetime.test.ts`
- `tests/net-codec.test.ts`
- `tests/net-command-queues.test.ts`
- `tests/net-event-loop-ownership.test.ts`
- `tests/net-lifecycle.test.ts`
- `tests/net-prediction.test.ts`
- `tests/net-records.test.ts`
- `tests/net-resilience.test.ts`
- `tests/net-runtime-metrics.test.ts`
- `tests/net-server-control-validation.test.ts`
- `tests/net-transport-lifetime.test.ts`
- `tests/net-transport.test.ts`
- `tests/network-bounded-recovery.test.ts`
- `tests/network-metric-retention.test.ts`
- `tests/open-world-worker-frame-pool.test.ts`
- `tests/open-world-worker.test.ts`
- `tests/power-unit-voice-lifetime.test.ts`
- `tests/racing-audio-lifetime.test.ts`
- `tests/recorder-rings.test.ts`
- `tests/recording-publication-ownership.test.ts`
- `tests/recording-transport.test.ts`
- `tests/recording.test.ts`
- `tests/renderer-resource-integration.test.ts`
- `tests/renderer-resource-lifecycle.test.ts`
- `tests/replay-clock.test.ts`
- `tests/replay-endpoint-precision.test.ts`
- `tests/replay-seek-preparation.test.ts`
- `tests/review-audio-tap-lifetime.test.ts`
- `tests/road-contact-ownership.test.ts`
- `tests/road-contact.test.ts`
- `tests/rumble-actuator-lifetime.test.ts`
- `tests/rumble.test.ts`
- `tests/session-replay-lifecycle.test.ts`
- `tests/skid-recording.test.ts`
- `tests/snapshot-encoding-hotpath.test.ts`
- `tests/snapshot-header-contract.test.ts`
- `tests/surface-channel-backpressure.test.ts`
- `tests/telemetry-export-lifetime.test.ts`
- `tests/telemetry-export.test.ts`
- `tests/texture-budget-source-refresh.test.ts`
- `tests/texture-loader-cache-lifecycle.test.ts`
- `tests/texture-loader-lifecycle.test.ts`
- `tests/texture-source-ownership.test.ts`
- `tests/ui-audio-lifetime.test.ts`
- `tests/vegetation-quality-transition.test.ts`
- `tests/wheel-contact-recording.test.ts`
- `tests/wheel-winding-recording.test.ts`
- `tests/worker-fixed-step-clock.test.ts`
- `tests/worker-input-edges.test.ts`
- `tests/worker-pause.test.ts`
- `tests/worker-rewind-ownership.test.ts`

## network — 18 additional unique files

Changed authority/client/input/records/server ownership, journal compatibility, command queues, exact packet encoding, transport failures, final-boundary publication, and bounded recovery/diagnostics.

## input — 12 additional unique files

Changed controller shift staging and action callback ordering; check mappings, driving/action allowlists, complete edge observation, device replacement/focus, input-pump reentrancy, worker queues and haptic teardown.

## audio — 7 additional unique files

Changed preview/activation and host resource lifetime; check close/restart and activation refusal, stale gestures, preview voices, shared UI/music and review-tap cleanup boundaries.

## resources — 7 additional unique files

Changed renderer cleanup, generated/imported budget registration and source ownership; check cloned source retention, cache retries, dynamic canvas refresh, loader cleanup, preparation cancellation, and real vegetation releasePlanting transitions (worker47 recommendation).

## storage — 15 additional unique files

Changed recorder truncation/snapshot, replay float32 boundaries, ghost bounds and CSV Blob groups; check transfer/republication ownership, complete CSV values, cancellation, IndexedDB transactions, page seams/seek/endpoints, full ghost lifecycle and recorded physical signals.

## workers_sessions — 9 additional unique files

Changed worker terminal state, diagnostics credit, Festival command/status receipts, session settlement and host ownership; check first-frame startup, fatal classification, frame/recording pauses, backpressure, fixed step conservation and immutable presentation copies. Surface channel backpressure was added after a concrete broader-CI failure; the exact baseline/current proof and test-only terminal-contract correction are retained.

## physics — 8 additional unique files

Changed scalar BVH/contact construction and road-contact/AWD allocation removal; check exact construction/traversal, ray/contact ownership, combined road frame, drivetrain and grounded/airborne clutch behavior. Worker48 adversarial file will be mandatory if added.
