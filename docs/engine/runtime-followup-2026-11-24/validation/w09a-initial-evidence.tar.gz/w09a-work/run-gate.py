#!/usr/bin/env python3
"""Run only after the coordinator explicitly grants source freeze and COMPUTE."""
from __future__ import annotations
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shlex
import stat
import subprocess
import sys
import tarfile
import time

REPO = Path('/tmp/engine-c71f32882729/repo')
OUT = Path('/tmp/engine-c71f32882729/w09a-work')
BASELINE = '1c609bfa7006ee2c51a32a97f1fedd61c6c1bfcb'
INPUT_DIRS = {'src', 'public', 'scripts', 'tests', 'e2e', 'docs', '.github'}
EXCLUDED = {'public/models/supplied-player-lods.bin.gz', 'browser-backend.json', 'browser-progress.json'}
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_ALLOW_PROTOCOL='none')
BASELINE_PATCH_SCOPE = ['src', 'tests', 'scripts', 'e2e', '.github']

def now():
    return dt.datetime.now(dt.UTC).isoformat()

def git(*args):
    return subprocess.check_output(['git', '-c', 'protocol.allow=never', *args], cwd=REPO, env=GIT_ENV).decode()

def save_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def snapshot():
    result = {}
    def visit(path):
        relative = path.relative_to(REPO).as_posix()
        if relative in EXCLUDED:
            return
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            result[relative] = 'symlink:' + os.readlink(path)
        elif stat.S_ISDIR(info.st_mode):
            for child in sorted(path.iterdir()):
                visit(child)
        elif stat.S_ISREG(info.st_mode):
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            result[relative] = f'{info.st_mode & 0o111}:{digest}'
    for child in sorted(REPO.iterdir()):
        if child.name in INPUT_DIRS or not stat.S_ISDIR(child.lstat().st_mode):
            visit(child)
    canonical = json.dumps(sorted(result.items()), separators=(',', ':')).encode()
    return {
        'captured_utc': now(),
        'head_commit': git('rev-parse', 'HEAD').strip(),
        'head_tree': git('rev-parse', 'HEAD^{tree}').strip(),
        'task_baseline': BASELINE,
        'task_baseline_tree': git('rev-parse', BASELINE + '^{tree}').strip(),
        'input_file_count': len(result),
        'input_manifest_sha256': hashlib.sha256(canonical).hexdigest(),
        'inputs': result,
        'exclusions_match_source_stability_guard': sorted(EXCLUDED),
    }

def capture_git(prefix):
    commands = {
        'status.txt': ('status', '--porcelain=v2', '--untracked-files=all'),
        'index.txt': ('ls-files', '--stage'),
        'tracked-task-baseline.patch': ('diff', '--binary', '--no-renames', BASELINE, '--', *BASELINE_PATCH_SCOPE),
        'tracked-task-baseline-raw.txt': ('diff', '--raw', '--no-abbrev', '--no-renames', BASELINE, '--'),
        'tracked-head-working.patch': ('diff', '--binary', 'HEAD', '--'),
        'tracked-index-working.patch': ('diff', '--binary', '--'),
        'tracked-head-index.patch': ('diff', '--cached', '--binary', '--'),
        'untracked.txt': ('ls-files', '--others', '--exclude-standard'),
    }
    captures = []
    for name, args in commands.items():
        command = ['git', '-c', 'protocol.allow=never', *args]
        result = subprocess.run(command, cwd=REPO, env=GIT_ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        (OUT / f'{prefix}-{name}').write_bytes(result.stdout)
        captures.append({'file': f'{prefix}-{name}', 'argv': command, 'exit_code': result.returncode,
                         'stderr': result.stderr.decode(), 'output_bytes': len(result.stdout),
                         'output_sha256': hashlib.sha256(result.stdout).hexdigest()})
        if result.returncode:
            print(f'Local-only Git capture unavailable: {name}: {result.stderr.decode()}', flush=True)
            if 'baseline' not in name:
                raise RuntimeError(f'Critical local Git identity capture failed: {name}')
    save_json(f'{prefix}-git-capture.json', captures)


def main():
    if sys.argv[1:] != ['--coordinator-granted-source-freeze-and-compute']:
        raise SystemExit('Explicit coordinator source freeze and COMPUTE grant required.')
    proposal = json.loads((OUT / 'selection-proposed.json').read_text())
    changed = {
        p for p in (git('diff', '--name-only', BASELINE, '--', 'tests').splitlines()
                     + git('ls-files', '--others', '--exclude-standard', 'tests').splitlines())
        if p.endswith('.test.ts') and (REPO / p).is_file()
    }
    engine = {str(p.relative_to(REPO)) for p in (REPO / 'tests').glob('engine-*.test.ts')}
    adjacent = {p for group in proposal['adjacent_groups'].values() for p in group['files']}
    files = sorted(changed | engine | adjacent)
    if files != proposal['files']:
        save_json('selection-change-needs-coordinator-review.json', {
            'added': sorted(set(files) - set(proposal['files'])),
            'removed': sorted(set(proposal['files']) - set(files)),
        })
        raise SystemExit('Selection changed after coordinator approval; stopped before tests.')
    if len(files) != len(set(files)):
        raise SystemExit('Duplicate test file selection.')
    proposal.update({
        'status': 'final_selection',
        'finalized_utc': now(),
        'observed_head': git('rev-parse', 'HEAD').strip(),
        'observed_head_tree': git('rev-parse', 'HEAD^{tree}').strip(),
        'pending_wave8_test_files': [],
        'pending_wave8_finalization': [],
        'engine_prefix_files': sorted(engine),
        'engine_prefix_count': len(engine),
        'changed_since_baseline_files': sorted(changed),
        'changed_since_baseline_count': len(changed),
        'mandatory_unique_count': len(changed | engine),
        'adjacent_unique_count': len(set(files) - (changed | engine)),
        'selected_unique_count': len(files),
    })
    for entry in proposal['file_selection']:
        entry['sha256_at_execution'] = hashlib.sha256((REPO / entry['path']).read_bytes()).hexdigest()
    save_json('selection-final.json', proposal)
    (OUT / 'selection-final.txt').write_text('\n'.join(files) + '\n')
    capture_git('before')
    untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
    code_untracked = [p for p in untracked if p.split('/')[0] in {'src', 'tests', 'scripts', 'e2e', '.github'}]
    if code_untracked:
        with tarfile.open(OUT / 'untracked-code-inputs.tar.gz', 'w:gz') as archive:
            for relative in sorted(code_untracked):
                archive.add(REPO / relative, arcname=relative, recursive=False)
    before = snapshot()
    save_json('source-before.json', before)
    command = [
        'node', '--experimental-transform-types', 'scripts/source-stability.ts', '--',
        'node', 'node_modules/vitest/vitest.mjs', 'run', *files,
        '--pool=threads', '--maxWorkers=1', '--minWorkers=1',
        '--allowOnly=false', '--retry=0', '--reporter=default', '--reporter=json',
        '--outputFile.json=' + str(OUT / 'unit-results.json'),
    ]
    env = dict(GIT_ENV, NODE_OPTIONS='--max-old-space-size=1024')
    identity = {
        'started_utc': now(), 'working_directory': str(REPO),
        'runtime': json.loads(subprocess.check_output([
            'node', '-p',
            'JSON.stringify({node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch})',
        ], cwd=REPO, env=env).decode()),
        'vitest_version': json.loads((REPO / 'node_modules/vitest/package.json').read_text())['version'],
        'gate_runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'source_guard_sha256': hashlib.sha256((REPO / 'scripts/source-stability.ts').read_bytes()).hexdigest(),
        'environment_overrides': {k: env[k] for k in ['NODE_OPTIONS', 'GIT_OPTIONAL_LOCKS', 'GIT_NO_LAZY_FETCH', 'GIT_ALLOW_PROTOCOL']},
        'git_per_command_configuration': {'protocol.allow': 'never'},
        'baseline_patch_scope': BASELINE_PATCH_SCOPE,
        'blocked_preflight_evidence': 'preflight-blocked/denial.json',
        'argv': command, 'shell_command': 'NODE_OPTIONS=--max-old-space-size=1024 ' + shlex.join(command),
        'source_before': {k: v for k, v in before.items() if k != 'inputs'},
    }
    save_json('invocation.json', identity)
    (OUT / 'command.txt').write_text(identity['shell_command'] + '\n')
    print(f'Starting {len(files)} unique files at {identity["started_utc"]}', flush=True)
    started = time.monotonic()
    with (OUT / 'unit-default.log').open('w') as log:
        completed = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
    duration = time.monotonic() - started
    after = snapshot()
    save_json('source-after.json', after)
    capture_git('after')
    source_changes = sorted(p for p in before['inputs'].keys() | after['inputs'].keys()
                            if before['inputs'].get(p) != after['inputs'].get(p))
    summary = {
        'schema': 1, 'worker': 'worker49/w09a',
        'started_utc': identity['started_utc'], 'finished_utc': now(),
        'wall_seconds_including_guard': duration,
        'exit_code': completed.returncode,
        'expected_selected_files': len(files),
        'source_changed_files': source_changes,
        'source_guard_stable': not source_changes,
        'before_head': before['head_commit'], 'after_head': after['head_commit'],
        'before_head_tree': before['head_tree'], 'after_head_tree': after['head_tree'],
        'before_input_manifest_sha256': before['input_manifest_sha256'],
        'after_input_manifest_sha256': after['input_manifest_sha256'],
        'raw_reports': ['unit-default.log', 'unit-results.json'],
        'source_manifests': ['source-before.json', 'source-after.json'],
        'git_capture_failures': [item for prefix in ['before', 'after']
                                 for item in json.loads((OUT / f'{prefix}-git-capture.json').read_text())
                                 if item['exit_code'] != 0],
        'blocked_preflight_evidence': 'preflight-blocked/denial.json',
        'deduplication_rule': 'One invocation over a sorted set of file paths; no counts from previous focused runs are added. Individual assertion identities preserve per-file occurrence for repeated display names.',
    }
    report_path = OUT / 'unit-results.json'
    if report_path.exists():
        report = json.loads(report_path.read_text())
        suites = report.get('testResults', [])
        actual = [str(Path(s['name']).relative_to(REPO)) for s in suites]
        summary['physical_result_files'] = len(actual)
        summary['duplicate_physical_files'] = [p for p, n in collections.Counter(actual).items() if n > 1]
        summary['missing_files'] = sorted(set(files) - set(actual))
        summary['unexpected_files'] = sorted(set(actual) - set(files))
        summary['vitest_reported_totals'] = {k: v for k, v in report.items() if k.startswith('num') or k in ('success', 'startTime')}
        summary['assertion_status_counts'] = dict(collections.Counter(a['status'] for s in suites for a in s.get('assertionResults', [])))
        per_file = []
        failures = []
        assertions = []
        for suite, relative in zip(suites, actual):
            seen = collections.Counter()
            for assertion in suite.get('assertionResults', []):
                full_name = assertion.get('fullName', assertion.get('title', ''))
                seen[full_name] += 1
                entry = {'file': relative, 'full_name': full_name, 'same_name_occurrence': seen[full_name],
                         'status': assertion['status'], 'duration_ms': assertion.get('duration'),
                         'failure_messages': assertion.get('failureMessages', [])}
                assertions.append(entry)
                if assertion['status'] == 'failed':
                    failures.append(entry)
            per_file.append({'file': relative, 'status': suite.get('status'),
                             'assertions': len(suite.get('assertionResults', [])),
                             'assertion_status_counts': dict(collections.Counter(a['status'] for a in suite.get('assertionResults', []))),
                             'message': suite.get('message', '')})
        summary['per_file'] = sorted(per_file, key=lambda x: x['file'])
        summary['failures'] = failures
        save_json('assertion-results-unique.json', assertions)
    else:
        summary['report_missing'] = True
    save_json('results-summary.json', summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in {'per_file', 'failures'}}, indent=2), flush=True)
    return completed.returncode or (1 if source_changes else 0)

if __name__ == '__main__':
    raise SystemExit(main())
