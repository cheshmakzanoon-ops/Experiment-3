# Worker49 — initial consolidated gate and controlled test corrections

## Status

The initial **127-file / 1,837-assertion** consolidated run on published `6a6bf02eb2d89eeb6aeff32769ef3deb4a49f17c` completed with **1,803 passed and 34 failed**, across **124 passing and 3 failing physical files**. There were no skips, retries, missing files, unexpected files or duplicate file selections. The guard and independent before/after manifest agree: all **3,396 input files remained unchanged**, aggregate SHA-256 `11041c91ffa0cda9058da63c6f39b17e11770b1fa6658e5d2cd0910f63e6387e`.

The corrected three-file gate subsequently passes **42/42**, and scoped ESLint passes. Production source hashes are unchanged from the initial gate. Root has authorized and reviewed the correction scope and will publish the fixture/CI checkpoint before the full 127-file rerun. **The complete final gate is still pending publication; this report does not relabel the failed initial run as passing.** COMPUTE was explicitly released after the targeted validation.

## Exact baseline classification

All three unchanged failing test files were executed together against exact task baseline `1c609bfa7006ee2c51a32a97f1fedd61c6c1bfcb`: **42/42 pass**. Every one of the 34 original failed assertion names is matched to a passing baseline assertion in `failure-classification.json`. No failure is classified as an independently proven baseline issue.

| File | Baseline pass / total | Initial candidate pass / total | Corrected targeted pass / total | Cause |
| --- | ---: | ---: | ---: | --- |
| circuit-frame-transport.test.ts | 5 / 5 | 3 / 5 | 5 / 5 | Existing recovery expectations conflict with intentional terminal worker ownership. |
| circuit-preparation-lifetime.test.ts | 19 / 19 | 5 / 19 | 19 / 19 | Partial fixture omitted the newly owned output pass. |
| festival-renderer-loader-lifecycle.test.ts | 18 / 18 | 0 / 18 | 18 / 18 | Partial fixture omitted sky geometry/material, near-shadow owner and output pass. |

The isolated baseline contains **1,124 files verified against their exact baseline Git blob identities**, including **29 locally read historical source blobs**. Unchanged current bytes were reused only when their Git blob SHA-1 matched the baseline object exactly. All required executed source bytes were available; no Git fetch was performed. The unchanged public tree and installed dependencies are linked from the frozen repository. The baseline source archive, per-file SHA-256/Git-blob manifest and source-stable results are retained.

## Controlled correction scope

Only the following three files were edited by this worker, after root granted a specific freeze exception:

- `tests/circuit-preparation-lifetime.test.ts`: instantiate a real Three OutputPass in the partial renderer fixture; observe its actual material using the existing disposal event assertions. Existing preparation, cancellation, first-failure and independent cleanup assertions remain.
- `tests/festival-renderer-loader-lifecycle.test.ts`: supply all four previously omitted resource owners and assert each is disposed exactly once during every fixture cleanup, including repeated explicit disposal. Existing loader, cancellation, installation, retry and idempotence assertions remain.
- `tests/circuit-frame-transport.test.ts`: keep real Simulation, serializer and structured transfers; require one terminal error, no further frames/acks/steps from repeated commands or a retired return while failed, successful initialization with five distinct full-size frames, and exactly one restored publication from a valid return despite its duplicate. The test does not claim that the existing wire format authenticates same-sized buffers across sessions.

No production, authored content, tuning, timeout, retry or quality setting was changed. No test was skipped or removed; the three files still contain 42 assertions. Root independently owns the focused workflow update. The exact three-file diff is `correction-tests.patch` (69 insertions, 16 deletions).

## Commands and evidence

All unit runs use direct Vitest with `NODE_OPTIONS=--max-old-space-size=1024`, `--pool=threads --maxWorkers=1 --minWorkers=1 --allowOnly=false --retry=0`, and default plus JSON reports outside the repository. Both current-targeted tests and ESLint ran through `scripts/source-stability.ts`.

The original full gate took 327.68 seconds including source guard. The baseline three-file run took 14.38 seconds. The corrected three-file run took 14.88 seconds and guarded ESLint 1.40 seconds. These are validation durations, not engine performance measurements.

- Original full evidence: `unit-default.log`, `unit-results.json`, `results-summary.json`, `assertion-results-unique.json`.
- Exact approved selection: `selection-final.json` / `.txt`; proposal coverage rationale: `selection-proposed.md`.
- Exact original inputs: `source-before.json`, `source-after.json`, `changed-code-source-manifest.json`, `before/after-git-capture.json`, local index/status/raw object lists and scoped binary diffs.
- Baseline proof: `baseline-source-manifest.json`, `baseline-source.tar.gz`, `baseline-tree-objects.txt`, `baseline-invocation.json`, `baseline-default.log`, `baseline-unit-results.json`, `baseline-results-summary.json`.
- Corrections: `correction-tests.patch`, `failure-classification.json`, `correction-three-file.log`, `correction-three-file-results.json`, `correction-eslint.log`, `correction-results-summary.json`, `correction-source-before.json`, `correction-source-after.json`.

## Preparation denial retained

Automatic approval review stopped the first evidence-capture attempt before Vitest started, because a full historical binary diff caused Git's partial clone to attempt an unnecessary HTTPS lazy fetch from GitHub. The denial, original runner and completed preflight index/status are retained under `preflight-blocked/`. Root authorized a materially safer local-only path: `GIT_NO_LAZY_FETCH=1`, `GIT_ALLOW_PROTOCOL=none`, and per-command `protocol.allow=never`; no global configuration or approval settings were changed. Scoped engine/test/script baseline diffs and full raw object metadata then completed with zero unavailable blobs. A separate archive attempt later reported one absent unchanged blob; exact blob-verified local reconstruction supplied it without fetching. These preparation events are not counted as test failures.
