import { finishRaceEntry } from './race-entry.ts';
import { test, expect } from '@playwright/test';
import { H } from '../src/simulation/protocol.ts';

test('recorded playback has exclusive modal, seek, audio and focus ownership', async ({
  page,
}, testInfo) => {
  test.setTimeout(300000);
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('console', (message) => {
    if (message.type() === 'error') errors.push(message.text());
  });
  const diagnostics = () => page.evaluate(() => window.apexDiagnostics());
  await page.goto('/');
  await expect(page.locator('#menu')).toBeVisible({ timeout: 60000 });
  await page.getByRole('button', { name: 'GARAGE & SETTINGS', exact: true }).click();
  await page.locator('[name=quality]').selectOption('low');
  await page.getByRole('button', { name: 'APPLY & SAVE' }).click();
  await expect(page.locator('#modal')).not.toBeVisible();
  await page.selectOption('#mode', 'practice');
  await page.selectOption('#opponents', '0');
  await page.selectOption('#weather', 'rain');
  await page.selectOption('#compound', 'wet');
  await page.getByRole('button', { name: 'ENTER CIRCUIT' }).click();
  await finishRaceEntry(page);
  await expect
    .poll(async () => (await diagnostics()).state, { timeout: 90000 })
    .toBe('driving');
  await page.keyboard.press('g');
  await expect
    .poll(async () => (await diagnostics()).replaySeconds, { timeout: 30000 })
    .toBeGreaterThan(6);

  // The physics worker must retain one-second telemetry/replay pages while the
  // render/UI thread is genuinely unavailable. This used to exhaust the six
  // transferable pages and create an archival hole after roughly six seconds.
  const beforeStall = await diagnostics();
  const stallMs = 8500;
  await page.evaluate((duration) => {
    const end = performance.now() + duration;
    while (performance.now() < end) {
      // Deliberately occupy the main thread; the dedicated physics worker must
      // continue stepping and recording without a recycle response.
    }
  }, stallMs);
  await expect
    .poll(async () => (await diagnostics()).replaySeconds, { timeout: 30000 })
    .toBeGreaterThan(beforeStall.replaySeconds + 5);
  const afterStall = await diagnostics();
  expect(afterStall.telemetrySamples).toBeGreaterThan(beforeStall.telemetrySamples + 300);
  expect(afterStall.recordingWarnings).toEqual([]);
  await testInfo.attach('recording-stall-continuity.json', {
    body: JSON.stringify(
      {
        stallMs,
        replayBefore: beforeStall.replaySeconds,
        replayAfter: afterStall.replaySeconds,
        telemetryBefore: beforeStall.telemetrySamples,
        telemetryAfter: afterStall.telemetrySamples,
        warnings: afterStall.recordingWarnings,
      },
      null,
      2,
    ),
    contentType: 'application/json',
  });

  await page.keyboard.press('t');
  await expect(page.locator('#telemetryModal')).toBeVisible();
  await expect
    .poll(async () => (await diagnostics()).workerPause)
    .toMatchObject({ pending: false, paused: true });
  const live = await diagnostics();
  expect(live.workerPause.tick).not.toBeNull();
  expect(live.frame?.[H.TICK]).toBe(Math.fround(live.workerPause.tick!));
  await page.keyboard.press('Escape');
  await expect(page.locator('#telemetryModal')).not.toBeVisible();
  await expect(page.getByRole('button', { name: 'RESUME SESSION' })).toBeVisible();
  expect((await diagnostics()).state).toBe('paused');
  await page.getByRole('button', { name: 'WATCH REPLAY' }).click();
  await expect(page.locator('#replayBar')).toBeVisible();
  await expect.poll(async () => (await diagnostics()).audio.playing).toBe(true);

  // A seek while playing must display its exact requested point once, not
  // silently add the next wall interval before drawing the first sample.
  // A callback is not a submitted frame: GPU backpressure or an asynchronous
  // replay page read may defer it. Observe every callback in-page so we capture
  // the FIRST submitted seek frame, without polling past it into playback.
  const seekObservation = await page.evaluate(async () => {
    const seek = document.getElementById('replaySeek') as HTMLInputElement;
    const before = window.apexDiagnostics();
    const framesBefore = before.presentation!.frames;
    seek.value = '0.75';
    seek.dispatchEvent(new Event('input', { bubbles: true }));
    const deadline = performance.now() + 60000;
    let callbacks = 0;
    return new Promise<{
      first: ReturnType<typeof window.apexDiagnostics>;
      framesBefore: number;
      callbacks: number;
    }>((resolve, reject) => {
      const observe = () => {
        const first = window.apexDiagnostics();
        callbacks++;
        if (first.presentation!.frames !== framesBefore || !first.replaySeekPending) {
          resolve({ first, framesBefore, callbacks });
          return;
        }
        if (first.replayError || performance.now() >= deadline) {
          reject(new Error(first.replayError ?? 'No replay seek frame within 60 seconds'));
          return;
        }
        requestAnimationFrame(observe);
      };
      requestAnimationFrame(observe);
    });
  });
  const sought = seekObservation.first;
  expect(seekObservation.callbacks).toBeGreaterThan(0);
  expect(sought.presentation!.frames).toBe(seekObservation.framesBefore + 1);
  expect(sought.replaySeekPending).toBe(false);
  expect(sought.replayPlaying).toBe(true);
  expect(sought.replayPosition).toBe(0.75);
  expect(sought.presentation!.time).toBeCloseTo(sought.replayStart + 0.75, 5);
  expect(sought.frame).toEqual(live.frame);

  await page.keyboard.press('t');
  await expect(page.locator('#telemetryModal')).toBeVisible();
  await expect.poll(async () => (await diagnostics()).audio.playing).toBe(false);
  const modal = await diagnostics();
  await page.waitForTimeout(500);
  const modalAfter = await page.evaluate(async () => {
    // Prove callbacks actually ran while the dialog owned the frozen backdrop;
    // a wall-clock sleep alone can miss the bug on a slow software GPU.
    for (let i = 0; i < 4; i++)
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    return window.apexDiagnostics();
  });
  expect(modalAfter.replayPosition).toBe(modal.replayPosition);
  expect(modalAfter.presentation).toEqual(modal.presentation);
  expect(modalAfter.frame).toEqual(live.frame);
  expect(modalAfter.replayPlaying).toBe(false);
  await page.keyboard.press('c');
  expect((await diagnostics()).renderer!.camera).toBe(modal.renderer!.camera);
  await page.keyboard.press('Escape');
  await expect(page.locator('#telemetryModal')).not.toBeVisible();
  await expect(page.locator('#modal')).not.toBeVisible();
  expect((await diagnostics()).state).toBe('replay');
  await expect(page.locator('#replayPlay')).toHaveText('PLAY');
  await page.waitForTimeout(300);
  expect((await diagnostics()).replayPosition).toBe(modal.replayPosition);

  // Focus restoration cannot resume a replay that a blur suspended.
  await page.locator('#replayPlay').click();
  await expect
    .poll(async () => (await diagnostics()).replayPosition)
    .toBeGreaterThan(modal.replayPosition);
  await page.evaluate(() => window.dispatchEvent(new Event('blur')));
  const blurred = await diagnostics();
  expect(blurred.replayPlaying).toBe(false);
  expect(blurred.audio.playing).toBe(false);
  await page.evaluate(() => window.dispatchEvent(new Event('focus')));
  await page.waitForTimeout(300);
  expect((await diagnostics()).replayPosition).toBe(blurred.replayPosition);
  await page.locator('#replayPlay').click();
  await expect.poll(async () => (await diagnostics()).audio.playing).toBe(true);

  // Pause a seek to the exact end before any presentation callback can run.
  // Pausing must preserve that requested frame; only a later PLAY may restart.
  const endPause = await page.evaluate(() => {
    const seek = document.getElementById('replaySeek') as HTMLInputElement;
    const before = window.apexDiagnostics();
    const step = seek.step;
    try {
      // Recorded endpoints need not be multiples of the slider's 0.01 s step.
      seek.step = 'any';
      seek.value = String(before.replaySeconds);
      seek.dispatchEvent(new Event('input', { bubbles: true }));
    } finally {
      seek.step = step;
    }
    const sought = window.apexDiagnostics();
    (document.getElementById('replayPlay') as HTMLButtonElement).click();
    return {
      end: before.replaySeconds,
      wasPlaying: before.replayPlaying,
      sought: {
        position: sought.replayPosition,
        playing: sought.replayPlaying,
        seekPending: sought.replaySeekPending,
      },
      paused: window.apexDiagnostics(),
    };
  });
  expect(endPause.wasPlaying).toBe(true);
  expect(endPause.sought).toEqual({
    position: endPause.end,
    playing: true,
    seekPending: true,
  });
  expect(endPause.paused.replayPosition).toBe(endPause.end);
  expect(endPause.paused.replayPlaying).toBe(false);
  expect(endPause.paused.replaySeekPending).toBe(true);
  expect(endPause.paused.audio.playing).toBe(false);
  expect(endPause.paused.frame).toEqual(live.frame);
  await expect.poll(async () => (await diagnostics()).replaySeekPending).toBe(false);
  const settledEnd = await diagnostics();
  expect(settledEnd.replayPosition).toBe(endPause.end);
  expect(settledEnd.replayPlaying).toBe(false);
  expect(settledEnd.presentation!.time).toBeCloseTo(settledEnd.replayStart + endPause.end, 5);

  const restartedEnd = await page.evaluate(() => {
    const floor = Number((document.getElementById('replaySeek') as HTMLInputElement).min);
    (document.getElementById('replayPlay') as HTMLButtonElement).click();
    return { floor, after: window.apexDiagnostics() };
  });
  expect(restartedEnd.after.replayPosition).toBe(restartedEnd.floor);
  expect(restartedEnd.after.replayPlaying).toBe(true);
  expect(restartedEnd.after.replaySeekPending).toBe(true);
  expect(restartedEnd.after.audio.playing).toBe(false);
  expect(restartedEnd.after.frame).toEqual(live.frame);
  await expect.poll(async () => (await diagnostics()).audio.playing).toBe(true);
  await page.locator('#replayPlay').click();
  await page.locator('#replaySeek').evaluate((element) => {
    (element as HTMLInputElement).value = '0';
    element.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await expect.poll(async () => (await diagnostics()).replaySeekPending).toBe(false);
  const held = await diagnostics();
  const heldAfter = await page.evaluate(async () => {
    for (let i = 0; i < 4; i++)
      await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
    return window.apexDiagnostics();
  });
  expect(heldAfter.presentation).toEqual(held.presentation);
  expect(heldAfter.frame).toEqual(live.frame);
  expect(heldAfter.replayPosition).toBe(0);
  expect(heldAfter.replaySurfaceTime).toBe(0);
  expect((await diagnostics()).frame![H.TICK]).toBe(live.frame![H.TICK]);
  expect((await diagnostics()).recordingWarnings).toEqual([]);
  await page.screenshot({ path: testInfo.outputPath('replay-first-frame.png') });
  await testInfo.attach('replay-ownership.json', {
    body: JSON.stringify(
      {
        seekObservation,
        sought,
        modal,
        modalAfter,
        blurred,
        endPause,
        settledEnd,
        restartedEnd,
        final: await diagnostics(),
      },
      null,
      2,
    ),
    contentType: 'application/json',
  });
  await page.getByRole('button', { name: 'RETURN', exact: true }).click();
  await expect(page.getByRole('button', { name: 'RESUME SESSION' })).toBeVisible();
  expect((await diagnostics()).audio.playing).toBe(false);
  expect((await diagnostics()).frame).toEqual(live.frame);
  expect(errors).toEqual([]);
});
