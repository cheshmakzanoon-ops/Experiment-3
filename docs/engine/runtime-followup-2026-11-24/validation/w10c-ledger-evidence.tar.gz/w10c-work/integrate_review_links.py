#!/usr/bin/env python3
"""Copy small retained review receipts and fix only the three assigned reviews."""
from pathlib import Path
import hashlib
import json
import datetime
import shutil

ROOT = Path('/tmp/engine-c71f32882729')
DOCS = ROOT / 'repo/docs/engine/runtime-followup-2026-11-24'
VALIDATION = DOCS / 'validation'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

copies = {
    'w10c-work/audit-initial.json': 'w10c-audit-initial.json',
    'w10c-work/strict-pending-demonstration.json': 'w10c-strict-pending-demonstration.json',
    'w10c-work/registration-anchor.json': 'w10c-registration-anchor.json',
    'w10c-work/validate-ledger.py': 'w10c-validate-ledger.py',
    'w10c-work/README.md': 'w10c-validator-readme.md',
    'w10d-work/source-review.json': 'w10d-source-review.json',
    'w10d-work/all-source-identities.json': 'w10d-all-source-identities.json',
    'w10d-work/production-baseline-to-final.patch': 'w10d-production-baseline-to-final.patch',
    'w10d-work/evidence-review.json': 'w10d-evidence-review.json',
    'w10d-work/operations.json': 'w10d-operations.json',
    'w10d-work/audit_source.py': 'w10d-audit-source.py',
}
e_files = [
    'commit-summary.json', 'ancestry-and-preservation.json', 'main-history.json',
    'main-close-snapshot.json', 'main-tree.json', 'source-and-fixture-continuity.json',
    'focused-workflow.yml', 'focused-workflow-after7.patch', 'artifact-list.json',
    'artifact-archive-manifest.json', 'focused-run.json', 'focused-jobs.json',
    'focused-evidence-review.json', 'playwright-report.json', 'recording-stall-continuity.json',
    'browser-backend.json', 'build-identity.json', 'broad-status-summary.json',
    'broad-unit-log-review.json', 'broad-unit-reconciliation.json', 'evidence-index.json',
    'operations.json', 'review-evidence.py',
] + [f'checkpoint{i}-commit.json' for i in range(1, 10)]
for name in e_files:
    copies['w10e-work/' + name] = 'w10e-' + name
receipts = []
for source, name in copies.items():
    src, dst = ROOT / source, VALIDATION / name
    if dst.exists() and sha(src) != sha(dst):
        raise RuntimeError('Existing receipt differs; refusing overwrite: ' + str(dst))
    reused = dst.exists()
    if not reused:
        shutil.copyfile(src, dst)
    receipts.append({'source': str(src), 'integrated_path': 'validation/' + name,
                     'bytes': dst.stat().st_size, 'sha256': sha(dst), 'reused_existing_identical_file': reused})

paths = {k: DOCS / 'reviews' / v for k, v in {
    'c': 'w10c-ledger-audit.md', 'd': 'w10d-final-engine-review.md',
    'e': 'w10e-publication-verification.md'}.items()}
before = {k: p.read_text() for k, p in paths.items()}
texts = dict(before)
d_map = {
    'w10d-work/source-review.json': '../validation/w10d-source-review.json',
    'w10d-work/all-source-identities.json': '../validation/w10d-all-source-identities.json',
    'w10d-work/production-baseline-to-final.patch': '../validation/w10d-production-baseline-to-final.patch',
    'w10d-work/evidence-review.json': '../validation/w10d-evidence-review.json',
    'w10d-work/operations.json': '../validation/w10d-operations.json',
    'w10d-work/audit_source.py': '../validation/w10d-audit-source.py',
    'w10a.md': 'w10a-regression-triage.md',
    'w09a-final/results-summary.json': '../validation/w09a-final-results.json',
    'w09b-work/w09b-static-build-manifest.json': '../validation/w09b-static-build-manifest.json',
    'checkpoint9-ci.json': '../validation/checkpoint9-ci.json',
    'w09c-native-gate-manifest.json': '../validation/w09c-native-gate-manifest.json',
    'w09c-case-results.json': '../validation/w09c-case-results.json',
    'w09c.md': 'w09c-native-final.md',
    'w09f-draft/validation/checkpoint9-broad-unit-summary.json': '../validation/checkpoint9-broad-unit-summary.json',
    'w10b.md': 'w10b-performance-claims.md',
}
for old, new in d_map.items():
    assert '(' + old + ')' in texts['d'], old
    texts['d'] = texts['d'].replace('(' + old + ')', '(' + new + ')')

c_map = {
    '`w10c-work/strict-pending-demonstration.json`': '[dated strict audit receipt](../validation/w10c-strict-pending-demonstration.json)',
    '`strict-pending-demonstration.json.errors`': '[dated strict audit errors](../validation/w10c-strict-pending-demonstration.json)',
    '`audit-initial.json`': '[initial audit receipt](../validation/w10c-audit-initial.json)',
    '`w10c-work/audit-initial.json`': '[initial audit receipt](../validation/w10c-audit-initial.json)',
    '`WAVE01-02.md`': '[Waves 1–2 reconstruction](../WAVE01-02.md)',
    '`COMMIT-HISTORY.md`': '[commit history](../COMMIT-HISTORY.md)',
    '`AGENTS.json`': '[AGENTS.json](../AGENTS.json)',
    '`TASKS.md`': '[TASKS.md](../TASKS.md)',
    '`w10c-work/validate-ledger.py`': '[retained validator source](../validation/w10c-validate-ledger.py)',
    '`w10c-work/registration-anchor.json`': '[registration anchor](../validation/w10c-registration-anchor.json)',
    '`w10c-work/README.md`': '[validator instructions](../validation/w10c-validator-readme.md)',
}
for old, new in c_map.items():
    texts['c'] = texts['c'].replace(old, new)

texts['e'] = texts['e'].replace(
    'tree **`2224939844137abcd06d1aed0d9618f74e05dc18`**, whose direct parent is checkpoint 9.',
    'tree **`2224939844137abcd06d1aed0d9618f74e05dc18`**, a direct child of checkpoint 9: its parent is **`9119c7683d821d145f15ed64a03ee3406595b58d`**.')
e_link_names = {name: 'w10e-' + name for name in e_files}
# Exact named receipts become links; bulky archived reports remain explicit plain-text names.
for old, new in e_link_names.items():
    texts['e'] = texts['e'].replace('`' + old + '`', '[' + old + '](../validation/' + new + ')')
for old, new in {
    '`w09e.md`': '[protected scope review](w09e-protected-scope.md)',
    '`w10a.md`': '[regression review](w10a-regression-triage.md)',
    '`w09d.md`': '[earlier published-CI review](w09d-published-ci.md)',
}.items():
    texts['e'] = texts['e'].replace(old, new)
texts['e'] = texts['e'].replace('`w09d.md`/`w10a.md`', '[earlier published-CI review](w09d-published-ci.md)/[regression review](w10a-regression-triage.md)')
# Independently downloaded focused log is byte-identical to the integrated raw log.
assert sha(ROOT / 'w10e-work/focused-job.log') == sha(VALIDATION / 'checkpoint9-ci.log')
texts['e'] = texts['e'].replace('`focused-job.log`', '[focused-job.log](../validation/checkpoint9-ci.log)')
texts['e'] = texts['e'].replace('`checkpoint1-commit.json` through `checkpoint9-commit.json`',
    '[checkpoint1-commit.json](../validation/w10e-checkpoint1-commit.json) through [checkpoint9-commit.json](../validation/w10e-checkpoint9-commit.json)')
report_changes = []
for key, path in paths.items():
    assert texts[key] != before[key], key
    path.write_text(texts[key])
    report_changes.append({'path': str(path.relative_to(DOCS)),
                           'before_sha256': hashlib.sha256(before[key].encode()).hexdigest(),
                           'after_sha256': sha(path)})
manifest = {
    'worker': 57, 'same_assignment_followup': True,
    'captured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Only assigned W10C/W10D/W10E review links, explicit W10E parent-direction wording, and small retained validation receipts.',
    'copied_receipts': receipts, 'reviews': report_changes,
    'bulk_exclusions': ['baseline source archive', 'dependencies', 'dist', 'night trace ZIP', 'focused CI ZIP preserved separately by coordinator'],
    'status_policy': 'Dated completion and remote-publication pending facts are retained. This followup is not another worker.'}
(VALIDATION / 'w10c-document-link-integration.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'receipt_entries': len(receipts), 'new_files': sum(not r['reused_existing_identical_file'] for r in receipts),
                  'new_bytes': sum(r['bytes'] for r in receipts if not r['reused_existing_identical_file']),
                  'review_files': [r['path'] for r in report_changes]}, indent=2))
