/** Parse source declarations and hash bytes only; do not execute engine source. */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const root = '/tmp/engine-c71f32882729/repo';
const require = createRequire(root + '/package.json');
const ts = require('typescript');
const commits = {
  baseline: '1c609bfa7006ee2c51a32a97f1fedd61c6c1bfcb',
  measuredW07: 'f4d41b0c00fa7b69f35ba1b1f48b67541e3749b6',
  final9: '9119c7683d821d145f15ed64a03ee3406595b58d',
};
const sourceCache = new Map();
const hash = (s) => createHash('sha256').update(s).digest('hex');
function source(role, path) {
  const key = role + ':' + path;
  if (!sourceCache.has(key)) {
    const bytes = execFileSync('git', ['-c', 'protocol.allow=never', 'cat-file', 'blob', `${commits[role]}:${path}`],
      { cwd: root, env: { ...process.env, GIT_NO_LAZY_FETCH: '1' } });
    const text = bytes.toString('utf8');
    sourceCache.set(key, { text, file: ts.createSourceFile(path, text, ts.ScriptTarget.Latest, true) });
  }
  return sourceCache.get(key);
}
function declaration(role, path, name, member) {
  const { file } = source(role, path);
  const node = file.statements.find(s => (ts.isClassDeclaration(s) || ts.isFunctionDeclaration(s)) && s.name?.text === name);
  if (!node) throw new Error(`Declaration missing: ${role}:${path}:${name}`);
  if (!member) return node.getText(file);
  const method = node.members.find(s => member === 'constructor' ? ts.isConstructorDeclaration(s) : s.name?.getText(file) === member);
  if (!method) return null;
  return method.getText(file);
}
const targets = [
  ['src/simulation/bvh.ts', 'TriangleBVH', 'constructor'],
  ['src/simulation/bvh.ts', 'TriangleBVH', 'build'],
  ['src/simulation/contact.ts', 'TrackContactMesh', 'constructor'],
  ['src/simulation/road-contact.ts', 'RoadContactFrame', 'set'],
  ['src/simulation/vehicle.ts', 'Vehicle', 'coupleClutch'],
  ['src/net/server.ts', 'RaceServer', 'snapshot'],
  ['src/net/server.ts', 'RaceServer', 'sendData'],
  ['src/net/server.ts', 'RaceServer', 'send'],
  ['src/net/server.ts', 'RaceServer', 'transportError'],
  ['src/net/server.ts', 'RaceServer', 'closeTransport'],
  ['src/net/server.ts', 'RaceServer', 'startGrid'],
  ['src/net/server.ts', 'RaceServer', 'endRace'],
  ['src/net/authority.ts', 'AuthoritativeWorld', 'capture'],
  ['src/net/authority.ts', 'AuthoritativeWorld', 'acceleration'],
  ['src/net/authority.ts', 'AuthoritativeWorld', 'clearContacts'],
  ['src/net/authority.ts', 'AuthoritativeWorld', 'tick'],
  ['src/net/input.ts', 'ServerInputQueue', 'takeSlack'],
  ['src/net/input.ts', 'quantizeControls'],
  ['src/net/input.ts', 'writeControls'],
  ['src/net/input.ts', 'readControls'],
  ['src/storage/recorders.ts', 'TelemetryRecorder', 'snapshot'],
  ['src/storage/telemetry-schema.ts', 'packTelemetry'],
  ['src/storage/telemetry-schema.ts', 'telemetryCsv'],
  ['src/rendering/texture-budget.ts', 'TextureBudget', 'register'],
  ['src/rendering/texture-budget.ts', 'TextureBudget', 'apply'],
  ['src/rendering/texture-budget.ts', 'TextureBudget', 'refresh'],
  ['src/rendering/texture-budget.ts', 'TextureBudget', 'unregister'],
  ['src/rendering/imported-texture-budget.ts', 'ImportedTextureBudget', 'register'],
  ['src/rendering/imported-texture-budget.ts', 'ImportedTextureBudget', 'apply'],
  ['src/rendering/imported-texture-budget.ts', 'ImportedTextureBudget', 'unregister'],
];
const methods = targets.map(([path, name, member]) => {
  const strings = Object.fromEntries(Object.keys(commits).map(role => [role, declaration(role, path, name, member)]));
  if (strings.measuredW07 === null || strings.final9 === null) throw new Error(`Measured/final method missing: ${name}.${member}`);
  return { path, declaration: [name, member].filter(Boolean).join('.'),
    hashes: Object.fromEntries(Object.entries(strings).map(([role, text]) => [role, text === null ? null : hash(text)])),
    bytes: Object.fromEntries(Object.entries(strings).map(([role, text]) => [role, text === null ? null : Buffer.byteLength(text)])),
    measuredW07EqualsFinal9: strings.measuredW07 === strings.final9 };
});
const guard = "    // Scalar stores cannot detect a truncated allocation from fractional rows.\n    if (!Number.isInteger(rows) || rows < 1)\n      throw new RangeError('Contact mesh rows must be a positive integer');\n";
const contactW07 = source('measuredW07', 'src/simulation/contact.ts').text;
const contactFinal = source('final9', 'src/simulation/contact.ts').text;
const contactGuardOnly = {
  removedTextForComparisonOnly: guard,
  exactlyOneOccurrence: contactFinal.split(guard).length === 2,
  finalWithoutAddedGuardEqualsEntireMeasuredFile: contactFinal.replace(guard, '') === contactW07,
  measuredFileSha256: hash(contactW07), finalFileSha256: hash(contactFinal),
};
const result = {
  purpose: 'Read-only declaration parsing and exact UTF-8 byte hashing; no compiler, emitted code, engine execution or benchmark.',
  commits, parser: `TypeScript ${ts.version} createSourceFile; getText excludes leading comment trivia; method body bytes are not normalized.`,
  methods, contactGuardOnly,
};
writeFileSync('/tmp/engine-c71f32882729/w10b-work/method-identity.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ methods: methods.length, same: methods.filter(m => m.measuredW07EqualsFinal9).length,
  changed: methods.filter(m => !m.measuredW07EqualsFinal9).map(m => m.declaration), contactGuardOnly }, null, 2));
for (const m of methods) console.log(m.declaration, m.measuredW07EqualsFinal9 ? 'identical' : 'changed', m.hashes.final9);
