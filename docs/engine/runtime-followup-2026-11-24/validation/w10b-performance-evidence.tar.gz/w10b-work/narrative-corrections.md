# Exact narrative corrections for root integration

No repository files were edited. Preserve every raw JSON, sample, outlier and original rl2 timing. These are documentation corrections and attribution additions only.

## 1. Required: do not claim a proven noise explanation

File: `docs/engine/runtime-followup-2026-11-24/measurements/w07b-contact.md`

Replace exactly:

> Negative change means the candidate was faster for that paired sample. A mixed-sign paired range is evidence of timing noise. Raw samples and warmups are retained in the adjacent JSON.

With:

> Negative change means the candidate was faster for that paired sample. A mixed-sign paired range shows observed variability; it does not establish its cause. Raw samples and warmups are retained in the adjacent JSON.

The later unresolved-slowdown discussion and the +9.964549759% value remain unchanged.

## 2. Required attribution addition to final README measurement section

Append after the paragraph identifying the Wave 7 and Wave 8 measurement checkpoints:

> These timings remain observations from their pinned measurement sessions. Final-source inspection confirms that the measured BVH, snapshot, quantizer, recorder snapshot, road-frame and texture registration methods remain byte-identical. Later grid/results callback guards and texture unregister changes are outside those timed paths. The contact constructor gained a positive-integer guard after Wave 7 and was not retimed. Wave 8's measured current CSV dependency graph matches the final production source. None of these source-identity checks is a new timing run of the final build.

For the Simulation paragraph, replace its first sentence with:

> At the Wave 7 baseline/candidate source checkpoints, three actual Simulation scenarios—formula, wet motorcycle and motocross—each ran 1,200 ticks / ten simulated seconds, with 617,181,316 serialized trace bytes identical across the two source graphs.

Retain the existing next sentence limiting capture to packed frames, exposed dynamic state and specified checkpoints. Add if room permits:

> The later contact constructor guard was checked separately; these traces were not regenerated on the final build.

## 3. Texture timer is elapsed time, not process CPU time

File: `docs/engine/runtime-followup-2026-11-24/measurements/w07f-texture.md`

Replace `Registration CPU time improved in all 36 measured pairs on this controlled Node fixture.` with `Elapsed registration time improved in all 36 measured pairs on this controlled Node fixture.`

Replace heading `## Paired CPU timing` with `## Paired elapsed registration timing`.

The existing explanation that `performance.now` intervals include runtime pauses and exclude canvas rasterization/GPU work remains intact. Final IMPLEMENTATION may say “measures elapsed registration time for CPU-side work” instead of “measures registration CPU work.” The draft README's “controlled Node registration with a simplified canvas substitute” is already suitable.

## 4. Optional precision in the contact operation inventory

In the final README, replace `237,583 temporary array/set operations` with `237,583 temporary array literals and their matching typed-array set calls`.

This is a source-level count: 122,895 normal literals/calls plus 114,688 index literals/calls. It is not a measurement of allocated heap objects after JIT optimization, heap bytes or GC time.

## 5. Optional wording precision for pooled BVH medians

File: `docs/engine/runtime-followup-2026-11-24/measurements/w07a-bvh-measurement.md`

Replace `The balanced overall medians average across both positions; they must not be promoted as universal percentage improvements.` with `The overall medians summarize the pooled samples from both balanced execution positions; they must not be promoted as universal percentage improvements.`

Do not change the underlying values. Aurel's exact independent-median reduction is 37.113682787% and its paired reduction is 33.107494232%; Poggio's respective values are 57.360062457% and 53.900922859%.

## 6. Maintain these existing draft limits

- Keep Node CSV high-water RSS labeled as process-lifetime through export, before verification, including startup/fixture/warmups. Do not call 628.602→370.602 MiB browser memory or exact live peak memory.
- Keep the 18 exact default exports, 115,038,761-byte result, unchanged retained payload and 216,000-row case unmeasured. Code-unit counts are not heap-byte counts.
- Keep imported texture draws at 1→1, already-shared storage, and initial disposal events at 1,025→2,048.
- Keep original rl2 +9.96455%, independent near-neutral W07E results, all outliers, and no natural-vehicle throughput claim.
- Keep BVH/query, quantization, contact and Simulation equivalence restricted to the documented finite cases. Native pixel/PCM equivalence is also fixture/reference-scoped.
- Final unit/build/native gate totals are correctness coverage, not performance gains. Never add overlapping gates into a unique grand total.
