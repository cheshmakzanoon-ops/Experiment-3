"""Audit retained manifests using local Git metadata and byte hashing only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/tmp/engine-c71f32882729/repo')
OUT = Path('/tmp/engine-c71f32882729/w10b-work')
M = ROOT / 'docs/engine/runtime-followup-2026-11-24/measurements'
BASE = '1c609bfa7006ee2c51a32a97f1fedd61c6c1bfcb'
MEASURED = 'f4d41b0c00fa7b69f35ba1b1f48b67541e3749b6'
CSV7 = '6a6bf02eb2d89eeb6aeff32769ef3deb4a49f17c'
FIXTURE8 = '811ac2bc92f4494b1ec99d1fc4201101ccf34c66'
FINAL9 = '9119c7683d821d145f15ed64a03ee3406595b58d'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')
checks, entries = [], []


def git(*args, input=None):
    return subprocess.run(['git', '-c', 'protocol.allow=never', *args], cwd=ROOT,
                          env=ENV, input=input, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout


def read(name):
    return json.loads((M / name).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def check(label, a, b):
    checks.append({'claim': label, 'actual': a, 'expected': b, 'matches': a == b})


def collect(label, records, refs=None):
    for entry in records:
        commit = entry.get('commit') or refs[entry['role']]
        entries.append({'measurement': label, 'role': entry.get('role') or entry.get('version') or entry.get('variant'), 'commit': commit, 'path': entry['path'],
                        'blob': entry.get('blob') or entry['gitBlob'], 'sha256': entry['sha256']})


a = read('w07a-bvh-raw.json')
b = read('w07b-contact.json')
c = read('w07c-network.json')
cs = read('w07c-network.sources.json')
d = read('w07d-telemetry-raw.json')
db = read('w07d-telemetry-browser.json')
e = read('w07e-simulation.json')
f = read('w07f-texture.json')
csv = read('w08c-csv-memory-raw.json')
collect('w07a', a['sources']['files'])
collect('w07b', b['harness']['sourceGraph'])
collect('w07c', cs['modules'], cs['refs'])
collect('w07d/node', d['sources'], d['refs'])
collect('w07d/browser', db['sources'], db['refs'])
for role, graph in e['harness']['variants'].items():
    collect('w07e/' + role, graph['sources'])
    check('w07e/' + role + '/source-graph-hash',
          sha('\n'.join(f"{s['path']}\0{s['sha256']}" for s in graph['sources']).encode()),
          graph['sourceGraphSHA256'])
collect('w07f', f['sources']['sourceGraph'])
collect('w08c', csv['sources'], {'baseline': MEASURED, 'current': FINAL9})
check('w07c/dependency-manifest-hash', sha(json.dumps(cs['modules'], ensure_ascii=False, separators=(',', ':')).encode()), c['metadata']['dependencyManifestSha256'])

commits = sorted({s['commit'] for s in entries} | {BASE, MEASURED, CSV7, FIXTURE8, FINAL9})
trees = {}
for commit in commits:
    tree = {}
    for raw in git('ls-tree', '-rz', commit).split(b'\0'):
        if not raw:
            continue
        metadata, path = raw.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        tree[path.decode()] = {'mode': mode, 'type': kind, 'blob': oid}
    trees[commit] = tree

blob_ids = sorted({s['blob'] for s in entries})
stream = git('cat-file', '--batch', input=('\n'.join(blob_ids) + '\n').encode())
pos, blobs = 0, {}
for requested in blob_ids:
    end = stream.index(b'\n', pos)
    header = stream[pos:end].decode().split()
    if len(header) == 2 and header[1] == 'missing':
        blobs[requested] = None
        pos = end + 1
        continue
    oid, kind, length = header
    size = int(length)
    content = stream[end + 1:end + 1 + size]
    pos = end + 1 + size + 1
    check('git/blob-response/' + requested, oid, requested)
    check('git/blob-type/' + requested, kind, 'blob')
    blobs[requested] = content

for entry in entries:
    label = entry['measurement'] + '/' + entry['path']
    check(label + '/tree-path-blob', trees[entry['commit']].get(entry['path'], {}).get('blob'), entry['blob'])
    content = blobs[entry['blob']]
    check(label + '/content-sha256', sha(content) if content is not None else 'MISSING_LOCAL_OBJECT', entry['sha256'])

checkpoint_trees = {commit: {'rootTree': git('rev-parse', commit + '^{tree}').decode().strip(),
                             'srcTree': git('rev-parse', commit + ':src').decode().strip()}
                    for commit in [BASE, MEASURED, CSV7, FIXTURE8, FINAL9]}
check('final-root-tree', checkpoint_trees[FINAL9]['rootTree'], '3b704f846c3283c21e73f8f5c3febf670a773c63')
check('production-src7-src8', checkpoint_trees[CSV7]['srcTree'], checkpoint_trees[FIXTURE8]['srcTree'])
check('production-src8-src9', checkpoint_trees[FIXTURE8]['srcTree'], checkpoint_trees[FINAL9]['srcTree'])

candidate_graph_differences = {}
for label in sorted({s['measurement'] for s in entries}):
    candidate = [s for s in entries if s['measurement'] == label and s['commit'] in [MEASURED, FINAL9]
                 and not (label == 'w08c' and s['role'] != 'current')]
    candidate_graph_differences[label] = [{'path': s['path'], 'measuredBlob': s['blob'],
                                         'finalBlob': trees[FINAL9].get(s['path'], {}).get('blob')}
                                        for s in candidate if s['blob'] != trees[FINAL9].get(s['path'], {}).get('blob')]

file_targets = sorted({s['path'] for s in entries if s['commit'] == FINAL9} |
                      {'src/simulation/bvh.ts', 'src/simulation/contact.ts', 'src/simulation/road-contact.ts',
                       'src/simulation/vehicle.ts', 'src/net/server.ts', 'src/net/input.ts',
                       'src/net/authority.ts', 'src/net/bytes.ts', 'src/net/codec.ts', 'src/net/snapshot.ts',
                       'src/storage/recorders.ts', 'src/storage/telemetry-schema.ts',
                       'src/rendering/texture-budget.ts', 'src/rendering/imported-texture-budget.ts',
                       'src/rendering/foliage-mipmaps.ts'})
final_files = []
for path in file_targets:
    current_blob = trees[FINAL9][path]['blob']
    content = (ROOT / path).read_bytes()
    actual_blob = hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()
    check('working-tree/' + path, actual_blob, current_blob)
    final_files.append({'path': path, 'measuredBlob': trees[MEASURED][path]['blob'], 'finalBlob': current_blob,
                        'sha256': sha(content), 'fullFileIdenticalW07ToFinal': trees[MEASURED][path]['blob'] == current_blob})

harness_pairs = [
    ('engine-followup-bvh.mjs', a['sources']['harnessSha256']),
    ('engine-followup-bvh.runner.mjs', a['sources']['runnerSha256']),
    ('engine-followup-contact.mjs', b['harness']['orchestratorSHA256']),
    ('engine-followup-contact.worker.mjs', b['harness']['workerSHA256']),
    ('engine-followup-network.mjs', c['metadata']['runnerSha256']),
    ('engine-followup-network-workload.mjs', c['metadata']['workloadSha256']),
    ('engine-followup-simulation.mjs', e['harness']['orchestratorSHA256']),
    ('engine-followup-simulation.worker.mjs', e['harness']['workerSHA256']),
    ('engine-followup-texture.mjs', f['sources']['orchestratorSHA256']),
    ('engine-followup-texture.worker.mjs', f['sources']['workerSHA256']),
]
for name, expected in harness_pairs:
    check('harness/' + name, sha((ROOT / 'scripts/bench' / name).read_bytes()), expected)

archive_entries = []
for name in ['w07d-telemetry-manifest.json', 'w08c-csv-memory-manifest.json']:
    manifest = read(name)
    files = manifest.get('files', []) + manifest.get('finalFormattedScripts', []) + manifest.get('measurementFiles', []) + manifest.get('harnessAtMeasurement', [])
    for file in files:
        content = (ROOT / file['path']).read_bytes()
        check(name + '/' + file['path'] + '/sha256', sha(content), file['sha256'])
        check(name + '/' + file['path'] + '/size', len(content), file['bytes'])
    archive = manifest['archive']
    content = (ROOT / archive['path']).read_bytes()
    check(name + '/archive-hash', sha(content), archive['sha256'])
    with tarfile.open(ROOT / archive['path']) as tar:
        for entry in manifest['timedBundles']:
            key = entry.get('archiveEntry') or entry['filename']
            content = tar.extractfile(key).read()
            check(name + '/bundle/' + key + '/sha256', sha(content), entry['sha256'])
            check(name + '/bundle/' + key + '/size', len(content), entry['bytes'])
            archive_entries.append({'archive': archive['path'], 'entry': key, 'sha256': sha(content)})

result = {
    'purpose': 'Read-only local source and manifest audit. GIT_NO_LAZY_FETCH=1; git -c protocol.allow=never. No builds, tests, benchmarks, Git mutation or network.',
    'checkpointTrees': checkpoint_trees,
    'manifestSourceEntries': len(entries), 'uniqueSourceBlobs': len(blob_ids),
    'candidateGraphDifferencesFromFinal9': candidate_graph_differences,
    'finalSourceFiles': final_files, 'archiveEntriesVerified': archive_entries,
    'checks': checks, 'discrepancies': [c for c in checks if not c['matches']],
}
(OUT / 'source-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['manifestSourceEntries', 'uniqueSourceBlobs', 'candidateGraphDifferencesFromFinal9', 'discrepancies']}, indent=2))
print('checks', len(checks))
