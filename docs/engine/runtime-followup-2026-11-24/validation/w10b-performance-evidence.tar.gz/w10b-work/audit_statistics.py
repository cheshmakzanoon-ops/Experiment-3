"""Read retained JSON and recompute arithmetic only; never run benchmark code."""
import hashlib
import json
import math
from pathlib import Path
from statistics import median

ROOT = Path('/tmp/engine-c71f32882729/repo')
MEASUREMENTS = ROOT / 'docs/engine/runtime-followup-2026-11-24/measurements'
OUT = Path('/tmp/engine-c71f32882729/w10b-work')
checks = []
summaries = []


def read(name):
    return json.loads((MEASUREMENTS / name).read_text())


def check(label, actual, reported):
    equal = (math.isclose(actual, reported, rel_tol=1e-12, abs_tol=1e-9)
             if isinstance(actual, (int, float)) and not isinstance(actual, bool)
             else actual == reported)
    checks.append({'claim': label, 'recomputed': actual, 'reported': reported, 'matches': equal})


def desc(xs):
    return {'median': median(xs), 'min': min(xs), 'max': max(xs)}


def paired(name, before, after, unit='ms'):
    ratios = [b / a for a, b in zip(before, after)]
    reductions = [(1 - r) * 100 for r in ratios]
    result = {
        'name': name, 'unit': unit, 'pairs': len(before),
        'before': desc(before), 'after': desc(after),
        'afterOverBefore': desc(ratios),
        'pairedReductionPercent': desc(reductions),
        'pairedSpeedRatio': desc([a / b for a, b in zip(before, after)]),
        'reductionOfIndependentMediansPercent': (1 - median(after) / median(before)) * 100,
        'fasterPairs': sum(b < a for a, b in zip(before, after)),
        'pairsRaw': [{'before': a, 'after': b} for a, b in zip(before, after)],
    }
    summaries.append(result)
    return result


bvh = read('w07a-bvh-raw.json')
for case in bvh['cases']:
    grouped = {}
    for sample in case['samples']:
        grouped.setdefault(sample['pair'], {})[sample['version']] = int(sample['durationNs']) / 1e6
        check('bvh duration conversion', int(sample['durationNs']) / 1e6, sample['milliseconds'])
    pairs = [grouped[k] for k in sorted(grouped)]
    result = paired('bvh/' + case['fixture']['circuit'],
                    [p['baseline'] for p in pairs], [p['current'] for p in pairs])
    for version, label in [('baseline', 'before'), ('current', 'after')]:
        for stat, key in [('median', 'median'), ('min', 'minimum'), ('max', 'maximum')]:
            check(result['name'] + '/' + version + '/' + stat, result[label][stat], case['summary'][version + 'Ms'][key])
    check(result['name'] + '/paired-reduction', result['pairedReductionPercent']['median'], case['summary']['pairedReductionPercent']['median'])
    check(result['name'] + '/independent-reduction', result['reductionOfIndependentMediansPercent'], case['summary']['reductionOfMediansPercent'])
    check(result['name'] + '/geometry-hash', case['fixture']['hashesBefore'], case['fixture']['hashesAfter'])

contact = read('w07b-contact.json')
contact_cases = ([('constructor/' + c['circuitId'], c) for c in contact['results']['construction']['scenarios']]
                 + [('frame', contact['results']['frame']), ('dormant-awd', contact['results']['clutch'])]
                 + [('vehicle/' + c['vehicleId'], c) for c in contact['results']['substeps']['scenarios']])
for label, case in contact_cases:
    result = paired('contact/' + label, [p['baseline']['elapsedMs'] for p in case['samples']],
                    [p['candidate']['elapsedMs'] for p in case['samples']])
    check(result['name'] + '/before-median', result['before']['median'], case['summary']['baseline']['median'])
    check(result['name'] + '/after-median', result['after']['median'], case['summary']['candidate']['median'])
    check(result['name'] + '/paired-change', -result['pairedReductionPercent']['median'], case['summary']['pairedChangePercent']['median'])
    check(result['name'] + '/favorable-pairs', result['fasterPairs'], case['summary']['candidateFasterPairs'])
    for p in case['samples']:
        check(result['name'] + '/timed-sink', p['baseline']['checksum'], p['candidate']['checksum'])

network = read('w07c-network.json')
for label, case in [(f'snapshot/{c["recipients"]}', c) for c in network['snapshotTimings']] + [('quantizer', network['controlTiming'])]:
    scale = 1e6 / case['iterationsPerSample']
    result = paired('network/' + label, [p['baselineMs'] * scale for p in case['samples']],
                    [p['currentMs'] * scale for p in case['samples']], unit='ns/op')
    for actual, reported in [('before', 'baselineNsPerOperation'), ('after', 'currentNsPerOperation'),
                             ('pairedSpeedRatio', 'pairedSpeedup'), ('pairedReductionPercent', 'pairedLatencyReductionPercent')]:
        for stat in ['median', 'min', 'max']:
            check(result['name'] + '/' + reported + '/' + stat, result[actual][stat], case['summary'][reported][stat])
check('quantizer/successful-case-count', network['controlEquivalence']['randomCount'] + network['controlEquivalence']['boundaryCount'] + network['controlEquivalence']['edgeCaseCount'], network['controlEquivalence']['compared'])
check('quantizer/wire-byte-count', network['controlEquivalence']['compared'] * 8, network['controlEquivalence']['wireBytes'])

telemetry = read('w07d-telemetry-raw.json')
for case in telemetry['snapshots']:
    before, after = [], []
    for p in case['pairs']:
        before.append(p['baseline']['elapsedMs'] / p['baseline']['iterations'])
        after.append(p['current']['elapsedMs'] / p['current']['iterations'])
    result = paired(f'telemetry/{case["capacity"]}/{case["state"]}', before, after)
    for actual, reported in [('before', 'baseline'), ('after', 'current'), ('pairedSpeedRatio', 'pairedBaselineOverCurrent')]:
        for stat in ['median', 'min', 'max']:
            check(result['name'] + '/' + reported + '/' + stat, result[actual][stat], case['summaryMs'][reported][stat])
    check(result['name'] + '/differing-bytes', case['exact']['differingBytes'], 0)
    check(result['name'] + '/typed-payload', case['exact']['rows'] * case['stride'] * 4, case['exact']['bytesCompared'])
check('telemetry/exact-byte-total', sum(c['exact']['bytesCompared'] for c in telemetry['snapshots']), 240412320)
check('telemetry/independence-count', sum(len(c['independenceUntimed']) for c in telemetry['snapshots']), 32)

simulation = read('w07e-simulation.json')
totals = {}
for run in simulation['runs']:
    if 'phases' not in run['result']:
        continue
    measured = run['result']['phases']['measured']
    total = {k: sum(s[k] for s in measured['samples']) for k in ['elapsedMs', 'cpuUserMs', 'cpuSystemMs']}
    for k, value in total.items():
        check(f'simulation/run/{run["sequence"]}/{k}', value, measured['totals'][k])
    totals[run['sequence']] = {**total, 'cpuMs': total['cpuUserMs'] + total['cpuSystemMs']}

for kind, comparisons in simulation['summary']['vehicles'].items():
    rounds = [r for r in simulation['vehicleRounds'] if r['vehicle'] == kind]
    for comparison in comparisons:
        a_role, b_role = comparison['before'], comparison['after']
        a = [totals[r['runs'][a_role]] for r in rounds]
        b = [totals[r['runs'][b_role]] for r in rounds]
        result = paired(f'simulation/vehicle/{kind}/{a_role}->{b_role}', [r['elapsedMs'] for r in a], [r['elapsedMs'] for r in b])
        result['pairedCPUChangePercent'] = desc([(bb['cpuMs'] / aa['cpuMs'] - 1) * 100 for aa, bb in zip(a, b)])
        check(result['name'] + '/before-median', result['before']['median'], comparison['beforeMs']['median'])
        check(result['name'] + '/after-median', result['after']['median'], comparison['afterMs']['median'])
        check(result['name'] + '/wall-change', -result['pairedReductionPercent']['median'], comparison['pairedWallChangePercent']['median'])
        check(result['name'] + '/cpu-change', result['pairedCPUChangePercent']['median'], comparison['pairedCPUChangePercent']['median'])
        check(result['name'] + '/favorable-pairs', result['fasterPairs'], comparison['afterFasterPairs'])
for kind, comparison in simulation['summary']['frames'].items():
    rounds = [r for r in simulation['frameRounds'] if r['kind'] == kind]
    a = [totals[r['runs']['baseline']] for r in rounds]
    b = [totals[r['runs']['candidate']] for r in rounds]
    result = paired(f'simulation/frame/{kind}', [r['elapsedMs'] for r in a], [r['elapsedMs'] for r in b])
    result['pairedCPUChangePercent'] = desc([(bb['cpuMs'] / aa['cpuMs'] - 1) * 100 for aa, bb in zip(a, b)])
    check(result['name'] + '/wall-change', -result['pairedReductionPercent']['median'], comparison['pairedWallChangePercent']['median'])
    check(result['name'] + '/cpu-change', result['pairedCPUChangePercent']['median'], comparison['pairedCPUChangePercent']['median'])
    check(result['name'] + '/favorable-pairs', result['fasterPairs'], comparison['afterFasterPairs'])
check('simulation/fresh-processes', len({r['result']['process']['pid'] for r in simulation['runs']}), 127)
check('simulation/exact-trace-byte-total', sum(p['comparison']['bytes'] for p in simulation['proof']), 617181316)

texture = read('w07f-texture.json')
for case in texture['timings']:
    before, after = [], []
    for p in case['samples']:
        before.append(sum(p['baseline']['durationsMs']) / len(p['baseline']['durationsMs']))
        after.append(sum(p['candidate']['durationsMs']) / len(p['candidate']['durationsMs']))
        check('texture/' + case['caseId'] + '/baseline-sample-mean', before[-1], p['baseline']['perRegistrationMs'])
        check('texture/' + case['caseId'] + '/candidate-sample-mean', after[-1], p['candidate']['perRegistrationMs'])
    result = paired('texture/' + case['caseId'], before, after)
    check(result['name'] + '/before-median', result['before']['median'], case['summary']['medianBaselineMsPerRegistration'])
    check(result['name'] + '/after-median', result['after']['median'], case['summary']['medianCandidateMsPerRegistration'])
    check(result['name'] + '/paired-change', -result['pairedReductionPercent']['median'], case['summary']['medianPairedChangePercent'])
    check(result['name'] + '/favorable-pairs', result['fasterPairs'], case['summary']['candidateFasterPairs'])

csv = read('w08c-csv-memory-raw.json')
node = paired('csv/node-export', [p['baseline']['uninstrumentedElapsedMs'] for p in csv['nodePairs']], [p['current']['uninstrumentedElapsedMs'] for p in csv['nodePairs']])
rss = paired('csv/node-high-water-rss-through-export', [p['baseline']['immediatelyAfterExport']['processMaxRssKiB'] / 1024 for p in csv['nodePairs']], [p['current']['immediatelyAfterExport']['processMaxRssKiB'] / 1024 for p in csv['nodePairs']], unit='MiB')
browser = paired('csv/native-worker-completion', [p['baseline']['exportCompletionMs'] for p in csv['browserPairs']], [p['current']['exportCompletionMs'] for p in csv['browserPairs']])
for actual, role in [('before', 'baseline'), ('after', 'current')]:
    for stat in ['median', 'min', 'max']:
        check('csv/node/' + role + '/' + stat, node[actual][stat], csv['nodeSummary'][role]['elapsedMs'][stat])
        check('csv/rss/' + role + '/' + stat, rss[actual][stat] * 1024, csv['nodeSummary'][role]['processMaxRssKiBBeforeVerification'][stat])
        check('csv/browser/' + role + '/' + stat, browser[actual][stat], csv['browserSummary'][role + 'Ms'][stat])
check('csv/node/paired-ratio', node['afterOverBefore']['median'], csv['nodeSummary']['pairedCurrentOverBaselineMs']['median'])
check('csv/browser/paired-ratio', browser['afterOverBefore']['median'], csv['browserSummary']['pairedCurrentOverBaselineMs']['median'])
exports = [p[role] for p in csv['nodePairs'] + csv['browserPairs'] for role in ['baseline', 'current']] + list(csv['observed'].values())
check('csv/full-exports', len(exports), 18)
for i, export in enumerate(exports):
    check(f'csv/exact/{i}/bytes', export['exact']['comparedBytes'], 115038761)
    check(f'csv/exact/{i}/differences', export['exact']['differingBytes'], 0)
check('contact/road-frame-cases', contact['results']['proof']['frames']['cases'], 2070)
check('contact/paired-substeps', sum(r['substeps'] for r in contact['results']['proof']['trajectories']), 960)
check('contact/mesh-fixtures', len(contact['results']['proof']['geometry']), 8)
check('contact/literal-array-set-paths', (8192 + 1) * 15 + 8192 * 14, 237583)

result = {
    'purpose': 'Independent raw-data arithmetic audit only; no benchmarks or tests run.',
    'statisticsDefinitions': {
        'independentMedians': 'median(before samples), median(after samples)',
        'pairedReductionPercent': 'median(100 * (1 - after_i / before_i))',
        'pairedSpeedRatio': 'median(before_i / after_i)',
        'uncertainty': 'Observed min/max and favorable-pair counts only; no confidence intervals or significance claim.',
    },
    'rawFiles': [{'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(MEASUREMENTS.glob('*.json'))],
    'summaries': summaries, 'checks': checks, 'discrepancies': [c for c in checks if not c['matches']],
}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'statistics-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'workloads': len(summaries), 'checks': len(checks), 'discrepancies': result['discrepancies']}, indent=2))
for s in summaries:
    print(f"{s['name']}: {s['before']['median']:.9f} -> {s['after']['median']:.9f} {s['unit']}; paired reduction {s['pairedReductionPercent']['median']:.9f}%; faster {s['fasterPairs']}/{s['pairs']}")
