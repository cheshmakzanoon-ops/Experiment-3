"""Read-only metadata/log/trace correlation. Does not execute game or tests."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import re
import subprocess
import zipfile

ROOT = Path('/tmp/engine-c71f32882729')
REPO = ROOT / 'repo'
OUT = ROOT / 'w10a-work'
A = ROOT / 'w09a-work'
D = ROOT / 'w09d-work'
BASE = '1c609bfa7006ee2c51a32a97f1fedd61c6c1bfcb'
C7 = '6a6bf02eb2d89eeb6aeff32769ef3deb4a49f17c'
C8 = '811ac2bc92f4494b1ec99d1fc4201101ccf34c66'
C9 = '9119c7683d821d145f15ed64a03ee3406595b58d'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_ALLOW_PROTOCOL='none')
OPS = []

def git(*args):
    cmd = ['git', '-c', 'protocol.allow=never', *args]
    p = subprocess.run(cmd, cwd=REPO, env=ENV, capture_output=True, check=True)
    OPS.append({'argv': cmd, 'returncode': p.returncode})
    return p.stdout.decode()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def read(name):
    return json.loads(name.read_text())

def tree(revision, *paths):
    rows = {}
    for line in git('ls-tree', '-r', '--full-tree', revision, '--', *paths).splitlines():
        meta, path = line.split('\t', 1)
        rows[path] = meta.split()
    return rows

def blob_hash(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

source = {rev: tree(rev, 'src') for rev in (BASE, C7, C8, C9)}
changed = [p for p in source[C7] if source[BASE].get(p) != source[C7][p]]
working = []
for path in changed:
    data = (REPO / path).read_bytes()
    working.append({'path': path, 'blob': blob_hash(data), 'sha256': hashlib.sha256(data).hexdigest(),
                    'equals_checkpoint7': blob_hash(data) == source[C7][path][2]})
fixtures = ['tests/circuit-frame-transport.test.ts', 'tests/circuit-preparation-lifetime.test.ts',
            'tests/festival-renderer-loader-lifecycle.test.ts', 'tests/surface-channel-backpressure.test.ts']
identities = {rev: tree(rev, *fixtures, 'src/workers/frame-buffer-pool.ts', 'src/workers/surface-channel.ts',
                        'tests/frame-buffer-pool.test.ts', 'e2e/fixtures/scenery-shadow-budget.ts',
                        'e2e/scenery-shadow-budget.spec.ts') for rev in (BASE, C7, C8, C9)}
save('source-review.json', {'observed_utc': datetime.now(timezone.utc).isoformat(),
     'head': git('rev-parse', 'HEAD').strip(), 'head_tree': git('rev-parse', 'HEAD^{tree}').strip(),
     'status': git('status', '--short'), 'production_changed_paths_count': len(changed),
     'checkpoint7_8_src_identical': source[C7] == source[C8],
     'checkpoint7_9_src_identical': source[C7] == source[C9],
     'production_working_bytes': working, 'test_and_channel_identities': identities})
(OUT / 'published-fixture-corrections.patch').write_text(git('diff', '--no-ext-diff', '--no-textconv', C7, C9, '--', *fixtures))
(OUT / 'published-focused-workflow.patch').write_text(git('diff', '--no-ext-diff', '--no-textconv', C7, C9, '--', '.github/workflows/engine-runtime-validation.yml'))

ansi = re.compile(r'\x1b\[[0-9;]*m')
timestamp = re.compile(r'^\d{4}-\d\d-\d\dT\S+\s')
def lines(path):
    return [timestamp.sub('', ansi.sub('', l)) for l in path.read_text().splitlines()]

def failures(path):
    result = []
    for line in lines(path):
        if ' FAIL ' in line:
            name = line.split(' FAIL ', 1)[1].strip()
            file, title = name.split(' > ', 1)
            result.append((file, title))
    return result

def results(path):
    result = {}
    data = read(path)
    for f in data['testResults']:
        file = 'tests/' + Path(f['name']).name
        for a in f['assertionResults']:
            title = ' > '.join(a['ancestorTitles'] + [a['title']])
            result[(file, title)] = a['status']
    return result

baseline = results(A / 'baseline-unit-results.json') | results(A / 'surface-baseline.json')
corrected = results(A / 'correction-three-file-results.json') | results(A / 'surface-corrected.json')
baseline_content = {key: f'triage-job-{job}.log' for job in ('138728088710', '138728088792')
                    for key in failures(D / f'triage-job-{job}.log')}
correlated = []
partitions = []
for job in ('138970922124', '138970922114', '138970922195', '138970922130'):
    path = D / f'triage-job-{job}.log'
    found = failures(path)
    partitions.append({'job': job, 'failure_count': len(found),
                       'summaries': [l.strip() for l in lines(path) if 'Test Files ' in l or '      Tests ' in l]})
    for file, title in found:
        key = (file, title)
        newtitle = title
        if 'circuit-frame-transport' in file:
            category = 'terminal_frame_contract'
            for kind in ('write', 'post'):
                newtitle = newtitle.replace(f'recovers attached buffers after repeated {kind} failures without acknowledging an incomplete pause',
                                           f'keeps {kind} failures terminal until reinitialization restores the complete frame pool')
        elif 'surface-channel' in file:
            category = 'terminal_surface_contract'
            newtitle = newtitle.replace('rebases real terrain after a failed post consumed its incremental change set',
                                       'keeps a failed surface post terminal and rebases real terrain after fresh initialization')
        elif file in fixtures:
            category = 'renderer_fixture_omission'
        else:
            category = 'baseline_confirmed_content_i18n'
        correlated.append({'current_job': job, 'file': file, 'original_title': title, 'category': category,
                           'exact_baseline_case_status': baseline.get(key),
                           'baseline_failure_log': baseline_content.get(key),
                           'corrected_title': newtitle if file in fixtures else None,
                           'corrected_status': corrected.get((file, newtitle))})
save('unit-failure-correlation.json', {'partitions': partitions, 'failure_count': len(correlated),
     'counts': dict(Counter(r['category'] for r in correlated)), 'failures': correlated,
     'uncorrelated': [r for r in correlated if
                     (r['category'] == 'baseline_confirmed_content_i18n' and not r['baseline_failure_log']) or
                     (r['category'] != 'baseline_confirmed_content_i18n' and
                      (r['exact_baseline_case_status'] != 'passed' or r['corrected_status'] != 'passed'))]})

roots = []
for filename in ('baseline-tree.json', 'baseline-source-tree.json'):
    roots.append({x['path']: (x['mode'], x['type'], x['sha']) for x in read(D / filename)['tree']})
save('baseline-source-equivalence-review.json', {'root_entries': [len(x) for x in roots],
     'differing_entries': [p for p in sorted(roots[0].keys() | roots[1].keys()) if roots[0].get(p) != roots[1].get(p)]})

pairs = [
 ('high', 'job-138970725628.log', 'baseline-job-138730047979.log', 'graphics-high-journey.spec.ts'),
 ('escape', 'job-138970725874.log', 'baseline-job-138730047969.log', '36-compact-race-journey.spec.ts'),
 ('terrain', 'job-138970726025.log', 'baseline-job-138730047822.log', 'terrain-morph-contract.spec.ts'),
 ('aurel-startup', 'triage-job-138970724672.log', 'baseline-job-138730047877.log', '26-aurel-environment.spec.ts'),
 ('garage-startup', 'triage-job-138970724672.log', 'baseline-job-138730047932.log', '43-hero-garage.spec.ts'),
]
excerpts = []
for label, current, previous, spec in pairs:
    pair = {'label': label, 'spec': spec}
    for side, log in [('current', current), ('baseline_equivalent', previous)]:
        ls = lines(D / log)
        heads = [i for i, l in enumerate(ls) if re.match(r'\s*\d+\) e2e/' + re.escape(spec), l)]
        pair[side] = {'log': log, 'blocks': [{'line': i + 1, 'text': '\n'.join(ls[i:i+36])} for i in heads]}
    excerpts.append(pair)
save('browser-baseline-excerpts.json', excerpts)

night = []
for log in ('job-138970724148.log', 'baseline-job-138730048197.log', 'prior-job-138936090359.log', 'prebaseline-job-138713911270.log'):
    ls = lines(D / log)
    night.append({'log': log, 'matching_lines': [{'line': i+1, 'text': l[:600]} for i,l in enumerate(ls)
                 if 'scenery-shadow-budget.spec.ts' in l and ('✓' in l or '✘' in l or ':42:31' in l)]})
trace = D / 'scenery-night-selected/trace.zip'
trace_result = {'sha256': hashlib.sha256(trace.read_bytes()).hexdigest(), 'size': trace.stat().st_size, 'members': {}}
with zipfile.ZipFile(trace) as z:
    for name in z.namelist():
        if not name.endswith('.trace'):
            continue
        events = [json.loads(line) for line in z.read(name).splitlines() if line]
        before = {e['callId']: e for e in events if e.get('type') == 'before'}
        after = {e['callId'] for e in events if e.get('type') == 'after'}
        errors = [e for e in events if e.get('type') == 'error' or e.get('error') or
                  (e.get('type') == 'event' and e.get('method') in ('pageError','console'))]
        trace_result['members'][name] = {'event_counts': dict(Counter(e.get('type') for e in events)),
                                         'pending_calls': [e for k,e in before.items() if k not in after],
                                         'errors_or_console_events': errors}
save('night-review.json', {'history': night, 'trace': trace_result})
save('operations.json', {'description': 'Metadata, content hashing, and existing evidence parsing only; no game/test/build/browser execution.',
                         'git_environment': {k: ENV[k] for k in ('GIT_NO_LAZY_FETCH','GIT_OPTIONAL_LOCKS','GIT_ALLOW_PROTOCOL')}, 'git_operations': OPS})
print(json.dumps({'production_paths': len(changed), 'src_identical_7_to_9': source[C7] == source[C9],
                  'unit_failures': len(correlated), 'category_counts': dict(Counter(r['category'] for r in correlated)),
                  'uncorrelated': len(read(OUT / 'unit-failure-correlation.json')['uncorrelated']),
                  'output': str(OUT)}, indent=2))
