// Prepared external runner. Executes only when supplied an exact final commit
// and an already provisioned clean source worktree; no deployment/browser/full suite.
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, statSync, mkdirSync, existsSync, openSync, writeSync, closeSync } from 'node:fs';
import { resolve, relative, join, sep } from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
const [sourceArg,expectedCommit,outputArg]=process.argv.slice(2);
if(!sourceArg||!/^[a-f0-9]{40}$/.test(expectedCommit??'')||!outputArg)throw new Error('Usage: node --experimental-transform-types run-clean-review-validation.mjs <clean-source> <exact-final-commit> <fresh-external-output>');
const source=resolve(sourceArg),output=resolve(outputArg),dist=resolve(output,'dist');
if(output===source||output.startsWith(source+sep))throw new Error('All validation outputs must be outside the protected worktree');
const git=(...args)=>{const r=spawnSync('git',args,{cwd:source,encoding:'utf8',shell:false});if(r.status!==0)throw new Error(r.stderr||'git failed');return r.stdout;};
const actualCommit=git('rev-parse','HEAD').trim();
if(actualCommit!==expectedCommit)throw new Error(`Expected ${expectedCommit}, found ${actualCommit}; wait for the final source handoff`);
if(git('status','--porcelain','--untracked-files=no').trim())throw new Error('Tracked source is not clean; no checks started');
if(!existsSync(resolve(source,'node_modules/vitest/vitest.mjs')))throw new Error('Existing dependencies must be linked before freezing validation; no installer or link is created by this runner');
if(existsSync(output))throw new Error('Use a fresh output directory; prior validation evidence will not be overwritten');
const {snapshotSource,changedSource}=await import(pathToFileURL(resolve(source,'scripts/source-stability.ts')).href);
mkdirSync(output,{recursive:true});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const before=snapshotSource(source),digest=s=>hash(JSON.stringify([...s]));
writeFileSync(resolve(output,'protected-inputs-before.json.gz'),gzipSync(JSON.stringify([...before]),{mtime:0}));
const trackedNames=git('ls-files','-z').split('\0').filter(Boolean).sort();
const trackedDigest=()=>{const h=createHash('sha256');for(const name of trackedNames){h.update(name+'\0');h.update(readFileSync(resolve(source,name)));h.update('\0');}return h.digest('hex');};
const expectedTracked=trackedDigest();
function files(directory){return readdirSync(directory,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(join(directory,e.name)):[join(directory,e.name)]);}
const identityHash=createHash('sha256');
for(const path of [...files(resolve(source,'src')),resolve(source,'package-lock.json'),resolve(source,'index.html'),resolve(source,'vite.config.ts')].sort()){identityHash.update(relative(source,path).replaceAll('\\','/')+'\0');identityHash.update(readFileSync(path));identityHash.update('\0');}
const fingerprint=identityHash.digest('hex');
const checks=[
 {label:'lint',command:['npm','run','lint']},
 {label:'content',command:['npm','run','validate:content']},
 {label:'build',command:['npm','run','build','--','--outDir',dist]},
 {label:'bundle',command:['node','scripts/bundle-budget.mjs','--dist',dist],requiresBuild:true},
 {label:'ip',command:['node','scripts/ip-guard.mjs','--dist',dist],requiresBuild:true},
 {label:'startup-preparation-inspector',command:['npx','vitest','run','tests/startup.test.ts','tests/preparation.test.ts','tests/high-fragment-inspector.test.ts']},
];
const receipt={source,expectedCommit,actualCommit,started:new Date().toISOString(),status:'running',output,dist,scope:{fullUnit:false,browser:false,publication:false,productionEdits:false,sequential:true,niceness:10},inputFiles:before.size,inputDigest:digest(before),trackedFiles:trackedNames.length,trackedInputDigest:expectedTracked,expectedFingerprint:fingerprint,commands:checks.map(c=>({label:c.label,command:c.command})),results:[]};
const receiptPath=resolve(output,'receipt.json'),save=()=>writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n');save();
console.log(JSON.stringify({status:'started',commit:actualCommit,inputFiles:before.size,output}));
let sourceStable=true,buildPassed=false;
for(const check of checks){
 if(!sourceStable||check.requiresBuild&&!buildPassed){receipt.results.push({label:check.label,status:'not-run',reason:!sourceStable?'Protected source changed during preceding check':'No successful build to inspect'});save();continue;}
 const logPath=resolve(output,check.label+'.log'),fd=openSync(logPath,'w');
 const args=['-n','10',process.execPath,'--no-warnings','--experimental-transform-types','scripts/source-stability.ts','--',...check.command];
 const started=new Date().toISOString(),t0=performance.now();
 console.log(JSON.stringify({status:'check-started',label:check.label,commit:actualCommit}));
 const child=spawn('nice',args,{cwd:source,stdio:['ignore','pipe','pipe'],shell:false});
 child.stdout.on('data',data=>writeSync(fd,data));child.stderr.on('data',data=>writeSync(fd,data));
 let error;child.on('error',e=>{error=String(e);});
 const {code,signal}=await new Promise(done=>child.on('close',(code,signal)=>done({code,signal})));
 closeSync(fd);
 const after=snapshotSource(source),changed=changedSource(before,after);sourceStable=changed.length===0;
 const result={label:check.label,command:['nice',...args],started,finished:new Date().toISOString(),wallSeconds:(performance.now()-t0)/1000,guardExit:code,commandExit:sourceStable?code:null,signal,error,sourceStable,changed,log:relative(output,logPath),logBytes:statSync(logPath).size,logSha256:hash(readFileSync(logPath)),passed:code===0&&sourceStable&&!error};
 if(check.label==='build')buildPassed=result.passed;
 if(check.label==='startup-preparation-inspector'){const text=readFileSync(logPath,'utf8').replace(/\u001b\[[0-9;]*m/g,'');const passed=text.match(/Tests\s+(\d+) passed/);if(passed)result.passedTests=Number(passed[1]);}
 receipt.results.push(result);save();console.log(JSON.stringify({status:'check-finished',label:check.label,exit:code,sourceStable,wallSeconds:result.wallSeconds,log:logPath}));
}
const after=snapshotSource(source);receipt.sourceStable=changedSource(before,after).length===0;receipt.changed=changedSource(before,after);receipt.outputDigest=digest(after);receipt.trackedInputDigestAfter=trackedDigest();receipt.trackedInputsUnchanged=receipt.trackedInputDigestAfter===expectedTracked;receipt.finalCommit=git('rev-parse','HEAD').trim();receipt.finalTrackedGitStatus=git('status','--porcelain','--untracked-files=no').trim();
if(buildPassed&&existsSync(resolve(dist,'BUILD_IDENTITY.json'))){receipt.buildIdentity=JSON.parse(readFileSync(resolve(dist,'BUILD_IDENTITY.json'),'utf8'));receipt.buildIdentityMatches=receipt.buildIdentity.commit===expectedCommit&&receipt.buildIdentity.fingerprint===fingerprint&&receipt.buildIdentity.variant==='product';writeFileSync(resolve(output,'BUILD_IDENTITY.json'),JSON.stringify(receipt.buildIdentity,null,2)+'\n');}
receipt.finished=new Date().toISOString();receipt.status='complete';receipt.passed=receipt.results.every(r=>r.passed===true)&&receipt.sourceStable&&receipt.trackedInputsUnchanged&&receipt.finalCommit===expectedCommit&&receipt.finalTrackedGitStatus===''&&receipt.buildIdentityMatches===true;save();
console.log(JSON.stringify({status:'complete',passed:receipt.passed,sourceStable:receipt.sourceStable,trackedInputsUnchanged:receipt.trackedInputsUnchanged,buildIdentityMatches:receipt.buildIdentityMatches,commit:receipt.finalCommit,receiptPath}));process.exitCode=receipt.passed?0:1;
