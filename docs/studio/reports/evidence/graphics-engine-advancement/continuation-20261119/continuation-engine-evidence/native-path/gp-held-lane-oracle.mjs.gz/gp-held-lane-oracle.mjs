import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const [source, destination] = process.argv.slice(2);
const root = resolve(source), load = (path) => import(pathToFileURL(resolve(root, path)).href);
const { Simulation } = await load('src/simulation/world.ts');
const { DEFAULT_OPTIONS } = await load('src/simulation/config.ts');
const { PHASE } = await load('src/simulation/race.ts');
const { BikeAIDriver } = await load('src/simulation/bike-ai.ts');
const { racingLineFor } = await load('src/simulation/racing-line.ts');
const { trackPoint } = await load('src/simulation/track.ts');
const paths = ['ai.ts', 'bike-ai.ts', 'bike.ts', 'motogp-physics.ts', 'traffic.ts'];
const hashes = () => Object.fromEntries(paths.map((p) => [p, createHash('sha256')
  .update(readFileSync(resolve(root, 'src/simulation', p))).digest('hex')]));
const before = hashes();

// Hold the rider exactly on a stationary authored world path; this is an AI
// reference-generation probe, not a race or a changed vehicle integrator.
const results = [];
for (const slope of [0, 0.01, -0.01, 0.04]) {
  const sim = new Simulation({ ...DEFAULT_OPTIONS, mode: 'practice', opponents: 0,
    vehicles: ['gpr1'], circuit: 'montejaral', seed: 5111 });
  const track = sim.track, line = racingLineFor(track), bike = sim.cars[0];
  const driver = new BikeAIDriver(bike), origin = 100, alongSpeed = 30;
  const worldSpeed = alongSpeed * Math.hypot(1, slope), heading = Math.atan(slope);
  line.offsetAt = (s) => slope * (s - origin);
  line.curvatureAt = () => 0;
  track.at = (s, out = trackPoint()) => Object.assign(out, {
    s, x: 0, y: 0, z: s, tx: 0, tz: 1, nx: 1, nz: 0,
    width: 20, curvature: 0, gradient: 0, bank: 0,
  });
  sim.race.phase = PHASE.RACING;
  const frames = [], dt = 1 / 120;
  for (let i = 0; i < 120; i++) {
    const station = origin + alongSpeed * i * dt, lateral = line.offsetAt(station);
    sim.race.time = sim.race.greenAt + 2 + i * dt;
    bike.s = station;
    bike.lateral = lateral;
    bike.speed = bike.dynamics.speed = worldSpeed;
    bike.dynamics.heading = heading;
    bike.dynamics.x = lateral;
    bike.dynamics.z = station;
    bike.dynamics.motoGP.lateralSpeed = 0;
    bike.body.position.set(lateral, bike.body.position.y, station);
    bike.body.orientation.yaw(heading);
    track.at(station, bike.trackPosition);
    driver.update(dt, track, sim.cars, sim.race);
    const selection = { ...driver.selectedRoadPath };
    frames.push({ frame: i, station, line: lateral, decision: driver.decision,
      sampled: driver.trafficRefreshed, desired: driver.desiredOffset,
      desiredRelativeNow: driver.desiredOffset - lateral,
      tactical: driver.tactical, launch: driver.launch, selection,
      laneRate: (selection.lane - selection.previousLane) / dt,
      target: driver.steeringTarget, correction: driver.steeringCorrection,
      blocker: driver.planner.blocker, passTarget: driver.planner.passTarget,
      heldOffset: driver.planner.heldOffset });
  }
  let signChanges = 0, previousSign = 0;
  for (const f of frames.slice(20)) {
    const sign = Math.abs(f.laneRate) > 1e-9 ? Math.sign(f.laneRate) : 0;
    if (sign && previousSign && sign !== previousSign) signChanges++;
    if (sign) previousSign = sign;
  }
  results.push({ slope, worldSpeed, samples: frames.filter((f) => f.sampled).length,
    maxTactical: Math.max(...frames.map((f) => Math.abs(f.tactical))),
    maxLaneRate: Math.max(...frames.map((f) => Math.abs(f.laneRate))),
    maxCorrection: Math.max(...frames.map((f) => Math.abs(f.correction))),
    signChanges, frames });
}
const after = hashes(), output = { source: root, sourceHashes: before,
  sourceStable: JSON.stringify(before) === JSON.stringify(after), results };
writeFileSync(destination, JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ destination, sourceStable: output.sourceStable,
  results: results.map(({ frames, ...summary }) => summary) }, null, 2));
