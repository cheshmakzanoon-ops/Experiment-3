import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root=process.argv[2],output=process.argv[3];
const {Simulation}=await import(pathToFileURL(root+'/src/simulation/world.ts'));
const {DEFAULT_OPTIONS}=await import(pathToFileURL(root+'/src/simulation/config.ts'));
const {racingLineFor,RACING_LINE}=await import(pathToFileURL(root+'/src/simulation/racing-line.ts'));
const {trackPoint}=await import(pathToFileURL(root+'/src/simulation/track.ts'));
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x)),mod=(x,n)=>(x%n+n)%n;
const cases=[];
const hashFiles=['src/simulation/ai.ts','src/simulation/bike-ai.ts','src/simulation/offroad/ai.ts','src/simulation/racing-line.ts'];
const sourceHashes=Object.fromEntries(hashFiles.map(p=>[p,createHash('sha256').update(readFileSync(root+'/'+p)).digest('hex')]));
for(const circuit of ['poggio-alto','vellamar','ardennes']) {
  const sim=new Simulation({...DEFAULT_OPTIONS,circuit,vehicles:['gpr1'],mode:'practice',opponents:0});
  const track=sim.track,line=racingLineFor(track),c=sim.cars[0],driver=sim.ai[0];
  for(const width of [1,0.775,0.55]) {
    const n=line.count,curves=new Float64Array(n),points=[];
    for(let i=0;i<n;i++) {
      const p=track.at(i*line.step,trackPoint()),l=width*line.offsetAt(i*line.step);
      points.push({x:p.x+p.nx*l,z:p.z+p.nz*l});
    }
    for(let i=0;i<n;i++) {
      const a=points[(i-1+n)%n],b=points[i],c=points[(i+1)%n];
      const ax=b.x-a.x,az=b.z-a.z,bx=c.x-b.x,bz=c.z-b.z;
      curves[i]=Math.atan2(az*bx-ax*bz,ax*bx+az*bz)/((Math.hypot(ax,az)+Math.hypot(bx,bz))*.5);
    }
    const actualCurvature=s=>{
      const u=mod(s,track.length)/line.step,i=Math.floor(u)%n,f=u-Math.floor(u);
      return curves[i]+(curves[(i+1)%n]-curves[i])*f;
    };
    for(const speed of [20,40,60,80]) {
      const rows=[],near=clamp(6+speed*.48,8,46);
      for(let i=0;i<n;i++) {
        const s=i*line.step,p=track.at(s,trackPoint()),ahead=s+speed*.3;
        const nearRaw=driver.steeringLineOffset(track,s+near),nowRaw=driver.steeringLineOffset(track,s);
        const aiOffset=width*nearRaw,tactical=aiOffset-nearRaw;
        const rawTarget=nowRaw+tactical,reach=Math.max(1,p.width-1.4),target=clamp(rawTarget,-reach,reach),actualTarget=width*nowRaw;
        const slope=(driver.steeringLineOffset(track,s+3)-driver.steeringLineOffset(track,s-3))/6;
        const heading=Math.atan(slope/Math.max(.5,1-p.curvature*target));
        const actualHeading=Math.atan((width*slope)/Math.max(.5,1-p.curvature*actualTarget));
        const k=driver.steeringLineCurvature(track,ahead),predictedCurvature=k/Math.max(.5,1-k*tactical),trueCurvature=actualCurvature(ahead);
        rows.push({station:s,speed,width,near,aiOffset,tactical,rawOffset:nowRaw,actualTarget,implementationTarget:target,targetError:target-actualTarget,targetClipped:target!==rawTarget,implementationHeading:heading,actualHeading,headingError:heading-actualHeading,implementationCurvature:predictedCurvature,actualCurvature:trueCurvature,curvatureError:predictedCurvature-trueCurvature,lateralAccelerationError:speed*speed*(predictedCurvature-trueCurvature)});
      }
      const summary={};
      for(const field of ['targetError','headingError','curvatureError','lateralAccelerationError']) {
        const a=rows.map(x=>Math.abs(x[field])).sort((a,b)=>a-b);
        summary[field]={meanAbsolute:a.reduce((a,b)=>a+b,0)/a.length,p95:a[Math.floor(.95*(a.length-1))],maximum:a.at(-1)};
      }
      rows.sort((a,b)=>Math.abs(b.targetError)-Math.abs(a.targetError));
      const targetMax=rows.slice(0,3);
      rows.sort((a,b)=>Math.abs(b.headingError)-Math.abs(a.headingError));
      const headingMax=rows.slice(0,3);
      rows.sort((a,b)=>Math.abs(b.curvatureError)-Math.abs(a.curvatureError));
      const curvatureMax=rows.slice(0,3);
      cases.push({circuit,width,speed,n,step:line.step,lineScale:c.definition.ai.lineScale??1,driver:driver.constructor.name,summary,targetMax,headingMax,curvatureMax});
    }
  }
}
const result={scope:'Geometry-only mismatch for the existing width-scaled racing line with zero tactical/launch offset. No simulation tick or control input modified. Curvature oracle uses independent world positions at the original racing-line sample spacing, preserving the solver\'s own three-chord convention; width=1 is a baseline control.',source:root,sourceHashes,limitations:['Synthetic constant speeds demonstrate curvature-to-acceleration implication, not speeds achieved at each circuit station.','This proves path interpretation mismatch, not a cause of any particular seeded race failure or accepted correction.','The existing wet width=.55 corresponds to front contact water>=.8 mm; .775 corresponds to .4 mm.'],cases};
writeFileSync(output,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(cases.filter(x=>x.speed===40).map(({circuit,width,driver,lineScale,summary,targetMax})=>({circuit,width,driver,lineScale,summary,targetMax:targetMax[0]})),null,2));
