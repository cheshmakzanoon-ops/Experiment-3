# Cache rejection and selected spatial-path investigation

This supplemental package preserves a new causal chain independently of the earlier rejected `4c9b858` checkpoint. It contains completed observations and local native proofs. **The cache-only source is rejected: 48 of the original 51 cases pass, three fail. The selected spatial-path candidate's race acceptance is pending.** No passing native result is presented as an accepted race fix.

## Completed results

| Evidence | Result and scope |
|---|---|
| Cache-only original four-file race/planner gate | 48/51, exit 1, all 7,245 protected inputs stable; Ardennes seed1000 falls, Aurel clear and Poggio Alto clear violate the original zero-contact assertion. |
| Post-clamp native onset reconstruction | All 479 reconstructible update previews and old feedback corrections match recorded outputs exactly. Actual selected-current versus inferred-current target discrepancy peaks 3.028925874 m. |
| Fixed-budget native approach comparison | Five measured geometry states, four geometry variants, same controlled speed/grip/recovery/mass/aero/skill. The authorized retained-lane curvature/local-metric variant is more conservative at the sampled onset. |
| Selected spatial-path source review | Only ai.ts and bike-ai.ts change from cache-only; no blocking ownership/scope finding. Authored/raw-lane curvature approximation remains disclosed. |
| New native consumer on saved onset | 479 states, target error 0 and maximum correction error 1.3322676295501878e-15 m/s². No integration or repeated race. |
| External spatial lifecycle/width fixture | 10/10 pass, exit 0, all 2,236 then-protected candidate inputs stable. Source lifetime, exact local bounds, takeover fade, captured width and non-GP exclusion. |

See `reports/onset-review.md` and `reports/spatial-source-review.md` for reasoning, exact source identities and limitations. These reports are verbatim snapshots written before the subsequent selected race gates. The completed cache-only receipt in `completed/` supersedes earlier prose that described its gate as still running.

## Compact, lossless inputs

The raw first-fall trace is 6,052,701 bytes. Its exact size/hash and source identity are retained in `projection/receipt.json`; the raw trace is deliberately omitted. Every field consumed by the supplied replay scripts is retained without decimal rounding for all 480 frames of the first falling rider:29 columns, 13,920 field values. All projected values were compared with the original before compression. The projection is 106,763 bytes gzipped. Other riders and unused telemetry are unnecessary to these recorded-state calculations.

The 3.385MB generated per-frame geometry report is also omitted: the replay regenerates it from the supplied projection and native source. The expected digest covers every numeric row, every approach sample, extrema and sampled points, so the compact archive does not merely compare a few headline numbers. Full fixed-budget and consumer summary outputs are retained directly.

Original logs/manifests compressed with gzip restore byte-for-byte. `copy-provenance.json` records original and compressed hashes/sizes. `PAYLOAD.sha256` covers the immutable replay payload; `SHA256SUMS` additionally covers the final staging/replay receipts.

## Replay without a race or the raw trace

Requires the project's existing Node/dependencies and two source roots matching `reproduction/source-identities.json.gz`. The runner checks every one of 931 production source files in each root before and after. It materializes only the lossless projection in a fresh external output directory, executes the three unchanged native scripts, checks their exits, and matches exact saved numeric-result digests.

```sh
node --no-warnings --experimental-transform-types \
  /absolute/path/gp-spatial-causal-evidence/reproduction/replay.mjs \
  /absolute/path/gp-history-relative-only \
  /absolute/path/gp-cache-spatial-candidate \
  /absolute/path/fresh-external-replay-output
```

The output directory must be fresh and outside both source roots and this evidence package. The runner performs no simulation steps, starts no race, edits no production files and needs no raw trace. Its receipt is written to the external output directory.

### Restoring source variants

Published Git anchor: `cd9f2f50b0655ee548c0fc943af15083693f42b5`. Both variants differ from that anchor in only four production files: ai.ts, bike-ai.ts, bike.ts and motogp-physics.ts. The source identity manifest verifies every remaining production file against the anchor comparison.

In disposable checkouts at that anchor, apply `reproduction/cache-only-from-cd9f2f5.patch` to restore cache-only. Apply that patch followed by `reproduction/cache-to-spatial.patch` in the second checkout to restore the reviewed spatial source. Reuse the project's existing dependency installation. The patches were applied to an external four-file anchor export and all resulting source hashes verified; see `reproduction/patch-restore-receipt.json`. Source restoration is an optional preparation step, separate from the read-only replay.

The original race observer is retained for provenance. **Do not run it merely to reproduce this package's derived proofs:** the compact replay is sufficient and is what was rerun for this archive.

## Limits

The source review and instantaneous feedback comparisons establish path ownership, not safe closed-loop handling. They do not replace original zero-fall/contact gates. Real temporal lane motion is not added to the authorized spatial candidate. The authored constant-shift curvature remains an approximation of a locally clipped, width-varying path. The fixed-budget comparison explicitly fixes nominal 245 kg and no-wake/undamaged aero because those dynamic values were not saved in the raw trace; it is not claimed as exact full-plant replay.

All new packaging/replay work occurred outside protected trees. No earlier checkpoint package was modified.
