# Independent review: cache-only Ardennes seed 1000 onset

## Disposition and scope

The source under review is `gp-history-relative-only`, the original history correction plus the GP sampled relative-intent cache. It is **not accepted**. The original seed 1000 Ardennes hairpin case falls, although seed 1037 passes. Root also reports clear-weather Aurel and Poggio zero-contact assertion failures in the same original 51-case gate. Those cases remain constraints on any spatial-path trial.

This review ran no race, changed no production file, and proposes no parameter change. It re-evaluates the native track and existing feedback law on the owner's saved first-fall ring. It separately compares the existing native approach solve at one fixed physical budget while varying only its path geometry. Neither calculation is a closed-loop acceptance test.

The causal pace/reachability investigation is complete in `gp-pace-causal-review/causal-review.md`; proposed reachability changes remain unimplemented. They are separate from this onset.

## Source and reproducibility

Input trace: `gp-cache-ardennes1000-first-fall.json`, produced by the owner's unmodified-argument observer `gp-hairpin-first-fall-observe.mjs`. Original options: Ardennes, clear, sport assist, four GPR1 entrants, one lap, seed 1000. The trace records a source-stable run.

Critical source SHA-256 values embedded in that trace:

| File | SHA-256 |
|---|---|
| bike.ts | 8aaa0ede0ff7cd94ee627dee0f9ecebefdef5a83904490677dfd2c13135225de |
| bike-ai.ts | 53781daa7badaf7814a63400bffd4ec96a0399ae9622671e51554f081fc265d5 |
| motogp-physics.ts | 2a3bac376e45e7de10fdb06674cf4fbf145bbafc8058d62af7e0472d5881e22a |
| ai.ts | b8a21f5be872ad5b9a19a4a64d29cd2f51d341e8797d75e5c5240a89a1dd5106 |
| traffic.ts | 58bbe1c1e66fdb5a7a7850f3bd1e04b320ddc58b030aa2ec0638ff639160e874 |

The native geometry proof verifies those hashes against the source and checks its nine imported source files before and after execution. Results: `traceSourcesMatch=true`, `sourceStable=true`.

From `/workspace/scratch/0ab62d15db18`:

```sh
node --no-warnings --experimental-transform-types gp-cache-ardennes1000-spatial-review.mjs
node --no-warnings --experimental-transform-types gp-cache-ardennes1000-budget-review.mjs
```

Both commands exited 0. They write external JSON/log evidence; the first command also records source and trace hashes. No simulation step is called.

## Phase alignment and exact native agreement

`Simulation.step` updates AI once, then advances the vehicle in two physics substeps. A saved post-step row therefore contains the new AI targets but the later physical pose. Pairing the row's own station with its AI target would introduce a false spatial difference.

For each of the 479 reconstructible updates in the four-second ring, the proof uses:

- The preceding completed row's station, heading, lateral position, forward speed, lateral speed, and contact wetness.
- The new row's tactical lane plus launch residual and newly published preview target.
- The base driver's ground speed, `hypot(forwardSpeed, lateralSpeed)`, for its lookahead, and the forward speed for the bike feedback law.
- The actual native Ardennes `Track`, solved `RacingLine`, `lineOffset`, and `laneReach` methods.
- The exact base edge margin of 2.4 m, queried independently at every station.

This reproduces **every one of the 479 published preview offsets exactly**, with maximum absolute error 0. It also reproduces **every recorded native steering-correction acceleration exactly**, with maximum absolute error 0. The first-fall callback itself can occur within a physics substep and is not included in this exact completed-frame reconstruction.

That exact match is the phase/control negative control for the subsequent spatial comparison.

## Actual selected target versus reconstructed preview target

The base driver evaluates the selected road path as the authored line plus retained lane, locally clamped at the point being queried. The bike instead subtracts the authored preview line from the already-clamped preview target, treating the result as the original lane. A saturated preview loses the original lane information. Moving that inferred lane back to the present station changes the path.

The maximum post-clamp selected-current versus native inferred-current discrepancy is **3.028925874 m**, at time 80.994224 s, pre-update station 3111.205689 m: selected target 4.686263008 m versus native target 1.657337134 m.

Representative exactly aligned frames:

| Recorded time (s) | Pre-AI station (m) | Current / preview road half-width (m) | Raw current target (m) | Actual base-clamped current target (m) | Native inferred target (m) | Actual difference (m) |
|---:|---:|---:|---:|---:|---:|---:|
| 80.852557 | 3109.170648 | 7.080178 / 7.118075 | 4.170982 | 4.170982 | 1.513715 | 2.657268 |
| 81.052557 | 3112.121567 | 7.089068 / 7.125585 | 4.893275 | 4.689068 | 1.783227 | 2.905842 |
| 81.452557 | 3117.745995 | 7.106897 / 7.136644 | 5.836391 | 4.706897 | 2.740453 | 1.966444 |
| 82.052557 | 3128.586093 | 7.133571 / 7.148665 | 6.738236 | 4.733571 | 4.215703 | 0.517869 |

In particular, the late `6.738 - 4.216` raw difference is not a 2.52 m actual selected-path error. The raw target is outside the base road corridor. Its actual clamped difference is about 0.518 m. The larger earlier discrepancy nevertheless survives the exact clamp and phase controls.

## Target and slope must describe the same local path

The existing feedback combines a position term against the inferred target with the **unclamped authored-line slope**. When the selected path follows the local road bound, that slope may differ substantially from the selected path's finite-difference slope.

At time 81.452557 s:

- Authored slope: 0.262320066.
- Selected locally clamped path slope over the same ±3 m stencil: 0.003027883.
- Recorded native correction: **+3.229975996 m/s²**.
- Replacing only the target while retaining the authored slope: **+5.883990 m/s²**, the existing correction limit.
- Evaluating the same position/heading law with the selected target and selected spatial slope: **−2.029498989 m/s²**.

This is why a target-only substitution would not establish coherent ownership. Both target and slope need the same point query, including the current-station clamp. These are instantaneous comparisons on a frozen state, with the original gains and acceleration clamp. They do not predict the resulting race trajectory. There is no new temporal heading term in this calculation. At the fully clipped current point, the local lane translation is itself zero; changing the raw lane while both endpoints remain clipped does not move that point.

The existing authored-curvature feed-forward remains a separate approximation. This review does not claim that a spatial target/slope correction makes it exact.

## Temporal handoff is a real invariant but small here

The same-update braking path calculation precedes `aiOffset` publication in the cache-only source, while steering uses the newly published value. The measured difference between braking's `planRecovery` and the absolute steering correction is:

| Time interval (s) | Mean absolute difference (m/s²) | Maximum absolute difference (m/s²) |
|---|---:|---:|
| 79–80 | 0.0191303 | 0.0558798 |
| 80–81 | 0.0004588 | 0.0007887 |
| 81–82 | 0.0003348 | 0.0014453 |
| 82–first fall | 0.0001278 | 0.0008845 |

At 81.452557 s the phase difference is only −0.000327758 m/s², beside the several-m/s² spatial feedback difference. This trace supports the spatial-path issue much more strongly than a claim that temporal handoff alone causes the hairpin fall. No timing-only race was repeated.

## Observed physical escalation

The visible failure is a roll overrun, with no impact before the fall:

- At 80.452557 s the body leans −0.151786 rad while the selected-current versus inferred-current target difference has already reached about 1.57 m.
- At 81.052557 s the lean has crossed to +0.043224 rad with roll rate +1.199483 rad/s. Requested correction is +2.371968 m/s².
- At 81.452557 s the lean is +0.451585 rad, rate +0.998960 rad/s; the authored slope still requests +3.229976 m/s² although the locally selected path is near its road bound.
- By 81.852557 s the lateral arrest reserve is at the existing 2 g cap, brake input is 0.3, and both actual brake forces are zero.
- In the last 126 saved frames after 82 s, 106 frames have a brake command above 0.05 but zero summed brake force; 99 frames have lateral reserve at approximately 2 g.
- The callback occurs at 83.044224 s / station 3146.743336 m, forward speed 13.984480 m/s, lean 1.256317 rad and rate 1.778793 rad/s, target lean 0.589803 rad, impact 0.

The plant's lateral reserve can consume available force while the speed planner still requests braking. The frozen trace establishes this ordering and the preceding path mismatch; it does not prove that every later load fluctuation or the final overrun has a single cause. Broad original race gates remain required.

## Fixed-budget approach comparison

`gp-cache-ardennes1000-budget-review.mjs` calls the existing native corner and backward approach solvers. For each sampled state, all variants share speed, observed contact-derived grip including the original tactical penalty, recorded recovery reserve, skill 0.92, mass 245 kg, aero factor 1, and the existing stopping-count rule. Only path geometry changes.

The trace lacks actual fuel, wake, and body-health values. Nominal mass and undamaged/no-wake aero are explicitly controlled fixture inputs, not claimed recovered telemetry. The old controlled solve matches the recorded profile within 0.00036 m/s in these five states, but that close agreement does not remove the disclosure.

The authorized narrow extraction retains authored curvature with the raw retained-lane parallel-shift denominator while applying the true local path query to target, slope, and distance metric. Its fixed-budget result is:

| Time (s) | Old inferred-lane planned speed (m/s) | Retained raw curvature + local metric (m/s) | Old next physical span (m) | Local next physical span (m) |
|---:|---:|---:|---:|---:|
| 80.452557 | 13.251012 | 13.035485 | 10.575742 | 10.605908 |
| 80.852557 | 15.278321 | 14.576282 | 10.693603 | 10.500142 |
| 81.052557 | 13.541850 | 12.728606 | 10.358269 | 10.008362 |
| 81.452557 | 12.387781 | 11.519289 | 9.593070 | 9.285445 |
| 82.052557 | 11.751286 | 11.037965 | 9.442219 | 9.379470 |

Thus this extraction is more conservative in the sampled onset geometry at the same physical budget; it is not an arbitrary brake-margin change. The JSON also retains raw-unclamped-metric and locally realized-curvature variants as diagnostic comparisons. Those alternatives are not implemented or accepted.

### Curvature limitation retained explicitly

At time 81.452557 s, the first approach point is station 3122.697515 m. Its inferred-lane curvature is 0.035954, raw-retained-lane approximation 0.040457, and locally realized shift approximation 0.037138 1/m. Native world-space chords of the fully clipped selected path produce about 0.066510 at a 3 m stencil and 0.066445 at 4 m. The selected local metric is 0.762760 versus the original 0.824073.

Neither a raw nor a locally realized constant-shift denominator includes all derivatives introduced by clipping a varying authored path. The two world-chord stencils are an independent geometric limitation check, not a proposed new curvature model or threshold. The authorized first candidate preserves the existing authored-curvature approximation and must therefore be judged by its native invariants and original race gates, with that limitation disclosed.
