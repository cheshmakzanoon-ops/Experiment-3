# Independent source review: cache plus selected spatial road path

## Review result

No blocking ownership or scope defect was found in the reviewed production diff. This is permission to continue the owner's original gates, **not acceptance of the candidate**. The predecessor cache-only source has genuine original race failures; passing native consumer invariants cannot supersede them.

Reviewed source: `/workspace/scratch/0ab62d15db18/gp-cache-spatial-candidate`, compared with immutable `gp-history-relative-only`.

| Production file | Reviewed SHA-256 |
|---|---|
| ai.ts | f349c0851169f2d1bdad6c81ea3251bf47f08e974be72092cf13a0c97da2748a |
| bike-ai.ts | 7a7a80e83593bb407b224857cf3ee1aab705ca0b65bbe12e713150c26471b50f |
| bike.ts | 8aaa0ede0ff7cd94ee627dee0f9ecebefdef5a83904490677dfd2c13135225de |
| motogp-physics.ts | 2a3bac376e45e7de10fdb06674cf4fbf145bbafc8058d62af7e0472d5881e22a |
| traffic.ts | 58bbe1c1e66fdb5a7a7850f3bd1e04b320ddc58b030aa2ec0638ff639160e874 |

The file comparison covered all 931 files currently under `src`: only `simulation/ai.ts` and `simulation/bike-ai.ts` differ. Formatting was restored to the original style before the final hashes above were recorded. No reviewer production edits were made.

## Ownership and lifecycle

The base driver owns one allocation-free road snapshot containing validity, the authored width selected by the base update, and the raw tactical lane plus launch residual. It clears validity at update entry and captures the snapshot after placement/handback re-anchoring, stalled-vehicle bypass folding, launch decay, and the actual finite lane slew. The snapshot therefore describes the same selection that constructs the current preview.

Pit and pit-preparation corridors do not publish a road snapshot. The bike clears validity before its rider-down early return, which can bypass the base update. Race-light and reaction-delay returns encounter the base invalidation. On the next ordinary road update, the snapshot is replaced by that update's actual choice. No old lane derivative, elapsed-time accumulator, or previous snapshot is introduced.

`selectedRoadOffset` samples the road at the requested station. It applies the original `lineOffset` virtual hook to the captured-width authored line, then adds the retained raw lane and clamps through the original `laneReach` hook and 2.4 m edge margin. The helper's track scratch point is separate from the current feedback point and approach point, so the ±3 m queries do not overwrite curvature/gradient data that the caller still needs.

The current feedback target and slope share this helper. The GP steering and ordinary braking plan obtain the same retained lane in the same update before `aiOffset` publication. Publication order itself is unchanged. The approach plan uses the helper for offset and ±3 m slope, and hence for physical distance and grade conversion.

## Scope preservation

Only ordinary GP road consumers opt into the snapshot. Non-GP bike steering still takes the old inferred-lane branch; its road-pedal approach path is unchanged. GP-only entry checks still guard the ordinary GP approach solver. Dirt-bike methods and four-wheel venue methods remain unmodified. GP motorcycles taken to a different venue still use the appropriate base virtual hooks; no new venue override is bypassed.

Absolute pit steering retains its original corridor branch. Invalid-snapshot direct research calls retain prior behavior. The newly recorded snapshot on a base/non-GP driver has no new control consumer in those branches.

The authored curvature function and its existing `k / max(0.5, 1 - k * tactical)` formula are preserved, using the now-retained raw selected lane. No locally realized-shift curvature replacement, world-chord curvature model, wet curvature blend, temporal heading term, extended pass profile, admission correction, gain, skill, grip coefficient, or safety threshold is added. Passing/traffic source is byte-identical to the history foundation.

The ordinary approach solver, sample-count rule and cadence are unchanged. Local point queries add bounded `Track.at` calls inside that existing sample loop; this is not a claim of identical CPU work or an additional 12 Hz profile extension.

## Independent native consumer check

The reviewer ran one short saved-state consumer oracle, with no integration steps or repeated race:

```sh
node --no-warnings --experimental-transform-types gp-cache-spatial-independent-review/consumer-onset.mjs
```

Exit 0. It evaluates the actual new `selectedRoadOffset` and `pathCorrection` methods on all 479 reconstructible Ardennes onset states. The selected snapshot comes from the separate exact old-source reconstruction, whose previews and old feedback matched all recorded outputs exactly.

Results:

- Maximum selected-target difference from the independent base/clamp reconstruction: **0 m**.
- Maximum correction difference from the same-law, selected-spatial-path oracle: **1.3322676295501878e-15 m/s²**.
- All nine checked production source hashes unchanged before/after.

At the difficult 81.452557 s state, the native new consumer produces the selected target 4.706896698 m and correction −2.029498989 m/s², matching the independent spatial oracle. The old native correction was +3.229975996 m/s². This validates consumer arithmetic on the measured onset; it does not predict that the full race will pass.

The owner's new nine-case file was also read: mirrored preview-clipping, edge-tangent and physical-distance fixtures, plus three full native update handoff observations. The reviewer did not duplicate its unit execution. The owner/graphics lifecycle suite and original race gates remain separately attributed to their own receipts.

## Retained limitations and required gates

The detailed onset and fixed-budget analysis is in `gp-cache-ardennes1000-review.md`. The original same-step timing discrepancy is small during this onset; the materially larger demonstrated error is loss of the retained spatial lane through a clipped preview. The new snapshot resolves both ownership issues without a separate timing patch.

The authored parallel-offset curvature remains an approximation of a locally clipped, width-varying path. The saved native world-chord comparison shows a material difference on part of the Ardennes edge. This candidate deliberately does not introduce a new curvature model; neither this review nor its native tests claim that broader approximation has been solved.

Temporal lane motion remains unmodeled by the existing spatial heading law. The earlier broader selected-path/temporal compositions failed genuine races and are excluded here. The relative-intent cache prevents the already demonstrated artificial sample-frame jitter, but it does not make every real lane change safe by proof alone.

Before acceptance, the original Ardennes 1000, Aurel clear, Poggio clear, mixed pace, Vellamar 5222, Montejaral 5111 and other established gates must satisfy their unchanged assertions on this exact candidate. No race acceptance is claimed by this report.
