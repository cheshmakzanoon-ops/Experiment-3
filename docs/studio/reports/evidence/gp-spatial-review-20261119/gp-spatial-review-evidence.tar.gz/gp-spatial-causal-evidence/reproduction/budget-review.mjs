import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';
const root=resolve('gp-history-relative-only'), load=p=>import(pathToFileURL(resolve(root,p)).href);
const { BikeAIDriver, gpApproachSampleCount, bikePreviewDistance, GP_AI_HANDS }=await load('src/simulation/bike-ai.ts');
const { BikeVehicle }=await load('src/simulation/bike-vehicle.ts');
const { GP_R1 }=await load('src/simulation/bike-definitions.ts');
const { DEFAULT_SETUP, AI_BASE_SKILL }=await load('src/simulation/config.ts');
const { Track, trackPoint }=await load('src/simulation/track.ts');
const { CIRCUITS }=await load('src/simulation/circuits.ts');
const { racingLineFor, RACING_LINE }=await load('src/simulation/racing-line.ts');
const { motorcycleApproachProfile, motorcyclePathMetric }=await load('src/simulation/motorcycle-braking-plan.ts');
const { envelopeCornerSpeed }=await load('src/simulation/ai.ts');
const { GP_ASSIST }=await load('src/simulation/bike.ts');
const review=JSON.parse(readFileSync('gp-cache-ardennes1000-spatial-review.json','utf8'));
const trace=JSON.parse(readFileSync('gp-cache-ardennes1000-first-fall.json','utf8'));
const track=new Track('clear',false,undefined,CIRCUITS.ardennes),line=racingLineFor(track);
const bike=new BikeVehicle(0,'medium',DEFAULT_SETUP,'sport',GP_R1),driver=new BikeAIDriver(bike,AI_BASE_SKILL);
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const env=bike.definition.ai, mass=bike.dynamics.mass, aero=env.downforceReference/(bike.spec.dryMass+bike.fuel);
const result=[];
for (const time of [80.45,80.85,81.05,81.45,82.05]) {
 const r=review.rows.reduce((a,b)=>Math.abs(a.time-time)<Math.abs(b.time-time)?a:b);
 const frames=trace.first.prior;const index=frames.findIndex(frame=>frame[0].t===r.time);const before=frames[index-1][0];
 const grip=clamp(Math.min(before.frontGrip,before.rearGrip),.1,1)*clamp(1-.25*Math.max(0,Math.abs(r.inferredLane)-1.5)/6,.8,1);
 const count=gpApproachSampleCount(r.speed,env.brakingBase*grip*env.brakingMargin,track.length);
 const base=station=>driver.lineOffset(track,station,line.offsetAt(station)*r.width);
 const offset=station=>{const reach=driver.laneReach(track,station,Math.max(1,track.at(station,trackPoint()).width-RACING_LINE.edgeMargin));return clamp(base(station)+r.lane,-reach,reach);};
 const variants=[];
 for(const kind of ['old-inferred','retained-raw','retained-raw-k-local-metric','retained-local']) {
  const curvature=new Float64Array(count),corners=new Float64Array(count),gradient=new Float64Array(count),metrics=new Float64Array(count),distance=new Float64Array(count-1),profile=new Float64Array(count),samples=[];
  for(let i=0;i<count;i++) {
   const station=r.station+bikePreviewDistance(r.speed,1/(2*GP_AI_HANDS.brakeApply))+i*12;
   const p=track.at(station,trackPoint()),authored=line.offsetAt(station),k=line.curvatureAt(station);
   const localGeometry=kind==='retained-local'||kind==='retained-raw-k-local-metric';
   const lane=kind==='old-inferred'?r.inferredLane:kind==='retained-local'?offset(station)-authored:r.lane;
   const selected=localGeometry?offset(station):authored+lane;
   const slope=localGeometry?(offset(station+3)-offset(station-3))/6:(line.offsetAt(station+3)-line.offsetAt(station-3))/6;
   const km=k/Math.max(.5,1-k*lane);curvature[i]=Math.abs(km);
   metrics[i]=motorcyclePathMetric(p.curvature,selected,slope);gradient[i]=p.gradient/Math.max(1e-6,metrics[i]);
   corners[i]=envelopeCornerSpeed(km,grip,aero,env,r.planRecovery)*AI_BASE_SKILL;
   if(i<3)samples.push({station,curvature:km,offset:selected,slope,metric:metrics[i],corner:corners[i]});
  }
  for(let i=0;i<count-1;i++)distance[i]=.5*(metrics[i]+metrics[i+1])*12;
  const planned=motorcycleApproachProfile(curvature,corners,grip,aero,env,count,profile,gradient,bike.dynamics.p,mass,GP_ASSIST.recovery/GP_ASSIST.leanMargin,0,distance,r.planRecovery);
  variants.push({kind,planned,next:profile[1],physicalDistance:distance[0],samples});
 }
 result.push({time:r.time,station:r.station,speed:r.speed,grip,aero,mass,skill:AI_BASE_SKILL,count,recovery:r.planRecovery,actualObservedPlan:frames[index][0].plan,variants});
}
const output={root,sourceHashes:review.sources,method:'Fixed-budget native profile comparison. All variants hold speed, contact-derived grip including old tactical penalty, nominal dry mass plus initial fuel, undamaged no-wake aero, actual skill0.92, and recorded recovery constant; only lane/path geometry differs. Trace lacks fuel/wake/health, so this is a controlled same-model comparison, NOT an exact replay of recorded plan or a safety/pace gate. No simulation steps or source edits.',result};
writeFileSync('gp-cache-ardennes1000-budget-review.json',JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify(result.map(r=>({time:r.time,grip:r.grip,recovery:r.recovery,observedPlan:r.actualObservedPlan,variants:r.variants.map(({samples,...v})=>v)}))));
