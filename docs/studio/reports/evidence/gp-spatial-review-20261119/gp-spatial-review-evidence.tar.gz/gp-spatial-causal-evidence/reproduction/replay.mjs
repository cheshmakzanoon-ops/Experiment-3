// Re-evaluate recorded native states only. Never starts a race or edits a source tree.
import { readFileSync, writeFileSync, mkdirSync, symlinkSync, existsSync } from 'node:fs';
import { dirname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const base=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const [cacheArg,spatialArg,outputArg]=process.argv.slice(2);
if(!cacheArg||!spatialArg||!outputArg)throw new Error('Usage: node --experimental-transform-types replay.mjs <cache-only-source> <spatial-source> <external-output>');
const cache=resolve(cacheArg),spatial=resolve(spatialArg),output=resolve(outputArg);
for(const protectedPath of [cache,spatial,base])if(output===protectedPath||output.startsWith(protectedPath+sep))throw new Error('Replay output must be outside both source trees and the evidence package');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const json=p=>JSON.parse(readFileSync(resolve(base,p),'utf8'));
const zipped=p=>JSON.parse(gunzipSync(readFileSync(resolve(base,p))).toString('utf8'));
let checked=0;
for(const line of readFileSync(resolve(base,'PAYLOAD.sha256'),'utf8').trim().split('\n')){
 const expected=line.slice(0,64),name=line.slice(66);if(sha(readFileSync(resolve(base,name)))!==expected)throw new Error('Payload checksum mismatch: '+name);checked++;
}
const identities=zipped('reproduction/source-identities.json.gz');
function verifySource(root,variant){const manifest=identities[variant].manifest;for(const [name,expected]of Object.entries(manifest))if(sha(readFileSync(resolve(root,name)))!==expected)throw new Error(`${variant} source mismatch: ${name}`);return Object.keys(manifest).length;}
const sourceFilesBefore={cache:verifySource(cache,'cache'),spatial:verifySource(spatial,'spatial')};
const projection=zipped('projection/ardennes1000-used-fields.json.gz');
const pReceipt=json('projection/receipt.json');
if(projection.rows.length!==480||projection.columns.length!==29||pReceipt.allValuesVerifiedAgainstRaw!==true)throw new Error('Unexpected projection shape');
const frames=projection.rows.map(values=>[Object.fromEntries(projection.columns.map((name,index)=>[name,values[index]]))]);
// The original scripts need only this rider's ring and first-fall metadata.
// The materialized JSON is explicitly a projection, not the omitted raw trace.
const materialized={candidate:projection.candidate,options:projection.options,sources:projection.sources,sourceStable:projection.sourceStable,first:{...projection.first,prior:frames},finished:projection.finished,crashes:projection.crashes,projectionProvenance:projection.rawTrace};
if(existsSync(output))throw new Error('Use a fresh external output directory so an earlier receipt cannot be overwritten');
mkdirSync(output,{recursive:true});mkdirSync(resolve(output,'gp-cache-spatial-independent-review'));
symlinkSync(cache,resolve(output,'gp-history-relative-only'),'dir');symlinkSync(spatial,resolve(output,'gp-cache-spatial-candidate'),'dir');
writeFileSync(resolve(output,'gp-cache-ardennes1000-first-fall.json'),JSON.stringify(materialized)+'\n');
const jobs=[['spatial-review.mjs','gp-cache-ardennes1000-spatial-review.json'],['budget-review.mjs','gp-cache-ardennes1000-budget-review.json'],['consumer-onset.mjs','gp-cache-spatial-independent-review/consumer-onset.json']];
const expected=json('reproduction/expected-results.json');
const select={
 'spatial-review.mjs':d=>Object.fromEntries(['frameCount','maximumNativeCorrectionMismatch','maximumPreviewMismatch','maximumTargetDifference','points','rows'].map(k=>[k,d[k]])),
 'budget-review.mjs':d=>d.result,
 'consumer-onset.mjs':d=>Object.fromEntries(['rows','maxTargetError','maxCorrectionError','passed','points','before','after'].map(k=>[k,d[k]])),
};
const started=new Date().toISOString(),results=[];
for(const [script,resultPath]of jobs){
 const run=spawnSync(process.execPath,['--no-warnings','--experimental-transform-types',resolve(base,'reproduction',script)],{cwd:output,encoding:'utf8',maxBuffer:16*1024*1024});
 writeFileSync(resolve(output,script+'.log'),(run.stdout??'')+(run.stderr??''));
 if(run.status!==0)throw new Error(`${script} exited ${run.status}: ${run.stderr}`);
 const result=JSON.parse(readFileSync(resolve(output,resultPath),'utf8'));
 if(script!=='budget-review.mjs'&&result.sourceStable!==true)throw new Error(`${script} source instability`);
 const actual=sha(JSON.stringify(select[script](result)));if(actual!==expected[script].numericResultSha256)throw new Error(`${script} numeric-result mismatch: ${actual}`);
 results.push({script,childExit:run.status,numericResultSha256:actual,matchedSavedResult:true});
}
const sourceFilesAfter={cache:verifySource(cache,'cache'),spatial:verifySource(spatial,'spatial')};
const receipt={started,finished:new Date().toISOString(),package:base,output,mode:'Recorded-state native replay only; no race/integration step; no production edits.',payloadFilesVerified:checked,projectionRows:frames.length,projectionFieldsPerRow:projection.columns.length,rawTrace:projection.rawTrace,rawTraceRequired:false,sourceFilesBefore,sourceFilesAfter,sourceStable:true,cacheSource:cache,spatialSource:spatial,sourceAnchor:identities.anchor,results,passed:true,cacheDisposition:'REJECTED48/51',spatialDisposition:'Race acceptance pending; native results only'};
writeFileSync(resolve(output,'replay-receipt.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt));
