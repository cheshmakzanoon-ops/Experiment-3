import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const root=resolve('gp-history-relative-only');
const load=p=>import(pathToFileURL(resolve(root,p)).href);
const { BikeAIDriver, BIKE_AI, bikePreviewDistance, GP_AI_HANDS }=await load('src/simulation/bike-ai.ts');
const { BikeVehicle }=await load('src/simulation/bike-vehicle.ts');
const { GP_R1 }=await load('src/simulation/bike-definitions.ts');
const { DEFAULT_SETUP }=await load('src/simulation/config.ts');
const { Track, trackPoint }=await load('src/simulation/track.ts');
const { CIRCUITS }=await load('src/simulation/circuits.ts');
const { racingLineFor, RACING_LINE }=await load('src/simulation/racing-line.ts');
const tracePath=resolve('gp-cache-ardennes1000-first-fall.json');
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const sourcePaths=['bike.ts','bike-ai.ts','motogp-physics.ts','ai.ts','traffic.ts','track.ts','racing-line.ts','bike-definitions.ts','circuits.ts'];
const hashes=()=>Object.fromEntries(sourcePaths.map(p=>[p,hash(resolve(root,'src/simulation',p))]));
const sources=hashes(), trace=JSON.parse(readFileSync(tracePath,'utf8'));
const track=new Track('clear',false,undefined,CIRCUITS.ardennes), line=racingLineFor(track);
const bike=new BikeVehicle(0,'medium',DEFAULT_SETUP,'sport',GP_R1), driver=new BikeAIDriver(bike);
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const rows=trace.first.prior.map(frame=>frame.find(r=>r.id===trace.first.rider.id));
const result=[];
for(let i=1;i<rows.length;i++) {
 const before=rows[i-1], now=rows[i],s=before.s,v=before.speed;
 const groundSpeed=Math.hypot(v,before.side);
 bike.s=s; bike.lateral=before.lateral; bike.speed=groundSpeed; bike.dynamics.speed=v;
 bike.dynamics.heading=before.heading; bike.dynamics.motoGP.lateralSpeed=before.side;
 bike.aiOffset=now.aiOffset;
 const width=(1-.45*clamp(before.water[0]/.8,0,1))*(bike.definition.ai.lineScale??1);
 const lane=now.tactical+now.launch;
 const lineAt=station=>driver.lineOffset(track,station,line.offsetAt(station)*width);
 const reachAt=station=>driver.laneReach(track,station,Math.max(1,track.at(station,trackPoint()).width-RACING_LINE.edgeMargin));
 const targetAt=station=>clamp(lineAt(station)+lane,-reachAt(station),reachAt(station));
 const preview=bike.definition.ai.lookahead,near=clamp((preview?.[0]??6)+groundSpeed*(preview?.[1]??.48),8,46);
 const p=track.at(s,trackPoint()),pAhead=track.at(s+near,trackPoint());
 const inferred=now.aiOffset-driver.steeringLineOffset(track,s+near);
 const legacy=driver.pathCorrection(track,inferred,false)*v*v;
 const legacyTarget=driver.steeringTarget;
 const selected=targetAt(s),raw=lineAt(s)+lane;
 const legacySlope=(driver.steeringLineOffset(track,s+3)-driver.steeringLineOffset(track,s-3))/6;
 const selectedSlope=(targetAt(s+3)-targetAt(s-3))/6;
 const relCourse=((before.heading+Math.atan2(before.side,Math.max(v,1))-Math.atan2(p.tx,p.tz)+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;
 const currentLaw=(target,slope)=>clamp(BIKE_AI.bandwidth**2*(target-before.lateral)+2*BIKE_AI.damping*BIKE_AI.bandwidth*v*(Math.atan(slope/Math.max(.5,1-p.curvature*target))-relCourse),-BIKE_AI.correctionG*9.80665,BIKE_AI.correctionG*9.80665);
 const nativeMatch=legacy-now.steeringCorrection;
 const sampleAt=station=>{
  const point=track.at(station,trackPoint()),authored=line.offsetAt(station),k=line.curvatureAt(station);
  const local=targetAt(station),localTactical=local-authored;
  const oldOffset=authored+inferred, oldSlope=(line.offsetAt(station+3)-line.offsetAt(station-3))/6;
  const localSlope=(targetAt(station+3)-targetAt(station-3))/6;
  const oldK=k/Math.max(.5,1-k*inferred),retainedK=k/Math.max(.5,1-k*lane),localK=k/Math.max(.5,1-k*localTactical);
  const world=ss=>{const p=track.at(ss,trackPoint()),d=targetAt(ss);return{x:p.x+p.nx*d,z:p.z+p.nz*d};};
  const chord=h=>{const a=world(station-h),b=world(station),c=world(station+h),ax=b.x-a.x,az=b.z-a.z,bx=c.x-b.x,bz=c.z-b.z;return Math.atan2(az*bx-ax*bz,ax*bx+az*bz)/((Math.hypot(ax,az)+Math.hypot(bx,bz))/2);};
  return{station,roadCurvature:point.curvature,authoredCurvature:k,authoredOffset:authored,oldOffset,selectedOffset:local,localTactical,oldSlope,localSlope,
   oldCurvature:oldK,retainedRawLaneCurvature:retainedK,localOffsetCurvature:localK,selectedWorldChord3:chord(3),selectedWorldChord4:chord(4),
   oldLateral:v*v*oldK,retainedRawLateral:v*v*retainedK,localOffsetLateral:v*v*localK,worldLateralChord3:v*v*chord(3),
   oldMetric:Math.hypot(1-point.curvature*oldOffset,oldSlope),selectedMetric:Math.hypot(1-point.curvature*local,localSlope)};
 };
 const steeringSample=sampleAt(s+bikePreviewDistance(v));
 const approachSamples=Array.from({length:4},(_,i)=>sampleAt(s+bikePreviewDistance(v,1/(2*GP_AI_HANDS.brakeApply))+i*12));
 result.push({time:now.t,preTime:before.t,station:s,recordedPostStation:now.s,speed:v,course:relCourse,
  lateral:before.lateral,lane,width,lineHere:lineAt(s),currentRoadWidth:p.width,previewRoadWidth:pAhead.width,
  currentReach:reachAt(s),previewReach:reachAt(s+near),near,rawCurrent:raw,selectedCurrent:selected,
  selectedPreview:targetAt(s+near),recordedPreview:now.aiOffset,previewError:targetAt(s+near)-now.aiOffset,
  inferredLane:inferred,nativeLegacyTarget:legacyTarget,recordedLegacyTarget:now.steeringTarget,
  targetError:selected-legacyTarget,legacySlope,selectedSlope,nativeCorrection:legacy,recordedCorrection:now.steeringCorrection,nativeMatch,
  correctedTargetOnly:currentLaw(selected,legacySlope),correctedSpatialPath:currentLaw(selected,selectedSlope),
  steeringSample,approachSamples,planRecovery:now.planRecovery,phaseGap:now.planRecovery-Math.abs(now.steeringCorrection),
  lean:now.lean,rate:now.rate,leanTarget:now.leanTarget,brake:now.brake,frontBrake:now.frontBrake,rearBrake:now.rearBrake,
  frontN:now.frontN,rearN:now.rearN,lateralDemand:now.lateralDemand,frontUse:now.frontUse,rearUse:now.rearUse,decision:now.decision});
}
const maxBy=(key)=>result.reduce((a,b)=>Math.abs(a[key])>=Math.abs(b[key])?a:b);
const summary={method:'Read-only native geometry/control evaluation of saved states. Previous completed frame is pre-AI-update physical pose; current frame supplies newly selected tactical and published preview. No simulation steps or candidate edits. Target-only/spatial comparisons are counterfactual instantaneous feedback, not closed-loop outcomes.',root,tracePath,traceHash:hash(tracePath),sources,traceSourcesMatch:Object.entries(trace.sources).every(([k,v])=>sources[k]===v),sourceStable:JSON.stringify(sources)===JSON.stringify(hashes()),frameCount:result.length,maximumNativeCorrectionMismatch:maxBy('nativeMatch'),maximumPreviewMismatch:maxBy('previewError'),maximumTargetDifference:maxBy('targetError'),points:result.filter((_,i)=>i%24===0),rows:result};
writeFileSync('gp-cache-ardennes1000-spatial-review.json',JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({sourceStable:summary.sourceStable,traceSourcesMatch:summary.traceSourcesMatch,nativeMismatch:summary.maximumNativeCorrectionMismatch.nativeMatch,previewMismatch:summary.maximumPreviewMismatch.previewError,maxTargetDifference:summary.maximumTargetDifference.targetError,points:summary.points.map(r=>({time:r.time,s:r.station,v:r.speed,width:r.currentRoadWidth,previewWidth:r.previewRoadWidth,reach:r.currentReach,raw:r.rawCurrent,selected:r.selectedCurrent,inferred:r.nativeLegacyTarget,gap:r.targetError,slope:r.legacySlope,localSlope:r.selectedSlope,correction:r.nativeCorrection,spatialCorrection:r.correctedSpatialPath,phaseGap:r.phaseGap,lean:r.lean,rate:r.rate,brake:r.brake,force:r.frontBrake+r.rearBrake}))}));
