# Minimal GP selected spatial path candidate

## Disposition and source

The isolated source is `/workspace/scratch/0ab62d15db18/gp-cache-spatial-candidate`. It is **rejected**. The original eight selected race gates completed **4/8, guarded exit 1, source stable, 384.452 s**. No original 51-case acceptance run, further onset replay or physics patch will start on this source. The complete structured rejection is in `gp-cache-spatial-rejection.json`.

| Original selected gate | Result |
| --- | --- |
| Ardennes1000 hairpin | Pass |
| Ardennes1037 hairpin | Fail: car 2 at station 3165.3421341682924, before flag |
| Vellamar mixed5222 | Fail: one fall |
| Montejaral mixed5111 | Pass |
| Mixed GP/SBK3303 | Pass, including original fastest-lap margin and incident/finish assertions |
| Aurel clear, eight GP | Fail: peak impact 0.9916666666666667 |
| Poggio clear, eight GP | Fail: peak impact 0.9833333333333334 |
| Poggio rain, eight GP | Pass |

The unmodified mixed3303 test does not print lap values on success, so no exact margin is claimed. The contact failures occur at the impact assertion before per-rider crash assertions; neither a bike-to-bike collision nor a particular fall cause is inferred from that value alone.

The frozen 15-file integration whitelist and complete SHA-256 values are in `gp-cache-spatial-whitelist.json`. Relative to `gp-history-relative-only`, only `src/simulation/ai.ts`, `src/simulation/bike-ai.ts` and two new native test files change. The history physics remains Bike `8aaa0ede…` / MotoGP `2a3bac37…`; traffic remains the original `58bbe1c1…`. New AI hashes are `f349c0851169…` and `7a7a80e83593…`.

## Why this isolated candidate exists

The preceding cache-only source passed the unchanged mixed 5222/5111/3303 trio but completed the original 51-case gate at **48/51**, stable exit one, in 530.455 seconds. Ardennes1000 hairpin failed, as did Aurel and dry Poggio's zero-contact/crash gates on their impact assertions. Ardennes1037, wet Poggio, all fourteen bike-session cases and all six mixed-passing cases passed. The impact assertion values alone do not identify a collision mechanism; per-rider crash assertions occur later in those tests.

Read-only reconstruction of the Ardennes1000 onset reproduced all 479 saved updates' preview offsets and original native correction exactly. The existing base AI selects a road-relative lane, then clips its preview point using the road width at that preview. GP reconstructed the entire lane by subtracting the authored line from that one clipped point. Clipping at the preview therefore changed its inferred target at the current station even when the current point had different available space.

The actual current target, including the original base 2.4 m margin and laneReach override, differed by up to **3.02893 m**. At 81.0526 seconds the selected current point was 4.68907 m and the inferred point 1.78323 m. Later raw selected offsets outside the road bound must not be used as the target: at 82.0526 seconds raw 6.73824 m clips to 4.73357 m, only 0.51787 m beyond the inferred point. The independently measured same-update brake/steer phase gap was much smaller, at most 0.05588 m/s² and mean 0.004843 m/s² over the last four seconds. It did not establish the separate current-path argument handoff as the dominant onset cause.

## Exact change

Base AI now retains this update's selected road width and unprojected lane after placement, takeover rebasing, stalled-vehicle bypass folding, launch decay and normal lane slew. It publishes that snapshot before the ordinary GP braking hook. A protected query evaluates the same authored width, venue line override and local laneReach/road-edge clamp at any station. Current position, preview position and sampled slope therefore belong to the same selected path.

The snapshot is invalidated before base early returns and before the rider-down return. Pit and pit-approach corridors never publish a road snapshot. GP steering and ordinary braking use its retained lane when valid; direct plan/control callers without a snapshot retain their existing fallback, and ordinary non-GP steering ignores it. Authored width is captured as part of the spatial selection: later water changes do not reinterpret that selection, while the next ordinary update adopts the new width.

GP feedback queries the selected current point and its existing ±3 m slope stencil. The ordinary approach profile uses the selected points and slopes for physical path distance and grade. Both steering and the ordinary profile use the retained raw lane in the **existing authored-curvature law**. No temporal-heading term, new curvature stencil, wet-curvature blend, passing forecast, passing admission change, controller gain, grip coefficient or assertion threshold is included.

## Explicit approximation limit

The retained authored curvature divided by its parallel-lane denominator is still an approximation when the selected lane clips at an edge. Merely substituting a local clipped shift is not exact either: that shift changes with station and omitted spatial derivatives matter. This candidate deliberately does not combine a new curvature model with the selected-position/slope ownership change. Independent geometric observations quantify the limitation, but do not claim that this candidate has solved it.

A controlled same-budget reconstruction supports the relevance of the ordinary approach change without claiming an exact fuel/wake replay. At 81.4526 seconds, the existing inferred geometry gives a 12.38778 m/s profile limit; retained raw-lane curvature with locally clamped distance gives 11.51929 m/s. The first physical sample distance changes from 9.59307 to 9.28545 m. Grip, recovery and speed were held fixed; mass/aero were controlled because the saved onset did not record fuel, wake and health. The independent source consumer then matched the correct selected target at all 479 poses exactly and the intended spatial feedback within 1.34e-15.

## Completed native verification

The focused suite passes 99 tests: the existing current-history and cache controls plus nine new spatial cases. The independent lifecycle/width suite passes ten more cases. This is **109 distinct native tests across those two runs**, not 109 races. The final-format nine spatial tests also pass in their own guarded positive run. A private negative source disables only the three selected-path consumer branches while retaining the API and legacy controller; all nine tests fail, guarded exit one and source stable.

The nine spatial tests cover mirrored independent diagonal world paths whose preview clips, the flat local tangent of a fully edge-clipped path, real physical approach sample distance, and real Vellamar updates sharing one current path with braking and steering. The ten lifecycle cases cover native current/preview geometry, the existing road margin, takeover, captured-width lifetime, five invalidation modes and a non-GP negative control. No planner or controller is mocked in those native lifecycle/update cases; analytic geometry alone is prescribed for the diagonal fixtures.

Initial and final full TypeScript checks and scoped lint pass, including the independent lifecycle file after its copy. These checks did not write protected inputs. Original gate source hashes remain byte-identical to the recorded four-file baseline.

## Evidence and reproduction

- `gp-cache-spatial-whitelist.json`: exact 15-file source/test scope and hashes.
- `gp-cache-spatial-review.patch`: compact four-file review delta against the rejected cache-only source; not accepted for integration.
- `gp-cache-spatial-rejection.json`: final structured outcomes and evidence inventory.
- `gp-cache-spatial-original8.json` / `.log`: completed original race receipt, complete input hash and exact outcomes.
- `gp-run-spatial-eight.mjs`: unchanged original assertions selected from the four original gate files: Ardennes1000/1037 hairpins, mixed 5222/5111/3303, and all three eight-rider contact races.
- `gp-cache-spatial-native.log`: initial 99-test result.
- `gp-cache-spatial-positive.json` / `.log` and `gp-cache-spatial-negative.json` / `.log`: paired guarded nine-case native proof.
- `gp-selected-spatial-lifecycle-review/lifecycle-status.json` and `lifecycle.log`: independent ten-case result.
- `gp-cache-spatial-independent-review/receipt.json` and `review.md`: independent final source/scope review and native 479-pose consumer comparison.
- `gp-cache-ardennes1000-review.md` and `gp-cache-ardennes1000-review-index.json`: independent onset geometry and fixed-budget analysis.
- `gp-cache-spatial-final-type.log` / `gp-cache-spatial-final-lint.log`: final static verification outputs.

No larger rejected candidate's passing profile, deadline change, temporal tests or wet-curvature helpers belong in this whitelist. Previous full-matrix/strict-GP results are for different sources and do not establish acceptance here. These eight original gates reject the source. The unchanged original 51 cases and root-owned final repository gates were not repeated for this failed composition.
