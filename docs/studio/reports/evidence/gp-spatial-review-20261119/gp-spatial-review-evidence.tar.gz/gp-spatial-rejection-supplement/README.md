# Completed spatial rejection supplement

**The selected spatial-path candidate is rejected: 4 of 8 original selected race gates pass, 4 fail.** The actual guarded process exited 1 after 384.452 seconds; all 2,237 protected inputs stayed unchanged. This is an evidence supplement, not an accepted physics change or a publication instruction.

## Relationship to the frozen causal package

Keep [`gp-spatial-causal-evidence`](../gp-spatial-causal-evidence/README.md) unchanged. That package preserves the cache-only 48/51 rejection, exact onset reconstruction, controlled budget comparison, source restoration and native consumer/lifecycle proofs. Its selected-race status was pending when it was frozen. **The completed results below supersede only that pending status.** `referenced-package.json` identifies every file and the full frozen package digest; packaging verified it unchanged.

## Completed original race results

| Original gate | Result |
| --- | --- |
| Ardennes hairpin, seed 1000 | Pass |
| Ardennes hairpin, seed 1037 | Fail: car 2 at station 3165.3421341682924, before the flag |
| Vellamar mixed, seed 5222 | Fail: one fall |
| Montejaral mixed, seed 5111 | Pass |
| Mixed GP/SBK, seed 3303 | Pass, including the original pace and incident assertions |
| Aurel clear, eight GP riders | Fail: peak impact 0.9916666666666667 |
| Poggio clear, eight GP riders | Fail: peak impact 0.9833333333333334 |
| Poggio rain, eight GP riders | Pass |

`completed/original8-status.json` and `completed/original8.log.gz` are verbatim or losslessly compressed originals. The four gate files retained their original hashes and assertions. The contact failures occur at the impact assertion before per-rider crash assertions; the values do not identify a collision or another specific event cause. The successful mixed test does not print lap values, so no exact fastest-lap margin is claimed. No full 51-case gate or further onset replay ran on this rejected source.

## Scope and native verification

`scope/final15-whitelist.json` preserves the final 15-file hashes. The review delta changes only two AI production files and adds two spatial test files relative to the already-rejected cache-only source. It retains the current-history foundation, existing gains/grip/thresholds and authored-curvature approximation; it adds no temporal heading, passing-profile/admission change or independent wet-curvature blend. The complete reasoning and limitations are preserved verbatim in `reports/handoff-original.md`.

The **109 distinct passing native cases** are the 99-case focused run in `native/focused99.log.gz` plus the independent 10-case lifecycle run and original receipt in `native/lifecycle-positive*`. They are separate runs, not 109 races or one combined guarded suite. The focused run preceded formatting-only restoration and did not produce its own source-guard receipt. A subsequent final-format guarded positive reran the nine spatial cases successfully; those nine are already included in the 99, not additional cases.

The paired negative run disables only three selected-path consumption branches, retaining the API and legacy fallbacks. All nine spatial cases fail as intended. Positive and negative receipts, logs and complete guard manifests are retained in `native/spatial-*`. `review/negative-consumer-disable.patch.gz` is a packaging-time textual comparison of the two already-existing files; its base, negative, uncompressed and payload hashes are recorded. No negative source was changed or executed during packaging.

Final TypeScript and scoped ESLint both exited zero. Their original logs are retained in `static/`; the previously written `completed/rejection-original.json` records those tool-observed exits. No separate original per-command JSON receipt existed for these static runs, and this supplement does not invent one or rerun the checks.

## Lossless storage and integrity

Raw logs, guard manifests and patches use deterministic gzip to preserve their exact bytes while keeping archive whitespace and lint concerns out of source review. `copy-provenance.json` records original paths, original byte counts/SHA-256 values, payload paths and stored byte counts/SHA-256 values. Every gzip payload was decompressed and byte-compared with its original during staging. All original files remain in place and unchanged.

`SHA256SUMS` covers every other file in this supplement. Run `sha256sum -c SHA256SUMS` from this directory to check stored payloads; decompression hashes are in `copy-provenance.json`. The retained runners under `reproduction/` are provenance and optional future reproduction tools. **No tests, races, source edits or modifications of the frozen causal package were performed while creating this supplement.**
