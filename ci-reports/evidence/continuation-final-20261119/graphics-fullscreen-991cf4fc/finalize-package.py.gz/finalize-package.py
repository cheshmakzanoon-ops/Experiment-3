"""Verify and package the exact isolated 991cf4fc run; never modifies a worktree."""
import gzip,hashlib,json,pathlib,shutil,subprocess
P=pathlib.Path(__file__).resolve().parent
SOURCE='991cf4fc17f46e102318f25b643bc160789203a2'
LOCAL='41c57598b017458c010b0d26d1627691c9b726ac'
TREE='e40d41dd4894f2975e0e78cbbd9557daa43c0957'
RUN=44615583958
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(name):
    p=P/name
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def write(name,value):
    (P/name).write_text(json.dumps(value,indent=2)+'\n')
run=read('run-final.json');jobs=read('jobs-final.json')['jobs'];a=read('high/native-analysis.json')
latest=read('high/last-trace-diagnostic.json.gz');d=latest['diagnostic'];r=d['renderer']
attached=read('high/high-gp-last-diagnostic.json.gz');resource=read('high/resource-evidence.json')
delta=read('high/first-chase-observed-native-delta.json');identity=read('source-identity.json')
assert run['head_sha']==SOURCE and run['head_commit']['tree_id']==TREE
assert run['status']=='completed' and run['conclusion']=='failure'
assert d['buildIdentity']['commit']==SOURCE
assert len(jobs)==5 and sum(j['conclusion']=='success' for j in jobs)==4
assert all(j['status']=='completed' for j in jobs)
assert next(j for j in jobs if j['name']=='high')['conclusion']=='failure'
counts={}
for group in ['gpu','menu','gameplay','high']:
    cases=read(group+'-case-results.json')
    counts[group]={'cases':len(cases),'passed':sum(c['outcome']=='expected' for c in cases),'failed':sum(c['outcome']=='unexpected' for c in cases),'skipped':sum(c['outcome']=='skipped' for c in cases),'flaky':sum(c['outcome']=='flaky' for c in cases),'retries':sum(t['retry'] or 0 for c in cases for t in c['results']),'caseResultsFile':group+'-case-results.json'}
    assert counts[group]['skipped']==counts[group]['flaky']==counts[group]['retries']==0
    if group!='high':assert all(t['status']=='passed' and not t['errors'] for c in cases for t in c['results'])
assert counts['gpu']['passed']==7 and counts['menu']['passed']==7 and counts['gameplay']['passed']==1
assert counts['high']['failed']==1
artifacts={}
for group in counts:
    receipt=read(group+'-download-receipt.json');b=(P/receipt['file']).read_bytes()
    assert receipt['matchesGitHubArtifactDigest'] and len(b)==receipt['bytes'] and sha(b)==receipt['sha256']
    artifacts[group]={**receipt,'includedInCompactPackage':False}
logs=read('log-provenance.json');assert len(logs)==5
for entry in logs:
    b=(P/entry['file']).read_bytes();raw=gzip.decompress(b)
    assert sha(b)==entry['gzipSha256'] and len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
for entry in read('high/attachment-manifest.json'):
    if 'file' not in entry:continue
    p=P/'high'/entry['file'];raw=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
    assert sha(raw)==entry['sha256']
    if 'bytes' in entry:assert len(raw)==entry['bytes']
for entry in read('source-provenance.json')['files']:
    raw=gzip.decompress((P/entry['file']).read_bytes())
    assert len(raw)==entry['bytes'] and sha(raw)==entry['sha256']
previous=P.parent/'background-ci/review-package/graphics-high-journey.spec.ts.gz'
assert gzip.decompress(previous.read_bytes())==gzip.decompress((P/'source/graphics-high-journey.spec.ts.gz').read_bytes())
repo=P.parent.parent/'0ab62d15db18/graphics-startup-precompile'
assert subprocess.check_output(['git','diff','c5cb136355d5fd7f7ca66d6f5cfa392d6f265ed6',LOCAL,'--','.github/workflows/graphics-high-diagnostic.yml','e2e/graphics-high-journey.spec.ts'],cwd=repo)==b''
predicate=a['readinessPredicate'];start=predicate['before']['startTime'];end=predicate['after']['endTime']
pit=next(s for s in a['stages'] if s['stage']=='Warming offscreen pit-service materials…')
assert pit['relativeToReadinessMs']>90000 and latest['endTime']>end
assert r['warmupFrames']==1 and r['scenePass']['frames']==1 and r['scenePass']['samples']==4
assert r['reflectionProbe']['completed']==1 and r['reflectionProbe']['immediateFaces']==6
assert r['gpuFrameQueue']['submitted']==2 and r['gpuFrameQueue']['completed']==0
assert len(a['latePrograms'])==0 and not a['consoleErrorsAndWarnings']
assert all(delta['delta']['counts'][key]==0 for key in ['compileShader','linkProgram','getProgramInfoLog','getActiveUniform','getUniformLocation','getAttribLocation'])
summary={
 'repository':'cheshmakzanoon-ops/Experiment-3','runId':RUN,'sourceCommit':SOURCE,'localReviewedCommit':LOCAL,'tree':TREE,
 'workflowUrl':f'https://github.com/cheshmakzanoon-ops/Experiment-3/actions/runs/{RUN}','attempt':run['run_attempt'],'status':run['status'],'conclusion':run['conclusion'],
 'createdAt':run['created_at'],'updatedAt':run['updated_at'],'jobs':[{k:j.get(k) for k in ['id','name','status','conclusion','started_at','completed_at','html_url']} for j in jobs],
 'browserCounts':counts,'totalBrowserCases':16,'totalPassed':15,'totalFailed':1,
 'originalHighAssertionsPassed':['Menu visible','Positive completed menu GPU submission','Settings modal hidden','Settings transition idle','Applied graphics exactly graphicsPreset(high)'],
 'originalHighAssertionFailed':{'path':'e2e/graphics-high-journey.spec.ts','line':786,'expected':'paused','received':'loading','configuredTimeoutMs':90000,'observedDurationMs':end-start},
 'originalHighAssertionsNotReached':['Paused circuit preparation complete and GPU completion','Active finite GP chassis/contact after resuming simulation','Two completed photo views, held frame, exact High options and 960x600 dimensions','Final backend/build/error assertions and complete High acceptance'],
 'high':{
  'testDurationMs':a['durationMs'],'readinessStartTraceTime':start,'readinessFailureTraceTime':end,'firstChase':a['firstChase'],
  'firstChaseDrawReturnedBy':{'nextStage':pit['stage'],'traceTime':pit['traceTime'],'relativeToReadinessMs':pit['relativeToReadinessMs'],'afterFailedAssertionMs':pit['traceTime']-end},
  'latestTraceDiagnostic':{'endTime':latest['endTime'],'relativeToReadinessMs':latest['endTime']-start,'afterFailedAssertionMs':latest['endTime']-end,'state':d['state'],'buildIdentity':d['buildIdentity'],'preparation':r['preparation'],'warmupFrames':r['warmupFrames'],'warmupPitPasses':r['warmupPitPasses'],'scenePassFrames':r['scenePass']['frames'],'scenePassSamples':r['scenePass']['samples'],'reflectionProbe':r['reflectionProbe'],'gpuFrameQueue':r['gpuFrameQueue']},
  'originalAttachedDiagnostic':{'lastObservedAt':attached['lastObservedAt'],'state':attached['lastDiagnostic']['state'],'lastPreparationStage':attached['lastDiagnostic']['renderer']['preparation']['stages'][-1],'errors':attached['errors'],'note':'This attachment predates the first chase. The trace contains a later evaluate completion after the failed assertion.'},
  'lastNativeSnapshot':{'traceTime':a['lastActivity']['traceTime'],'beforeFailedAssertionMs':end-a['lastActivity']['traceTime'],'inFlight':a['lastActivity']['inFlight'],'lastStarted':a['lastActivity']['lastStarted'],'lastCompleted':a['lastActivity']['lastCompleted'],'counts':a['lastActivity']['counts'],'note':'Before-deadline worker snapshot; its zero fence counts do not supersede the later post-deadline application diagnostic.'},
  'observedFirstChaseNativeDelta':delta,'latePrograms':a['latePrograms'],'consoleErrorsAndWarnings':a['consoleErrorsAndWarnings'],
  'construction':r['construction'],'maximumConstructionTaskEvidence':resource['maximumConstructionTaskEvidence'],
  'uploadResourceIdentity':'Not retained. Current program/framebuffer, byte count and Three helper stack cannot establish asset identity or duplicate native resource transfer.',
  'duplicateImmutableStorageWarnings':len(resource['traceWarningsAndErrors']),
 },
 'backend':read('high/browser-backend.json'),'artifacts':artifacts,
 'verification':{'allFiveCompleteDecodedJobLogsHashVerified':True,'allFourDownloadedZipDigestsMatchGitHub':True,'originalHighAttachmentDigestsVerified':True,'retainedSourceDigestsVerified':True,'originalHighTestAndWorkflowUnchanged':True,'remoteTreeAndDiagnosticBuildCommitMatchReviewedSource':True},
 'limitations':a['limitations']+['This isolated candidate run is not main CI.','CPU native-call totals can include queued driver work and instrumentation; they do not isolate transfer or pure GPU cost.','The newer diagnostic and first completed draw arrive after the failed assertion and do not establish High acceptance.','No cockpit warmup or photo acceptance was reached.','Software Mesa/llvmpipe is not physical-hardware FPS validation.','Repeated network requests do not prove duplicate native resource transfers.']
}
write('summary.json',summary)
readme=f'''# 991cf4fc isolated graphics run — final evidence

Exact source **{SOURCE}**, reviewed local commit **{LOCAL}**, tree **{TREE}**. Run **{RUN}**, attempt 1, finished **failure**. This is an isolated candidate result, not main CI.

| Job | Verdict | Original browser cases |
| --- | --- | --- |
| build | success | Production build completed |
| GPU components | success | 7 passed |
| Menu and settings | success | 7 passed |
| Gameplay journey | success | 1 passed |
| High GP journey | failure | 1 failed |

All 16 cases ran without retries, skips or flaky results. High failed the unchanged line 786 readiness predicate: expected paused, received loading, configured 90,000 ms and observed 90,000.214 ms. Its total 156,619 ms includes setup and evidence capture. No downstream paused, driving, photo or final High acceptance assertion ran.

## What the trace establishes

The first chase draw began at readiness **+39,843.517 ms**. Its stage lasted **51,138.3 ms**. The next stage, warming offscreen pit-service materials, appeared at **+90,983.346 ms**, approximately 983 ms after the readiness assertion had failed. This is progress beyond the previous late-exposure owner, while the original acceptance result remains failed.

The newest trace diagnostic returned at **+91,044.272 ms**, 1,044.058 ms after failure. It records one warmup frame, one scene-pass frame, one completed six-face local probe, GPU submitted=2/completed=0, and preparation still warming pit materials. That diagnostic is newer than the original last-diagnostic attachment, which was serialized before the chase during post-processing preparation. Both are preserved with their distinct provenance.

The final native worker snapshot was **71.267 ms before** assertion failure. It records a returned drawElementsInstanced call, not an in-flight metadata stall. Its zero fence counts must not be presented as the final application state after the deadline. No cockpit stage, late-program record, GL error or immutable-texture reallocation warning appears.

Subtracting the final pre-chase worker snapshot yields **zero new compileShader, linkProgram, getProgramInfoLog, active-uniform, uniform-location or attribute-location calls** during the observed chase. Instead it records 209 texSubImage2D calls with 27,102.1 ms aggregate CPU-call time and 3,850 bufferData calls with 16,387.7 ms. These durations can include previously queued driver work and instrumentation; they are not pure GPU or isolated transfer costs. Sixteen bounded slow-upload records retain sizes and Three helper stacks, but no texture/buffer identity or asset URL. Equal transfer sizes or the current program do not prove duplicate resource transfer.

## Construction and preparation intervals

Recorded sky preparation took 5,431.1 ms, scene compilation 10,965.4 ms, native scene metadata preparation 244 ms, fullscreen preparation 1,153.8 ms, and shadow-caster preparation 475.1 ms. Construction recorded 445 tasks, 128 yields, 13,420.7 ms work and a 5,369.7 ms maximum task.

The independent worker retained every observed loading-label change even when native tracing was inactive. Its **Far sun shadow** label at trace 68,828.816 ms changes to Scene ready at 74,201.391 ms: a 5,372.575 ms interval that corroborates the 5,369.7 ms maximum allowing reporting overhead. Spatial geometry batching occupied approximately 259.764 ms; it is not the five-second interval. The far-shadow interval has no retained per-native-call breakdown, so its internal cost is not attributed further.

## Retained package

summary.json records exact source, job timestamps, all case counts, original assertion reach, before/after-deadline timing, backend and limits. Complete decoded job logs are losslessly gzipped and hash-verified. Each passing case retains its original title, status, duration and retry. The High directory contains original diagnostic attachments, native records, complete bounded upload stacks, assertion timeline, newer trace diagnostic, worker-label timeline and resource-evidence limits. Source files and the unchanged original test/workflow are retained with SHA-256 provenance. The parser scripts reproduce the principal extraction from the original archives.

All four downloaded artifact ZIPs match GitHub's SHA-256 digest. Original ZIPs remain outside this compact package; the High archive is 106,750,195 bytes. No additional browser run, workflow retry/cancellation, remote write or production source change was performed by this audit.

Backend is ANGLE Mesa llvmpipe software WebGL2. This record does not certify physical-hardware FPS or completed High appearance.
'''
(P/'README.md').write_text(readme)
package=P/'review-package';assert not package.exists(),'Refusing to overwrite a finalized package';package.mkdir()
names=['README.md','summary.json','run-final.json','jobs-final.json','artifacts-final.json','source-identity.json','source-provenance.json','log-provenance.json']
names += [g+'-job.log.gz' for g in ['build','gpu','menu','gameplay','high']]
names += [g+'-case-results.json' for g in ['gpu','menu','gameplay','high']]
names += [g+'-download-receipt.json' for g in ['gpu','menu','gameplay','high']]
names += [g+'-browser-backend.json' for g in ['gpu','menu','gameplay']]
for name in names:shutil.copy2(P/name,package/name)
for directory in ['high','source']:shutil.copytree(P/directory,package/directory)
for name in ['analyze-high.py','extract-report.py','finalize-package.py']:
    (package/(name+'.gz')).write_bytes(gzip.compress((P/name).read_bytes(),mtime=0))
manifest=[]
for path in sorted(package.rglob('*')):
    if path.is_file():manifest.append(sha(path.read_bytes())+'  '+str(path.relative_to(package)))
(package/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
receipt={'path':str(package),'files':len(manifest)+1,'bytes':sum(p.stat().st_size for p in package.rglob('*') if p.is_file()),'summarySha256':sha((package/'summary.json').read_bytes()),'allSourceLogAndArtifactDigestsVerified':True}
write('package-receipt.json',receipt);print(json.dumps(receipt,indent=2))
