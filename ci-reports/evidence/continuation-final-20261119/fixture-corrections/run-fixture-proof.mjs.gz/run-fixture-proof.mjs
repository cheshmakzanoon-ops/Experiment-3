import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const root = '/workspace/scratch/dac6891506fb/fixture-repair';
const destination = '/workspace/scratch/dac6891506fb/fixture-evidence';
const require = createRequire(path.join(root, 'package.json'));
const { build } = require('esbuild');
const ts = require('typescript');
const canvas = require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');
globalThis.HTMLCanvasElement = canvas.Canvas;
globalThis.document = {
  createElement(name) {
    assert.equal(name, 'canvas');
    return canvas.createCanvas(1, 1);
  },
};
const files = ['e2e/fixtures/apx01-assembly.ts', 'e2e/fixtures/gp-contact-effects.ts', 'e2e/09-reference-depth.spec.ts'];
const sha = data => createHash('sha256').update(data).digest('hex');
const inputs = {};
for (const file of files) {
  inputs[file] = {
    baseline: execFileSync('git', ['show', '57d1a98:' + file], { cwd: root, encoding: 'utf8' }),
    candidate: await readFile(path.join(root, file), 'utf8'),
  };
}
const extraGp = `
export function exerciseFlatRoad() {
  const bike = new ContactBike(0, 'wet', DEFAULT_SETUP, 'sport', GP_R1);
  bike.placeFree(flatRoad, 0, 0, 0, 0);
  let poses = 0;
  for (const lean of [-0.8, 0, 0.8]) for (const pitch of [-0.12, 0, 0.12]) {
    bike.dynamics.lean = lean;
    bike.dynamics.pitch = pitch;
    bike.dynamics.state = 'riding';
    bike.dynamics.speed = 30;
    bike.pose(flatRoad);
    const {position:p, orientation:q} = bike.body;
    if (![p.x,p.y,p.z,q.x,q.y,q.z,q.w].every(Number.isFinite)) throw new Error('Nonfinite actual GP body');
    poses++;
  }
  return {poses, bodyFinite:true};
}
`;
async function bundled(file, version, append='') {
  const target = path.join(root,file);
  const out = path.join(destination, path.basename(file,'.ts')+'-'+version+'.mjs');
  await build({
    entryPoints:[target], outfile:out, bundle:true, platform:'node', format:'esm', logLevel:'error',
    loader:{'.frag':'text','.vert':'text'},
    define:{__SUPPLIED_PLAYER__:'false',__REVIEW_TOOLS__:'true'},
    plugins:[{name:'exact-fixture-source',setup(b){b.onLoad({filter:/\.ts$/},args=>args.path===target?{contents:inputs[file][version]+append,loader:'ts'}:undefined);}}],
  });
  return import(pathToFileURL(out).href);
}
const report = {source:'57d1a98', kind:'CPU proof using real runtime geometry and native Canvas 2D; no browser or WebGL', inputs:Object.fromEntries(Object.entries(inputs).map(([file,v])=>[file,{baselineSha256:sha(v.baseline),candidateSha256:sha(v.candidate)}])),results:{}};
for (const version of ['baseline','candidate']) {
  const gp = await bundled('e2e/fixtures/gp-contact-effects.ts',version,extraGp);
  try {report.results['gp-'+version]={pass:true,...gp.exerciseFlatRoad()};}
  catch(error){report.results['gp-'+version]={pass:false,error:String(error)};}
  assert.equal(report.results['gp-'+version].pass,version==='candidate');
  if(version==='baseline')assert.match(report.results['gp-'+version].error,/cast is not a function/);

  const assembly = await bundled('e2e/fixtures/apx01-assembly.ts',version);
  try {
    const result=await assembly.exercise([...await readFile(path.join(root,'src/rendering/apx01-shell.glb.gz'))],[...await readFile(path.join(root,'src/rendering/apx01-driver.glb.gz'))]);
    report.results['assembly-'+version]={pass:true,report:result};
  }catch(error){report.results['assembly-'+version]={pass:false,error:String(error)};}
  assert.equal(report.results['assembly-'+version].pass,version==='candidate');
  if(version==='baseline')assert.match(report.results['assembly-'+version].error,/Upright joint detached: 0\.060000/);

  const source=inputs['e2e/09-reference-depth.spec.ts'][version];
  const expression=source.match(/\.poll\((async \(\) => \(await diag\(page\)\)\.[^\n]+geometrySurvey\.count[^\n]*)\)\n\s*\.toBeGreaterThan\(0\)/)?.[1];
  assert.ok(expression,'Must locate the exact original geometry-survey poll callback and unchanged greater-than-zero assertion');
  const js=ts.transpileModule('const read = '+expression+';', {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
  const states=[{}, {renderer:{geometrySurvey:{count:0}}}, {renderer:{geometrySurvey:{count:12}}}];
  const callback=new Function('diag','page',js+'\nreturn read;')(async()=>states.shift(),{});
  try {
    const observed=[await callback(),await callback(),await callback()];
    assert.deepEqual(observed,[0,0,12]);
    report.results['survey-'+version]={pass:true,observed,accepted:observed.map(value=>value>0)};
  }catch(error){report.results['survey-'+version]={pass:false,error:String(error)};}
  assert.equal(report.results['survey-'+version].pass,version==='candidate');
  if(version==='baseline')assert.match(report.results['survey-'+version].error,/geometrySurvey/);
}
for(const file of files)assert.equal(sha(await readFile(path.join(root,file))),report.inputs[file].candidateSha256);
report.inputsStable=true;
await writeFile(path.join(destination,'native-proof.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
