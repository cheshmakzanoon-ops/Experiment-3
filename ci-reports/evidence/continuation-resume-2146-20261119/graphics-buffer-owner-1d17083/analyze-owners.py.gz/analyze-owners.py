"""Audit bounded, retained native buffer metadata; never infer payload equality."""
from pathlib import Path
from collections import Counter
import gzip
import json

root = Path(__file__).resolve().parent / 'high'

def read(name, default=None):
    path = root / name
    if path.exists():
        return json.loads(path.read_bytes())
    path = root / (name + '.gz')
    return json.loads(gzip.decompress(path.read_bytes())) if path.exists() else default

analysis = read('native-analysis.json', {})
native_path = root / 'native-console-records.jsonl.gz'
if native_path.exists():
    events = [json.loads(row) for row in gzip.decompress(native_path.read_bytes()).splitlines()]
    provenance = 'original retained trace console events'
else:
    attached = read('high-gp-startup-commands.json', {})
    events = attached.get('records', []) + attached.get('slowUploads', [])
    provenance = 'original bounded test attachment; trace-relative times unavailable'

chase = analysis.get('firstChase') or next((row for row in events
    if row.get('kind') == 'stage' and 'Warming shadows and scene reflections' in row.get('stage', '')), {})
chase_ms = chase.get('atMs')
retained = {}
inconsistencies = []

def take(event, call, kind):
    owner = call.get('bufferOwner') if isinstance(call, dict) else None
    if not owner:
        return
    key = (event.get('pageId'), owner['context'], owner['generation'], owner['upload'])
    row = retained.get(key)
    if row is None:
        row = retained[key] = {
            'pageId': event.get('pageId'), 'sequence': call.get('sequence'),
            'method': call.get('method'), 'nativeAtMs': call.get('atMs'),
            'owner': owner, 'firstObservedTraceTime': event.get('traceTime'),
            'lastObservedTraceTime': event.get('traceTime'),
            'observedKinds': [], 'stages': [], 'returnedObserved': False,
            'maxObservedInFlightMs': 0, 'returnedCpuCallMs': None,
        }
    elif row['owner'] != owner:
        inconsistencies.append({'key': key, 'reason': 'same upload ID has differing owner metadata'})
    if owner['method'] != call.get('method'):
        inconsistencies.append({'key': key, 'reason': 'native call method and owner method differ'})
    if kind not in row['observedKinds']:
        row['observedKinds'].append(kind)
    if event.get('stage') not in row['stages']:
        row['stages'].append(event.get('stage'))
    if call.get('atMs') is not None:
        row['nativeAtMs'] = call['atMs']
    if event.get('traceTime') is not None:
        row['lastObservedTraceTime'] = event['traceTime']
    if kind == 'activity-last-started':
        end = event.get('lastCompleted') or {}
        if end.get('sequence') == call.get('sequence'):
            row['returnedObserved'] = end.get('returned') is True
            row['returnedCpuCallMs'] = end.get('cpuCallMs')
        if event.get('inFlight'):
            row['maxObservedInFlightMs'] = max(row['maxObservedInFlightMs'], event.get('observedInFlightMs', 0))
    else:
        row['returnedObserved'] = True
        row['returnedCpuCallMs'] = call.get('cpuCallMs')

for event in events:
    if event.get('kind') == 'activity':
        take(event, event.get('lastStarted'), 'activity-last-started')
        for call in event.get('slowCalls', []):
            take(event, call, 'activity-retained-slow-call')
    elif event.get('kind') == 'slow-upload':
        take(event, event, 'main-thread-slow-upload')

rows = sorted(retained.values(), key=lambda row: (row['sequence'] or 0, row['owner']['upload']))
for row in rows:
    if row['nativeAtMs'] is not None and chase_ms is not None:
        row['chaseClassification'] = 'started-after-chase-label' if row['nativeAtMs'] >= chase_ms else 'started-before-chase-label'
    elif 'main-thread-slow-upload' in row['observedKinds']:
        # The unchanged producer emits this record only when chaseStarted is true.
        row['chaseClassification'] = 'returned-under-chase-enabled-producer'
    else:
        row['chaseClassification'] = 'unknown-call-start-window'

repeated_views = []
for row in rows:
    owner = row['owner']
    for prior in owner.get('priorBuffersForView', []):
        if prior['buffer'] == owner['buffer']:
            relation = 'same-view-seen-earlier-on-current-buffer'
        elif prior['context'] != owner['context']:
            relation = 'same-view-seen-in-another-context'
        elif prior['generation'] != owner['generation']:
            relation = 'same-view-seen-in-another-context-generation'
        elif prior['deleteObserved']:
            relation = 'same-view-seen-on-another-buffer-with-deletion-observed'
        else:
            relation = 'same-view-seen-on-another-buffer-without-a-retained-deletion'
        repeated_views.append({'sequence': row['sequence'], 'upload': owner['upload'],
            'view': owner['view'], 'currentBuffer': owner['buffer'], 'currentRenderer': owner['renderer'],
            'context': owner['context'], 'generation': owner['generation'], 'relation': relation,
            'prior': prior, 'currentAttribution': owner['attribution'],
            'currentExact': owner['exact'], 'priorHistoryTruncated': owner['priorBuffersTruncated']})

last_activity = next((event for event in reversed(events) if event.get('kind') == 'activity'), None)
classifications = Counter(row['owner']['attribution'] for row in rows)
limitations = [
    'Only worker snapshots and bounded retained slow calls are represented; these are not counts of all native uploads.',
    'Registered-array matches remain candidate consumers, including when only one candidate is retained.',
    'Exact direct-index claims apply only to the actual non-wireframe invocation and the live index view at that call.',
    'Typed-array identity does not establish unchanged submitted bytes, and backing-buffer identity is weaker still.',
    'Prior-view history totals belong to the native buffer lifetime, not exclusively to that view; returns may be zero.',
    'An earlier buffer can belong to another renderer; prior history alone does not retain that renderer identity.',
    'No native driver query confirms attempted binding/deletion success; bufferKnown is knowledge from observed native calls.',
    'Metadata/inventory/postMessage overhead affects whole-startup timing, while native CPU spans can wait behind earlier queued GPU work.',
]
summary = {
    'source': '1d17083c7364b0d960d3f4a548139ac95077daa2', 'run': 44631109424, 'job': 135937650956,
    'provenance': provenance, 'retainedUniqueUploadRecords': len(rows),
    'attributionCountsInRetainedRecords': dict(classifications),
    'chaseWindowCountsInRetainedRecords': dict(Counter(row['chaseClassification'] for row in rows)),
    'distinctNativeContexts': sorted({row['owner']['context'] for row in rows}),
    'contextGenerations': sorted({(row['owner']['context'], row['owner']['generation']) for row in rows}),
    'unknownNativeBufferRecords': sum(not row['owner']['bufferKnown'] for row in rows),
    'recordsWithInventoryTruncation': sum(row['owner']['inventoryTruncated'] for row in rows),
    'recordsWithAliasTruncation': sum(row['owner']['aliasesTruncated'] for row in rows),
    'recordsWithPriorHistoryTruncation': sum(row['owner']['priorBuffersTruncated'] for row in rows),
    'recordsWithStaleCandidates': sum(row['owner']['staleCandidates'] > 0 for row in rows),
    'priorViewRelations': dict(Counter(row['relation'] for row in repeated_views)),
    'observerUnavailable': [event for event in events if event.get('kind') == 'unavailable'],
    'identityInconsistencies': inconsistencies,
    'lastActivity': last_activity,
    'lastRetainedUpload': rows[-1] if rows else None,
    'limitations': limitations,
}
(root / 'retained-buffer-owners.json.gz').write_bytes(gzip.compress((json.dumps(rows, indent=2)+'\n').encode(), mtime=0))
(root / 'prior-view-relations.json.gz').write_bytes(gzip.compress((json.dumps(repeated_views, indent=2)+'\n').encode(), mtime=0))
(root / 'buffer-owner-analysis.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({key: summary[key] for key in ['retainedUniqueUploadRecords', 'attributionCountsInRetainedRecords',
    'contextGenerations', 'unknownNativeBufferRecords', 'recordsWithInventoryTruncation',
    'priorViewRelations', 'observerUnavailable', 'identityInconsistencies', 'lastRetainedUpload']}, indent=2))
