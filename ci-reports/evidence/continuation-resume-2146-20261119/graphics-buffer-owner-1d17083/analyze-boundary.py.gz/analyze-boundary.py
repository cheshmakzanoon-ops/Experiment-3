"""Keep configured acceptance, observed trace spans and GPU completion distinct."""
from pathlib import Path
import gzip
import json

root = Path(__file__).resolve().parent / 'high'
def read(name):
    p = root / name
    return json.loads(p.read_bytes()) if p.exists() else json.loads(gzip.decompress((root / (name+'.gz')).read_bytes()))

analysis = read('native-analysis.json')
latest = read('last-trace-diagnostic.json')
records = [json.loads(row) for row in gzip.decompress((root/'native-console-records.jsonl.gz').read_bytes()).splitlines()]
predicate = analysis['readinessPredicate']
start, end = predicate['before']['startTime'], predicate['after']['endTime']
chase = analysis['firstChase']['traceTime']
activities = [row for row in records if row.get('kind') == 'activity']
before = max((row for row in activities if row['traceTime'] < chase), key=lambda row: row['traceTime'])
last = max((row for row in activities if row['traceTime'] < end), key=lambda row: row['traceTime'])
delta = {key: {method: last[key].get(method, 0)-before[key].get(method, 0)
               for method in sorted(set(last[key])|set(before[key]))} for key in ['counts','cpuMs']}
diagnostic = latest['diagnostic']
assert diagnostic['buildIdentity']['commit'] == '1d17083c7364b0d960d3f4a548139ac95077daa2'
labels=[]
for row in records:
    label=row.get('stage')
    if label is None or (labels and labels[-1]['stage']==label): continue
    labels.append({'traceTime':row['traceTime'],'relativeToReadinessTraceStartMs':row['traceTime']-start,
                   'stage':label,'kind':row['kind']})
for i,row in enumerate(labels[:-1]):row['nextObservedLabelAfterMs']=labels[i+1]['traceTime']-row['traceTime']
boundary={
    'source':'1d17083c7364b0d960d3f4a548139ac95077daa2','run':44631109424,
    'predicate':{'configuredTimeoutMs':90000,'traceStart':start,'traceEnd':end,'observedTraceSpanMs':end-start,
                 'failure':'expected paused, received loading; original 90000 ms timeout reported'},
    'firstChaseRelativeToPredicateTraceStartMs':chase-start,
    'configuredBudgetMinusObservedChaseOffsetMs':90000-(chase-start),
    'observedPredicateEndMinusChaseMs':end-chase,
    'preChaseSnapshot':{'traceTime':before['traceTime'],'stage':before['stage']},
    'lastPrePredicateEndSnapshot':{'traceTime':last['traceTime'],'relativeMs':last['traceTime']-start,
        'beforePredicateEndMs':end-last['traceTime'],'stage':last['stage'],'inFlight':last['inFlight'],
        'observedInFlightMs':last['observedInFlightMs'],'lastStarted':last['lastStarted'],'lastCompleted':last['lastCompleted']},
    'lastSuccessfulApplicationDiagnostic':{'traceTime':latest['endTime'],'relativeMs':latest['endTime']-start,
        'beforePredicateEndMs':end-latest['endTime'],'afterChaseStartMs':latest['endTime']-chase,
        'buildIdentity':diagnostic['buildIdentity'],'state':diagnostic['state'],
        'warmupFrames':diagnostic['renderer']['warmupFrames'],
        'gpuFrameQueue':diagnostic['renderer']['gpuFrameQueue'],
        'preparation':diagnostic['renderer']['preparation'],
        'reflectionCaptureSubmissionMetric':diagnostic['renderer']['reflectionProbe'],
        'reflectionMetricMeaning':'Capture/submission calls returned. This metric does not certify GPU completion.'},
    'observedChaseThroughPitDelta':delta,'latePrograms':analysis['latePrograms'],
    'consoleErrorsAndWarnings':analysis['consoleErrorsAndWarnings'],
    'limitations':[
        'Configured predicate timeout remains90000ms. Recorded trace operation span is reported separately without treating its instrumentation boundary as the internal timeout start.',
        'Native counts cover selected trace-active stages, not all construction/texture-preparation work.',
        'CPU call spans can include queued prior GPU work; owner metadata overhead is outside those spans but inside total startup time.',
        'A returned cube capture or scene draw does not certify GPU completion; the final fence queue remains pending with completed0.',
        'No cockpit, paused/driving or photo acceptance assertion follows the failed readiness predicate.',
        'The observer/source did not change production rendering, so cross-run timing differences are not a demonstrated source optimization.',
    ],
}
(root/'first-chase-boundary.json').write_text(json.dumps(boundary,indent=2)+'\n')
(root/'worker-label-timeline.json').write_text(json.dumps(labels,indent=2)+'\n')
print(json.dumps({'predicate':boundary['predicate'],'firstChaseRelativeMs':chase-start,
    'lastDiagnosticBeforePredicateEndMs':end-latest['endTime'],
    'counts':{name:delta['counts'].get(name) for name in ['bufferData','bufferSubData','texSubImage2D','drawElements','drawElementsInstanced','fenceSync','clientWaitSync','flush','compileShader','linkProgram','getProgramInfoLog']},
    'cpuMs':{name:delta['cpuMs'].get(name) for name in ['bufferData','bufferSubData','texSubImage2D','drawElements','drawElementsInstanced','clientWaitSync']},
    'labelChanges':len(labels)},indent=2))
