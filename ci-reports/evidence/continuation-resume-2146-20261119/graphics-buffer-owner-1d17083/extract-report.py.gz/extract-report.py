"""Extract original HTML-reporter results from an unmodified artifact ZIP."""
import base64,hashlib,io,json,pathlib,re,sys,zipfile
archive=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);group=sys.argv[3]
out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive) as z:
    html=z.read('playwright-report/index.html').decode()
    match=re.search(r'<script[^>]+id="playwrightReportBase64"[^>]*>(.*?)</script>',html,re.S)
    payload=match[1].strip().split('base64,',1)[-1]
    cases=[]
    with zipfile.ZipFile(io.BytesIO(base64.b64decode(payload))) as report:
        metadata=json.loads(report.read('report.json'))
        for name in report.namelist():
            if not name.endswith('.json') or name=='report.json':continue
            data=json.loads(report.read(name))
            if not isinstance(data,dict):continue
            for test in data.get('tests',[]):
                cases.append({k:test.get(k) for k in ['testId','title','path','projectName','location','outcome','duration']} | {'results':[{k:result.get(k) for k in ['status','duration','retry','startTime','errors']} for result in test.get('results',[])]})
    (out/(group+'-report-metadata.json')).write_text(json.dumps(metadata,indent=2)+'\n')
    (out/(group+'-case-results.json')).write_text(json.dumps(cases,indent=2)+'\n')
    for name in ['browser-backend.json','browser-progress.json']:
        if name in z.namelist():(out/(group+'-'+name)).write_bytes(z.read(name))
summary={'group':group,'cases':len(cases),'passed':sum(t['outcome']=='expected' for t in cases),'failed':sum(t['outcome']=='unexpected' for t in cases),'flaky':sum(t['outcome']=='flaky' for t in cases),'skipped':sum(t['outcome']=='skipped' for t in cases),'retries':sum(r['retry'] or 0 for t in cases for r in t['results'])}
print(json.dumps(summary))
