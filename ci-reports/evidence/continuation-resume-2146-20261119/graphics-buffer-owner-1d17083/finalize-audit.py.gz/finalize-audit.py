"""Seal compact exact-source CI evidence. Original ZIPs stay beside this package."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

root = Path(__file__).resolve().parent
package = root / 'review-package'
assert not package.exists(), 'Never overwrite a sealed package'
package.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda name: json.loads((root / name).read_bytes())
run = read('run-final.json')
coverage = read('case-coverage.json')
boundary = read('high/first-chase-boundary.json')
owners = read('high/buffer-owner-analysis.json')
cases = read('all-original-cases.json')
assert len({case['testId'] for case in cases}) == 16
assert run['head_sha'] == '1d17083c7364b0d960d3f4a548139ac95077daa2'
assert run['status'] == 'completed' and run['conclusion'] == 'failure'
assert coverage['passed'] == 15 and coverage['failed'] == 1
artifacts = [read(group+'-download-receipt.json') for group in ['build','gpu','menu','gameplay','high']]
logs = [read(group+'-log-receipt.json') for group in ['build','gpu','menu','gameplay','high']]
for row in artifacts:
    data = (root / row['file']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
for row in logs:
    data = (root / row['file']).read_bytes()
    assert sha(data) == row['sha256']
    decoded = gzip.decompress(data)
    assert len(decoded) == row['decoded_bytes'] and sha(decoded) == row['decoded_sha256']
retained = json.loads(gzip.decompress((root/'high/retained-buffer-owners.json.gz').read_bytes()))
garage = next(row for row in retained if row['sequence'] == 23145)
assert garage['owner']['attribution'] == 'exact-direct-index'
assert garage['owner']['exact']['path'][-1].startswith('Mesh:LOD1_GARAGE_TeamEnamel#')
summary = {
    'source':run['head_sha'],'tree':'efa81a0e2ef87d079d355a457c67be24b0a8f263',
    'parent':'f22622e3302ed6147c5aae6f8eb6f6bc4057a242',
    'matchingLocalCommit':'07bf358316f4a51e1566a052628ca57a68ca2610',
    'branch':run['head_branch'],'run':run['id'],'attempt':run['run_attempt'],
    'workflow':run['path'],'url':run['html_url'],'conclusion':run['conclusion'],
    'coverage':coverage,'uniqueOriginalTestIds':16,
    'artifacts':artifacts,'logs':logs,
    'high':{
        'wholeTestDurationMs':read('high/native-analysis.json')['durationMs'],
        'predicate':boundary['predicate'],
        'firstChaseRelativeToPredicateTraceStartMs':boundary['firstChaseRelativeToPredicateTraceStartMs'],
        'lastSuccessfulApplicationDiagnostic':boundary['lastSuccessfulApplicationDiagnostic'],
        'observedChaseThroughPitDelta':boundary['observedChaseThroughPitDelta'],
        'lastPrePredicateEndSnapshot':boundary['lastPrePredicateEndSnapshot'],
        'exactGarageIndexObservation':garage,
        'ownerSample':{key:owners[key] for key in [
            'retainedUniqueUploadRecords','attributionCountsInRetainedRecords','contextGenerations',
            'unknownNativeBufferRecords','recordsWithInventoryTruncation','recordsWithAliasTruncation',
            'recordsWithPriorHistoryTruncation','recordsWithStaleCandidates','priorViewRelations',
            'observerUnavailable','identityInconsistencies']},
        'noLaterAcceptance':'No paused/driving/cockpit/photo acceptance follows the failed readiness predicate.',
        'gpuCompletion':'Six reflection face capture/submission calls and one scene frame returned; the fresh final GPU frame queue is pending, submitted2/completed0.',
        'appearance':'Original High photo views were not reached; authored-scene appearance remains unverified.',
        'limitations':owners['limitations']+boundary['limitations'],
    },
    'actions':'Read-only GitHub GETs and isolated scratch analysis. No source/ref changes, workflow rerun/cancel, or local browser execution.',
}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files = ['summary.json','run-final.json','jobs-final.json','artifacts-final.json',
         'remote-source.json','source-provenance.json','build-source-proof.json','case-coverage.json','all-original-cases.json']
for group in ['build','gpu','menu','gameplay','high']:
    files += [group+'-download-receipt.json',group+'-artifact-descriptor.json',group+'-log-receipt.json',group+'-job.log.gz']
for group in ['gpu','menu','gameplay','high']:
    files += [group+'-case-results.json',group+'-report-metadata.json',group+'-browser-backend.json',group+'-browser-progress.json']
for name in files:
    p=root/name
    assert p.is_file(), name
    shutil.copyfile(p,package/name)
shutil.copytree(root/'high',package/'high')
scripts = ['extract-report.py','verify-artifact.py','analyze-high.py','analyze-owners.py','analyze-boundary.py','finalize-audit.py']
for name in scripts:
    (package/(name+'.gz')).write_bytes(gzip.compress((root/name).read_bytes(),mtime=0))
repo = Path('/workspace/scratch/dac6891506fb/graphics-buffer-owner-2218')
provenance=read('source-provenance.json'); receipt=provenance['unchanged_acceptance_receipt']
snapshots=[]
for name,digest in receipt['source_hashes'].items():
    data=subprocess.check_output(['git','show',summary['matchingLocalCommit']+':'+name],cwd=repo)
    assert sha(data)==digest
    destination=package/'source'/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(gzip.compress(data,mtime=0))
    snapshots.append({'kind':'immutable-source','path':name,'sha256':digest,'file':str(destination.relative_to(package))})
for name,digest in receipt['native_hashes'].items():
    data=(repo/'node_modules/three'/name).read_bytes();assert sha(data)==digest
    destination=package/'native'/(name+'.gz');destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(gzip.compress(data,mtime=0))
    snapshots.append({'kind':'installed-native-module','path':name,'sha256':digest,'file':str(destination.relative_to(package))})
(package/'snapshot-provenance.json').write_text(json.dumps(snapshots,indent=2)+'\n')
readme='''# Exact buffer-owner diagnostic CI audit

Source: `1d17083c7364b0d960d3f4a548139ac95077daa2`; reviewed tree `efa81a0e2ef87d079d355a457c67be24b0a8f263`.
Run: https://github.com/cheshmakzanoon-ops/Experiment-3/actions/runs/44631109424 (attempt1).

All five jobs are terminal. Build, component GPU7/7, gameplay1/1 and menu7/7 passed. High1/1 failed its unchanged90000ms readiness predicate (expected paused, received loading). The16 original case identities match the prior f226 suite exactly:15pass,1fail,0skip/flaky/retry.

All five original artifact ZIPs match GitHub size and SHA256; their receipts are included. The ZIPs remain in the parent audit directory, outside this compact package. The exact build source marker, embedded identity and bundled native devtools hook are verified. Five complete decoded job logs are retained losslessly as gzip with decoded hashes.

The strongest owner record is returned bufferData sequence23145: a26568-byte index view for Aurel garage bay5 / AUREL_GARAGE / GARAGE_LOD1 / LOD1_GARAGE_TeamEnamel. Exact direct index, attributeversion0, context1/generation1, first bufferData start; its returned CPU span is12268.9ms. This identifies a native invocation; it does not establish duplicate bytes or isolated upload cost.

Seventeen sampled upload records are retained:3exact indices,3registered-array candidates,11unknown. Every sampled record reports inventory truncation; none may be used to infer complete scene coverage. No retained prior-view buffer relation, observer failure, or identity inconsistency appears. Missing history does not prove content uniqueness.

First chase begins34231.749ms after the recorded readiness-operation start. The final successful application diagnostic resolves9.93ms before the failed predicate's recorded end, so it is fresh after chase. The six local-reflection face capture/submission calls and one scene frame returned. GPU frame completion is still pending:submitted2/completed0, active wait13748.5ms. Do not describe the reflection GPU work as complete. The final native snapshot is a returned clientWaitSync under offscreen pit-service preparation. No later cockpit/driving/photo acceptance was reached.

The configured timeout is90000ms. The recorded trace-operation span is89704.857ms; these are distinct boundaries, preserved without redefining the acceptance deadline. Native CPU spans can wait behind prior queued GPU work. Added metadata overhead is outside those spans and inside total startup time. The diagnostic changed no production source, so cross-run timing differences are not a demonstrated optimization.

Start with summary.json, high/first-chase-boundary.json and high/buffer-owner-analysis.json. Full bounded owner records and prior-view relations are gzip JSON. Original trace-derived console records, latest application diagnostic, assertion timeline,177 worker label transitions and original test attachments are preserved in high/. Source and installed native snapshots are unchanged compressed bytes. Parsers are included as gzip source; they write only within their selected audit directory.

No workflow rerun/cancellation, source/ref mutation, or local browser occurred during this audit. Authored-scene appearance and original High acceptance remain unresolved.
'''
(root/'README.md').write_text(readme);(package/'README.md').write_text(readme)
manifest=[]
for p in sorted(package.rglob('*')):
    if p.is_file(): manifest.append(f'{sha(p.read_bytes())}  {p.relative_to(package)}')
(package/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
allfiles=[p for p in package.rglob('*') if p.is_file()]
print(json.dumps({'package':str(package),'files':len(allfiles),'bytes':sum(p.stat().st_size for p in allfiles),
    'summarySha256':sha((package/'summary.json').read_bytes()),'originalArtifactsVerified':len(artifacts),
    'completeJobLogs':len(logs),'originalCases':16,'passed':15,'failed':1}))
