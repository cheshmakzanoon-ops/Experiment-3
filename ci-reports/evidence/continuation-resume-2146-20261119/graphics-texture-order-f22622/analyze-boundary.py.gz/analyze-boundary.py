"""Derive bounded native timing from retained evidence, without rerunning a browser."""
from pathlib import Path
import gzip
import json

root = Path(__file__).resolve().parent / 'high'
analysis = json.loads((root / 'native-analysis.json').read_text())
latest = json.loads(gzip.decompress((root / 'last-trace-diagnostic.json.gz').read_bytes()))
records = [json.loads(row) for row in gzip.decompress(
    (root / 'native-console-records.jsonl.gz').read_bytes()).splitlines()]
start = analysis['readinessPredicate']['before']['startTime']
end = analysis['readinessPredicate']['after']['endTime']
chase = analysis['firstChase']['traceTime']
activities = [row for row in records if row.get('kind') == 'activity']
before = max((row for row in activities if row['traceTime'] < chase), key=lambda row: row['traceTime'])
last = max((row for row in activities if row['traceTime'] < end), key=lambda row: row['traceTime'])
delta = {key: {method: last[key].get(method, 0) - before[key].get(method, 0)
               for method in sorted(set(last[key]) | set(before[key]))}
         for key in ['counts', 'cpuMs']}
metadata_methods = ['compileShader', 'linkProgram', 'getProgramInfoLog',
                    'getActiveUniform', 'getUniformLocation', 'getActiveAttrib', 'getAttribLocation']
assert all(delta['counts'][method] == 0 for method in metadata_methods)
assert latest['diagnostic']['buildIdentity']['commit'] == 'f22622e3302ed6147c5aae6f8eb6f6bc4057a242'
labels = []
for record in records:
    label = record.get('stage')
    if label is None or (labels and labels[-1]['stage'] == label):
        continue
    labels.append({'traceTime': record['traceTime'], 'stage': label,
                   'relativeToReadinessMs': record['traceTime'] - start,
                   'kind': record['kind']})
for index, label in enumerate(labels[:-1]):
    label['nextObservedLabelAfterMs'] = labels[index + 1]['traceTime'] - label['traceTime']
boundary = {
    'source': 'f22622e3302ed6147c5aae6f8eb6f6bc4057a242', 'run': 44623276067,
    'predicate': {'start': start, 'end': end, 'durationMs': end - start, 'configuredMs': 90000},
    'firstChaseRelativeMs': chase - start, 'deadlineRemainingAtFirstChaseMs': end - chase,
    'preChaseSnapshot': {'traceTime': before['traceTime'], 'stage': before['stage']},
    'lastSnapshot': {'traceTime': last['traceTime'], 'relativeMs': last['traceTime'] - start,
                     'beforeFailureMs': end - last['traceTime'], 'stage': last['stage'],
                     'inFlight': last['inFlight'], 'observedInFlightMs': last['observedInFlightMs'],
                     'lastStarted': last['lastStarted'], 'lastCompleted': last['lastCompleted']},
    'lastSuccessfulApplicationDiagnostic': {
        'traceTime': latest['endTime'], 'relativeMs': latest['endTime'] - start,
        'beforeChaseMs': chase - latest['endTime'], 'staleAfterChaseBegins': latest['endTime'] < chase,
        'buildIdentity': latest['diagnostic']['buildIdentity'],
        'state': latest['diagnostic']['state'],
        'warmupFrames': latest['diagnostic']['renderer']['warmupFrames'],
        'gpuFrameQueue': latest['diagnostic']['renderer']['gpuFrameQueue']},
    'observedChaseDelta': delta,
    'latePrograms': analysis['latePrograms'],
    'consoleErrorsAndWarnings': analysis['consoleErrorsAndWarnings'],
    'limitations': [
        'This is the observed first-chase interval, not total construction/preparation work.',
        'Only selected pre-chase labels enable native tracing; earlier texture preparation is not fully counted.',
        'Native CPU timing can include queued earlier driver work; it is not isolated upload or GPU time.',
        'bufferData starts include the final in-flight call; returned-call CPU totals exclude its unfinished duration.',
        'No native buffer handle or submitted payload hash is retained. Current shader/framebuffer/byte size does not identify the resource or duplicate transfer.',
        'The last successful application diagnostic predates chase and cannot certify post-chase completion.',
        'No paused, driving, cockpit or photo acceptance follows the failed readiness predicate.',
        'The cancelled c9d3ff run has no browser result, so the two source changes cannot be timed independently.']}
(root / 'first-chase-boundary.json').write_text(json.dumps(boundary, indent=2) + '\n')
(root / 'worker-label-timeline.json').write_text(json.dumps(labels, indent=2) + '\n')
print(json.dumps({'predicateMs': end - start, 'firstChaseRelativeMs': chase - start,
                  'lastObservedBeforeFailureMs': end - last['traceTime'],
                  'latePrograms': len(analysis['latePrograms']),
                  'metadataDeltas': {name: delta['counts'][name] for name in metadata_methods},
                  'labelChanges': len(labels)}, indent=2))
