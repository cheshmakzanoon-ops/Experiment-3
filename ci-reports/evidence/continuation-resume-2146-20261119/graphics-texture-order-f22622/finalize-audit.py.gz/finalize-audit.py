"""Finalize the source-specific evidence package without touching any repository."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil

P = Path(__file__).resolve().parent
SOURCE = 'f22622e3302ed6147c5aae6f8eb6f6bc4057a242'
TREE = 'c413cd5062b6555d1e607297e99ad93db123de77'
RUN = 44623276067

def read(name):
    path = P / name
    return json.loads(gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes())

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (P / name).write_text(json.dumps(value, indent=2) + '\n')

run, jobs = read('run-final.json'), read('jobs-final.json')['jobs']
assert run['id'] == RUN and run['head_sha'] == SOURCE and run['head_commit']['tree_id'] == TREE
assert run['status'] == 'completed' and run['conclusion'] == 'failure' and run['run_attempt'] == 1
assert len(jobs) == 5 and all(job['status'] == 'completed' for job in jobs)
assert sum(job['conclusion'] == 'success' for job in jobs) == 4
assert next(job for job in jobs if job['name'] == 'high')['conclusion'] == 'failure'
counts, artifacts, case_ids = {}, {}, set()
for group in ['gpu', 'menu', 'gameplay', 'high']:
    cases = read(group + '-case-results.json')
    for case in cases:
        assert case['testId'] not in case_ids
        case_ids.add(case['testId'])
    counts[group] = {'cases': len(cases),
                     'passed': sum(case['outcome'] == 'expected' for case in cases),
                     'failed': sum(case['outcome'] == 'unexpected' for case in cases),
                     'skipped': sum(case['outcome'] == 'skipped' for case in cases),
                     'flaky': sum(case['outcome'] == 'flaky' for case in cases),
                     'retries': sum(result['retry'] or 0 for case in cases for result in case['results'])}
    assert counts[group]['skipped'] == counts[group]['flaky'] == counts[group]['retries'] == 0
    if group != 'high':
        assert all(result['status'] == 'passed' and not result['errors']
                   for case in cases for result in case['results'])
    receipt = read(group + '-download-receipt.json')
    assert receipt['sourceCommit'] == SOURCE and receipt['runId'] == RUN
    assert receipt['matchesGitHubArtifactDigest']
    artifacts[group] = {**receipt, 'originalZipIncludedInCompactPackage': False}
assert counts['gpu']['passed'] == counts['menu']['passed'] == 7
assert counts['gameplay']['passed'] == counts['high']['failed'] == 1 and len(case_ids) == 16
log_receipts = []
for group in ['build', 'gpu', 'menu', 'gameplay', 'high']:
    receipt = read(group + '-log-receipt.json')
    compressed = (P / receipt['file']).read_bytes()
    raw = gzip.decompress(compressed)
    assert sha(compressed) == receipt['gzipSha256']
    assert sha(raw) == receipt['decodedSha256'] and len(raw) == receipt['decodedBytes']
    assert SOURCE in raw.decode() and receipt['sourceCommit'] == SOURCE and receipt['runId'] == RUN
    log_receipts.append(receipt)
save('log-provenance.json', log_receipts)
source = read('source-provenance.json')
for item in source['files']:
    raw = gzip.decompress((P / item['file']).read_bytes())
    assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
for item in read('high/attachment-manifest.json'):
    if 'file' not in item:
        continue
    path = P / 'high' / item['file']
    raw = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    assert sha(raw) == item['sha256']
    if 'bytes' in item:
        assert len(raw) == item['bytes']
boundary = read('high/first-chase-boundary.json')
analysis = read('high/native-analysis.json')
latest = read('high/last-trace-diagnostic.json.gz')
assert boundary['source'] == SOURCE and boundary['run'] == RUN
assert latest['diagnostic']['buildIdentity']['commit'] == SOURCE
assert boundary['lastSuccessfulApplicationDiagnostic']['staleAfterChaseBegins']
assert not analysis['latePrograms'] and not analysis['consoleErrorsAndWarnings']
assert not any(item.get('name', '').startswith('high-gp-') and item.get('contentType') == 'image/png'
               for item in read('high/attachment-manifest.json'))
summary = {
    'repository': 'cheshmakzanoon-ops/Experiment-3', 'sourceCommit': SOURCE, 'tree': TREE,
    'reviewedLocalCommit': '62f18b868163a9c86857ac3222414484b92bffc9', 'runId': RUN,
    'workflowUrl': run['html_url'], 'attempt': 1, 'status': 'completed', 'conclusion': 'failure',
    'accepted': False, 'createdAt': run['created_at'], 'updatedAt': run['updated_at'],
    'jobs': [{key: job.get(key) for key in ['id', 'name', 'status', 'conclusion',
                                           'started_at', 'completed_at', 'html_url']} for job in jobs],
    'browserCounts': counts, 'totalCases': 16, 'passed': 15, 'failed': 1,
    'skipped': 0, 'flaky': 0, 'retries': 0,
    'highFailure': {'path': 'e2e/graphics-high-journey.spec.ts', 'line': 786,
                    'expected': 'paused', 'received': 'loading', 'configuredTimeoutMs': 90000,
                    'observedPredicateMs': boundary['predicate']['durationMs'],
                    'testDurationMs': analysis['durationMs']},
    'highBoundary': boundary,
    'construction': latest['diagnostic']['renderer']['construction'],
    'lastObservedPreparation': latest['diagnostic']['renderer']['preparation'],
    'lastObservedPreparationIsPreChase': True,
    'highPhotoViewsReached': False, 'authoredHighAppearanceAccepted': False,
    'originalAssertionsNotReached': ['paused/preparation/GPU completion',
                                     'active finite GP chassis after resuming',
                                     'two completed photo views and original High dimensions',
                                     'final application/backend/error acceptance'],
    'backend': read('high/browser-backend.json'), 'artifacts': artifacts,
    'nativeSourceReview': 'Accepted as fixture owner/payload/lifecycle and initial construction routing evidence only.',
    'pixelScope': 'The far-shadow inputs intentionally adopt selected final policy; no old pixel equivalence or authored High appearance acceptance is claimed.',
    'cancelledPredecessor': {'source': 'c9d3ff07f0b459697133e5c6d68dcbe8492bd2ab',
                            'run': 44620560801, 'result': 'cancelled with zero artifacts and no acceptance verdict',
                            'evidenceDirectory': '../texture-ci-c9d3ff-audit-2144'},
    'auditActions': 'GitHub reads, immutable local Git reads and new source-specific scratch evidence only. No tests, source/ref changes, workflow rerun or cancellation.'}
save('summary.json', summary)
package = P / 'review-package'
assert not package.exists(), 'Refusing to overwrite a finalized package'
package.mkdir()
names = ['README.md', 'SOURCE-REVIEW.md', 'summary.json', 'run-final.json', 'jobs-final.json',
         'artifacts-final.json', 'source-identity.json', 'source-provenance.json',
         'source-metadata.json', 'log-provenance.json', 'parser-provenance.json']
names += [group + '-job.log.gz' for group in ['build', 'gpu', 'menu', 'gameplay', 'high']]
names += [group + '-case-results.json' for group in ['gpu', 'menu', 'gameplay', 'high']]
names += [group + '-download-receipt.json' for group in ['gpu', 'menu', 'gameplay', 'high']]
names += [group + '-browser-backend.json' for group in ['gpu', 'menu', 'gameplay']]
for name in names:
    shutil.copy2(P / name, package / name)
for name in ['high', 'source']:
    shutil.copytree(P / name, package / name)
for name in ['analyze-high.py', 'analyze-boundary.py', 'extract-report.py',
             'verify-artifact.py', 'snapshot-source.py', 'finalize-audit.py']:
    (package / (name + '.gz')).write_bytes(gzip.compress((P / name).read_bytes(), mtime=0))
manifest = [sha(path.read_bytes()) + '  ' + str(path.relative_to(package))
            for path in sorted(package.rglob('*')) if path.is_file()]
(package / 'SHA256SUMS').write_text('\n'.join(manifest) + '\n')
receipt = {'path': str(package), 'files': len(manifest) + 1,
           'bytes': sum(path.stat().st_size for path in package.rglob('*') if path.is_file()),
           'sourceCommit': SOURCE, 'runId': RUN,
           'summarySha256': sha((package / 'summary.json').read_bytes()),
           'sourceAndLogHashesVerified': True, 'fourOriginalZipDigestsPreviouslyVerified': True}
save('package-receipt.json', receipt)
print(json.dumps(receipt, indent=2))
