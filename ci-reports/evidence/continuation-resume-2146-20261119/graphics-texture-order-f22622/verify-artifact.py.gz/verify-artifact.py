"""Verify a downloaded original CI artifact before extracting its evidence."""
import hashlib
import json
import pathlib
import sys
import zipfile

root = pathlib.Path(__file__).resolve().parent
group = sys.argv[1]
descriptor = json.loads((root / f'{group}-artifact-descriptor.json').read_text())
assert descriptor['workflow_run']['head_sha'] == 'f22622e3302ed6147c5aae6f8eb6f6bc4057a242'
assert descriptor['workflow_run']['id'] == 44623276067
archive = root / f'texture-{group}-f22622.zip'
data = archive.read_bytes()
sha = hashlib.sha256(data).hexdigest()
assert len(data) == descriptor['size_in_bytes']
assert 'sha256:' + sha == descriptor['digest']
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
receipt = {'artifactId': descriptor['id'], 'name': descriptor['name'],
           'sourceCommit': descriptor['workflow_run']['head_sha'],
           'runId': descriptor['workflow_run']['id'], 'file': archive.name,
           'bytes': len(data), 'sha256': sha,
           'githubArtifactDigest': descriptor['digest'],
           'matchesGitHubArtifactDigest': True,
           'deliveryFileId': descriptor['deliveryFileId'],
           'acquisition': 'GitHub artifact GET through its authorized file delivery; no workflow mutations'}
(root / f'{group}-download-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
