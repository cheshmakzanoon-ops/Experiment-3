"""Retain immutable reviewed source; all writes stay beside this audit script."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/dac6891506fb/Experiment-3')
LOCAL = '62f18b868163a9c86857ac3222414484b92bffc9'
BASE = '4b9d6bb70f1443930ae674e610dc14d61e187ee3'
TREE = 'c413cd5062b6555d1e607297e99ad93db123de77'
EVIDENCE = 'docs/studio/reports/evidence/static-scene-texture-order-20261119/'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

assert git('rev-parse', LOCAL + '^{tree}').decode().strip() == TREE
assert git('rev-parse', LOCAL + '^').decode().strip() == BASE
receipt = json.loads(git('show', LOCAL + ':' + EVIDENCE + 'receipt.json'))
paths = list(receipt['sources']) + [EVIDENCE + name for name in receipt['logs']]
paths += [EVIDENCE + 'receipt.json', 'docs/studio/reports/static-scene-texture-order-2026-11-19.md']
provenance = []
for path in paths:
    assert not Path(path).is_absolute() and '..' not in Path(path).parts
    raw = git('show', LOCAL + ':' + path)
    entry = receipt['sources'].get(path) or receipt['logs'].get(Path(path).name)
    sha = hashlib.sha256(raw).hexdigest()
    if entry:
        assert len(raw) == entry['bytes'] and sha == entry['sha256']
    destination = ROOT / 'source' / (path + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(gzip.compress(raw, mtime=0))
    provenance.append({'path': path, 'file': str(destination.relative_to(ROOT)),
                       'bytes': len(raw), 'sha256': sha,
                       'blob': git('rev-parse', LOCAL + ':' + path).decode().strip()})
diff = git('diff', BASE, LOCAL, '--', 'src/rendering/renderer.ts')
(ROOT / 'source' / 'renderer-order.patch').write_bytes(diff)
assert git('diff', BASE, LOCAL, '--', 'e2e', '.github/workflows/graphics-high-diagnostic.yml') == b''
result = {'localCommit': LOCAL, 'baseCommit': BASE, 'tree': TREE,
          'remoteCommit': 'f22622e3302ed6147c5aae6f8eb6f6bc4057a242',
          'files': provenance, 'allReceiptHashesMatched': True,
          'originalE2EAndWorkflowUnchanged': True,
          'rendererDiffSha256': hashlib.sha256(diff).hexdigest()}
(ROOT / 'source-provenance.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'files': len(provenance), 'allReceiptHashesMatched': True, 'tree': TREE}))
