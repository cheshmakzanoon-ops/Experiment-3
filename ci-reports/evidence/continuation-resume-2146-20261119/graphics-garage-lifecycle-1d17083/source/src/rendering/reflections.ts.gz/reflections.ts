import * as T from 'three';
import { MirrorViews } from './mirrors.ts';
import { STUDIO_REFLECTION_LAYER } from './photo-stage.ts';
import { cullProbeDetail, type ProbeDetail } from './probe-detail.ts';
import { hasSpecularIBL, setOwnEnvMap } from './studio/ibl-energy.ts';
import { compileProbeBackground, compileProbeBlur } from './pmrem-preparation.ts';

/** Local probe face size (High). 256 px keeps a 0.04 clearcoat's horizon line
 * crisp; draws per face are unchanged. */
export const PROBE_FACE_SIZE = 256;
/** Detail culling keeps its 128 px-face texel threshold: props below one such
 * texel are a few texels at 256 px but would cost one draw per face. */
export const PROBE_DETAIL_FACE_SIZE = 128;
/** Moving captures may replace the ordinary time cadence, but never raise
 * its normal start rate above two cycles per second. A caller's explicitly
 * faster time cadence remains valid. Face work is still bounded separately.
 * These are capture-origin distances, not accumulated path length or heading:
 * a world-oriented cubemap remains valid when a stationary car turns. */
export const PROBE_MOTION_REFRESH = Object.freeze({ distance: 12, minimumInterval: 0.5 });
type ProbeRefreshReason = 'immediate' | 'motion' | 'scenery' | 'cadence';

/** Coordinates recursive render passes. Mirrors render actual rear-facing camera feeds, and are hidden during other mirror/probe passes to prevent cycles. */
export class ReflectionSystem {
  private views = new MirrorViews();
  private surfaces: T.Mesh[] = [];
  private preparationRenderer: T.WebGLRenderer | null = null;
  private prefilterPreparation: T.PMREMGenerator | null = null;
  private backgroundPreparation: T.MeshBasicMaterial | null = null;
  private prefilterPrograms: T.WebGLProgram[] = [];
  private disposed = false;
  /** Link the same background, conversion and blur programs used by Three's sky/local-map cache
   * before asset/scenery preparation. A linear target matters: this is a
   * ShaderMaterial, so compiling against the tone-mapped canvas uses another
   * program key. This owner never captures or allocates a GPU PMREM atlas. */
  beginProbePreparation(renderer: T.WebGLRenderer, target: T.WebGLRenderTarget) {
    if (this.disposed) return;
    if (this.preparationRenderer) {
      if (this.preparationRenderer !== renderer)
        throw new Error('Reflection preparation belongs to another renderer');
      return;
    }
    const previous = renderer.getRenderTarget(),
      face = renderer.getActiveCubeFace(),
      mip = renderer.getActiveMipmapLevel(),
      viewport = renderer.getViewport(new T.Vector4()),
      scissor = renderer.getScissor(new T.Vector4()),
      scissorTest = renderer.getScissorTest();
    // r180 retains programs by reference count. Identify this material's
    // acquired reference, including when the exact program already exists.
    const references = new Map(
      (renderer.info.programs ?? []).map((program) => [program, program.usedTimes]),
    );
    let preparation: T.PMREMGenerator | null = null;
    let background: T.MeshBasicMaterial | null = null;
    try {
      renderer.setRenderTarget(target);
      preparation = new T.PMREMGenerator(renderer);
      preparation.compileCubemapShader();
      compileProbeBlur(preparation, PROBE_FACE_SIZE);
      background = compileProbeBackground(renderer);
      const backgroundPrograms = new Set(
        (
          renderer.properties.get(background) as {
            programs?: Map<string, T.WebGLProgram>;
          }
        ).programs?.values() ?? [],
      );
      const acquired = (renderer.info.programs ?? []).filter(
        (program) =>
          (program.name === 'CubemapToCubeUV' ||
            program.name === 'SphericalGaussianBlur' ||
            backgroundPrograms.has(program)) &&
          program.usedTimes > (references.get(program) ?? 0),
      );
      if (acquired.length !== 3 || backgroundPrograms.size !== 1)
        throw new Error('Reflection prefilter programs were not retained by the renderer');
      this.preparationRenderer = renderer;
      this.prefilterPreparation = preparation;
      this.backgroundPreparation = background;
      this.prefilterPrograms = acquired;
      preparation = null;
      background = null;
    } finally {
      try {
        preparation?.dispose();
        background?.dispose();
      } finally {
        renderer.setRenderTarget(previous, face, mip);
        renderer.setViewport(viewport);
        renderer.setScissor(scissor);
        renderer.setScissorTest(scissorTest);
      }
    }
  }
  /** Called after the existing asset wait, before scene draws. Three defers
   * its error diagnostics and uniform/attribute queries until getUniforms().
   * Resolve them once here, rather than synchronizing behind six cube faces.
   * Disposal clears the pending program before an awaited owner can resume. */
  completeProbePreparation() {
    if (this.disposed) return;
    for (const program of this.prefilterPrograms) program.getUniforms();
    this.prefilterPrograms = [];
  }
  get mirrorUpdates() {
    return this.views.updates;
  }
  get mirrorWidth() {
    return this.views.targets[0].width;
  }
  get mirrorHeight() {
    return this.views.targets[0].height;
  }
  /** Chooses what each mirror pass shows of the scene (see MirrorViews.detail). */
  set mirrorDetail(detail: MirrorViews['detail']) {
    this.views.detail = detail;
  }
  get mirrors() {
    return this.surfaces;
  }
  /** Layer mask used by the local probe's cube cameras. */
  get probeLayers() {
    return this.cubes[0].layers;
  }
  /** The actual rear-facing mirror cameras (profiling and census). */
  get mirrorCameras(): readonly T.Camera[] {
    return this.views.cameras;
  }
  /** Pose the mirror cameras on `root` now. Feeds are rendered at their own
   * rate, so between passes the cameras can lag a moving car (profiling). */
  poseMirrorCameras(root: T.Object3D) {
    this.views.orient(root);
    return this.views.cameras;
  }
  probeUpdates = 0;
  /** Roots omitted from the local probe (other cars, people, particles, small
   * props): at 128 px per face they are a few texels but cost one draw each
   * per face. Visibility is restored even if a face throws. */
  probeExclusions: T.Object3D[] = [];
  private exclusionVisibility: boolean[] = [];
  /** Static scenery left out of a capture when, from the probe, it cannot
   * cover one cube-face texel. Restored like the exclusions. */
  probeDetail: readonly ProbeDetail[] = [];
  /** Detail drawables omitted from the most recent capture. */
  probeDetailOmitted = 0;
  private detailHidden: T.Object3D[] = [];
  /** The first complete capture draws every static drawable, so all scenery
   * is resident on the GPU before driving. Omitting detail from it left
   * sub-texel props to upload when the main view first reached them. */
  private sceneryResident = false;
  /** Cube faces a periodic refresh renders per frame (1-6). A whole capture
   * in one frame put about 940 extra draws on that frame every 1.5 s (0.55 s
   * wet). Below 6, a refresh renders into the back target over several
   * frames from one fixed eye and is published only when all six faces are
   * complete. First captures, seeks, subject and environment changes always
   * render all six faces at once. */
  probeFacesPerFrame = 6;
  /** Next face of the refresh in progress, or -1 when none is. */
  private pendingFace = -1;
  private pendingStart = 0;
  private pendingSceneryRevision = 0;
  private pendingReason: ProbeRefreshReason = 'immediate';
  /** Presentation time of the last refresh face. A paused or held frame does
   * no probe work: a refresh advances only as presentation time does. */
  private faceClock = NaN;
  private probeEye = new T.Vector3();
  private currentEye = new T.Vector3();
  private completedEye = new T.Vector3();
  private consideredClock = NaN;
  private lastStart = -Infinity;
  private lastCompleted = -Infinity;
  private sceneryRevision = 0;
  private externalSceneryRevision = 0;
  private capturedSceneryRevision = -1;
  private requestEpoch = 0;
  private attemptedEpoch = -1;
  private attemptedClock = NaN;
  private attemptedCar: T.Object3D | null = null;
  private attemptedEnvironment: object | null = null;
  private immediateRetryPending = false;
  private probeStarts = { immediate: 0, motion: 0, scenery: 0, cadence: 0 };
  private activePass = false;
  private clock = NaN;
  private enabled = false;
  private lastProbe = -Infinity;
  /** Specular IBL gain of the sky (see studio/ibl-energy.ts): the probe captures
   * the dome at environment × gain, the radiance sky-lit specular sees. */
  private specularGain = 1;
  private capturedEnvironment: object | null = null;
  // Alternate completed targets: a scene never samples the cubemap into which
  // it is currently rendering. Material programs stay stable between captures.
  private cubeTargets = [0, 1].map(
    () =>
      new T.WebGLCubeRenderTarget(PROBE_FACE_SIZE, {
        type: T.HalfFloatType,
        generateMipmaps: true,
        minFilter: T.LinearMipmapLinearFilter,
      }),
  );
  private cubes = this.cubeTargets.map((target) => {
    const camera = new T.CubeCamera(0.1, 1600, target);
    // CubeCamera's six face cameras share this Layers object. Preserve layer 0
    // scenery and include lighting cards without exposing them to driving views.
    camera.layers.enable(STUDIO_REFLECTION_LAYER);
    return camera;
  });
  private nextTarget = 0;
  private originalMaps = new Map<
    T.MeshStandardMaterial,
    {
      texture: T.Texture | null;
      intensity: number;
    }
  >();
  private capturedCar: T.Object3D | null = null;
  private probeActive = false;
  get localProbeActive() {
    return this.probeActive;
  }
  private restoreEnvironment() {
    for (const [material, original] of this.originalMaps) {
      material.envMap = original.texture;
      material.envMapIntensity = original.intensity;
      setOwnEnvMap(material, false);
      material.needsUpdate = true;
    }
    this.originalMaps.clear();
    this.probeActive = false;
    this.capturedCar = null;
    this.lastProbe = -Infinity;
    this.pendingFace = -1;
    this.lastStart = this.lastCompleted = -Infinity;
    this.consideredClock = this.attemptedClock = NaN;
    this.attemptedCar = null;
    this.immediateRetryPending = false;
    this.capturedSceneryRevision = -1;
  }
  /** Sky-only IBL uses the authored gain. A completed local cubemap already
   * contains lit scene radiance, so applying that gain again also darkens every
   * lamp and lit building (by 12.5x on an overcast night). Keep the fallback gain
   * current while a probe owns the map, and restore it on disable/subject change.
   * `specularGain` is the sky's specular IBL normalisation (apexSpecularIBL): the
   * recorded sky intensity of a sky-lit reflective material is its effective
   * specular gain, environment × specularGain (three uses the scene's
   * environmentIntensity for a material without an envMap of its own), and the
   * probe captures the dome at that same scale. A material without the
   * normalisation hook (hasSpecularIBL) records the plain environment, so the
   * reported gain (diag reflectionIntensity, KPI 7) is the one it renders. */
  setSkyIntensity(
    materials: readonly T.MeshStandardMaterial[],
    intensity: number,
    specularGain = 1,
  ) {
    if (!Number.isFinite(intensity) || intensity < 0)
      throw new Error('Invalid sky environment intensity');
    if (!Number.isFinite(specularGain) || specularGain < 1)
      throw new Error('Invalid sky specular gain');
    this.specularGain = specularGain;
    for (const material of materials) {
      const sky = hasSpecularIBL(material) ? intensity * specularGain : intensity;
      const original = this.originalMaps.get(material);
      if (original) original.intensity = sky;
      material.envMapIntensity = original ? 1 : sky;
    }
  }
  attachMirrors(surfaces: readonly T.Mesh[]) {
    for (const mirror of this.surfaces) mirror.visible = false;
    this.surfaces = [...surfaces];
    this.views.bind(surfaces);
  }
  quality(value: 'low' | 'medium' | 'high') {
    this.views.quality(value);
  }
  /** A seek invalidates captured scenery without rebuilding material programs.
   * Otherwise a probe from a later lap can remain installed until replay time
   * catches its old timestamp, and mirrors can briefly show the old position. */
  invalidate() {
    this.lastProbe = -Infinity;
    this.pendingFace = -1;
    this.requestEpoch++;
    this.views.invalidate();
  }
  /** Queue a bounded refresh for streamed/authored scenery. Changes arriving
   * during a six-face cycle coalesce into a later cycle; they never keep
   * restarting the back buffer. A held presentation waits until it resumes. */
  sceneryChanged() {
    this.sceneryRevision++;
  }
  /** Streamers can report their revision every frame without generating
   * needless captures when nothing changed. Other owners use sceneryChanged. */
  setSceneryRevision(revision: number) {
    if (!Number.isSafeInteger(revision) || revision < 0)
      throw new Error('Invalid reflection scenery revision');
    if (revision === this.externalSceneryRevision) return;
    this.externalSceneryRevision = revision;
    this.sceneryChanged();
  }
  get probeDiagnostics() {
    return {
      completed: this.probeUpdates,
      starts: { ...this.probeStarts },
      pendingFace: this.pendingFace,
      pendingReason: this.pendingFace >= 0 ? this.pendingReason : null,
      facesPerFrame: this.probeFacesPerFrame,
      motionDistance: PROBE_MOTION_REFRESH.distance,
      minimumInterval: PROBE_MOTION_REFRESH.minimumInterval,
      // Initial/seek/subject/environment captures deliberately retain their
      // existing six-face immediate cost; the ordinary face budget is not a
      // claim that these exceptional captures are sliced.
      immediateFaces: 6,
      immediateRetryPending: this.immediateRetryPending,
      lastStart: Number.isFinite(this.lastStart) ? this.lastStart : null,
      lastCompleted: Number.isFinite(this.lastCompleted) ? this.lastCompleted : null,
      capturedAt: Number.isFinite(this.lastProbe) ? this.lastProbe : null,
      origin: this.probeActive ? this.completedEye.toArray() : null,
      displacement: this.probeActive ? this.currentEye.distanceTo(this.completedEye) : 0,
      sceneryPending: this.capturedSceneryRevision !== this.sceneryRevision,
    };
  }
  beginFrame(time: number, cockpit: boolean) {
    if (!Number.isFinite(time)) throw new Error('Invalid reflection presentation time');
    if (
      !Number.isFinite(this.clock) ||
      time < this.clock ||
      time - this.clock > 2 ||
      cockpit !== this.enabled
    )
      this.invalidate();
    this.clock = time;
    this.enabled = cockpit;
    for (const mirror of this.mirrors) mirror.visible = cockpit;
  }
  renderMirrors(renderer: T.WebGLRenderer, scene: T.Scene, root: T.Object3D, dt: number) {
    if (this.enabled && !this.activePass) this.views.render(renderer, scene, root, dt);
  }
  /** Roots omitted from the rear-view feeds (spectators, pit people, props). */
  set mirrorExclusions(roots: T.Object3D[]) {
    this.views.exclusions = roots;
  }
  get mirrorExclusions() {
    return this.views.exclusions;
  }
  updateProbe(
    renderer: T.WebGLRenderer,
    scene: T.Scene,
    car: T.Object3D,
    materials: readonly T.MeshStandardMaterial[],
    high: boolean,
    intervalSeconds = 1.5,
    skyScale?: { value: number },
  ) {
    if (this.activePass) return;
    if (!high) {
      if (this.probeActive) this.restoreEnvironment();
      this.pendingFace = -1;
      return;
    }
    if (!Number.isFinite(intervalSeconds) || intervalSeconds < 0.25 || intervalSeconds > 5)
      throw new Error('Invalid reflection probe interval');
    if (
      !Number.isInteger(this.probeFacesPerFrame) ||
      this.probeFacesPerFrame < 1 ||
      this.probeFacesPerFrame > 6
    )
      throw new Error('Invalid probe faces per frame');
    if (
      skyScale &&
      (!Number.isFinite(skyScale.value) ||
        !Number.isFinite(scene.environmentIntensity) ||
        scene.environmentIntensity < 0)
    )
      throw new Error('Invalid probe sky radiance');
    // Photo/replay inspection can select another real car at the SAME instant.
    // Never keep the first car's map owners or let cadence retain its location.
    if (this.capturedCar && this.capturedCar !== car) this.restoreEnvironment();
    // A paused lighting/weather-bin change must not retain a daytime cubemap.
    // PMREM identity changes discretely, unlike continuously changing exposure:
    // keying on intensity would force an expensive capture on every wet frame.
    const environmentIdentity: object | null =
      scene.environment?.userData.aurelSkyEpoch ?? scene.environment;
    const environmentChanged = environmentIdentity !== this.capturedEnvironment;
    car.getWorldPosition(this.currentEye);
    this.currentEye.y += 1.5;
    const advancing = this.clock !== this.consideredClock;
    this.consideredClock = this.clock;
    const immediate = environmentChanged || this.lastProbe === -Infinity,
      minimum = Math.min(intervalSeconds, PROBE_MOTION_REFRESH.minimumInterval);
    // Failed first/forced captures cannot resubmit six faces every frame.
    // The same request waits for the start budget, even before a cube exists.
    // A genuinely new source/subject/environment can still request a capture
    // at that instant, as can an explicit invalidate().
    if (
      this.requestEpoch === this.attemptedEpoch &&
      car === this.attemptedCar &&
      environmentIdentity === this.attemptedEnvironment &&
      (this.clock === this.attemptedClock ||
        (immediate && this.immediateRetryPending && this.clock - this.lastStart < minimum))
    )
      return;
    if (!immediate && !advancing) return;
    // First captures, seeks (invalidate) and subject or environment changes
    // render all six faces now and drop any refresh in progress.
    let from = 0,
      to = 6;
    let starting = false;
    if (immediate) {
      this.pendingFace = -1;
      this.pendingReason = 'immediate';
      this.immediateRetryPending = true;
      starting = true;
    } else if (this.pendingFace >= 0) {
      if (this.clock === this.faceClock) return;
      from = this.pendingFace;
      to = Math.min(6, from + this.probeFacesPerFrame);
    } else {
      const elapsed = this.clock - this.lastProbe,
        moved =
          this.currentEye.distanceToSquared(this.completedEye) >=
          PROBE_MOTION_REFRESH.distance ** 2,
        scenery = this.sceneryRevision !== this.capturedSceneryRevision;
      // Failed sliced captures also respect the start budget before retrying
      // from face zero. The last complete map remains installed meanwhile.
      if (this.clock - this.lastStart < minimum) return;
      if (elapsed < intervalSeconds && !(elapsed >= minimum && (moved || scenery))) return;
      this.pendingReason = moved ? 'motion' : scenery ? 'scenery' : 'cadence';
      starting = true;
      to = this.probeFacesPerFrame;
    }
    if (starting) {
      this.pendingStart = this.lastStart = this.clock;
      this.pendingSceneryRevision = this.sceneryRevision;
      this.probeStarts[this.pendingReason]++;
    }
    this.attemptedClock = this.clock;
    this.attemptedEpoch = this.requestEpoch;
    this.attemptedCar = car;
    this.attemptedEnvironment = environmentIdentity;
    // A failed face abandons the refresh; a bounded retry starts from face zero.
    this.pendingFace = -1;
    const cube = this.cubes[this.nextTarget];
    const visible = car.visible;
    const mirrorVisibility = this.mirrors.map((m) => m.visible);
    const shadows = renderer.shadowMap.autoUpdate;
    const target = renderer.getRenderTarget();
    const face = renderer.getActiveCubeFace();
    const mip = renderer.getActiveMipmapLevel();
    const viewport = renderer.getViewport(new T.Vector4());
    const scissor = renderer.getScissor(new T.Vector4());
    const scissorTest = renderer.getScissorTest();
    const xr = renderer.xr.enabled;
    const priorSkyScale = skyScale?.value;
    const mipmaps = cube.renderTarget.texture.generateMipmaps;
    // Capture one scene-radiance bounce, not a history of previously captured
    // reflections. In particular, the wet road must not feed the prior probe
    // back into the next one: that made identical replay seeks history-dependent.
    const previousMaps = [...this.originalMaps].map(([material, original]) => ({
      material,
      original,
      texture: material.envMap,
      intensity: material.envMapIntensity,
    }));
    this.activePass = true;
    try {
      this.mirrors.forEach((mirror) => {
        mirror.visible = false;
      });
      car.visible = false;
      this.exclusionVisibility.length = 0;
      for (const root of this.probeExclusions) {
        this.exclusionVisibility.push(root.visible);
        root.visible = false;
      }
      // Every face of one capture shares the eye of its first face.
      if (from === 0) this.probeEye.copy(this.currentEye);
      if (this.sceneryResident)
        cullProbeDetail(this.probeDetail, this.probeEye, PROBE_DETAIL_FACE_SIZE, this.detailHidden);
      this.probeDetailOmitted = this.detailHidden.length;
      for (const { material, original } of previousMaps) {
        material.envMap = original.texture;
        material.envMapIntensity = original.intensity;
        setOwnEnvMap(material, false);
      }
      renderer.shadowMap.autoUpdate = false;
      renderer.setScissorTest(false);
      // Scale only the visible skydome contribution, to the radiance sky-lit
      // specular sees (environment × specular gain, about the visible dome).
      // Lit scenery/emissive objects are already radiance and remain unscaled.
      // The ordinary visible sky is restored even if a cube face throws.
      if (skyScale) skyScale.value = scene.environmentIntensity * this.specularGain;
      cube.position.copy(this.probeEye);
      if (from === 0 && to === 6) cube.update(renderer, scene);
      else this.renderFaces(renderer, scene, cube, from, to);
      if (to === 6) {
        this.sceneryResident = true;
        this.probeUpdates++;
        // A spread refresh dates from its eye, so the cadence is unchanged.
        this.lastProbe = from === 0 && to === 6 ? this.clock : this.pendingStart;
        this.lastCompleted = this.clock;
        this.completedEye.copy(this.probeEye);
        this.capturedSceneryRevision = this.pendingSceneryRevision;
        this.capturedEnvironment = environmentIdentity;
        this.capturedCar = car;
        this.immediateRetryPending = false;
      }
    } finally {
      if (skyScale) skyScale.value = priorSkyScale!;
      cube.renderTarget.texture.generateMipmaps = mipmaps;
      for (const { material, texture, intensity } of previousMaps) {
        material.envMap = texture;
        material.envMapIntensity = intensity;
        setOwnEnvMap(material, true);
      }
      car.visible = visible;
      this.probeExclusions.forEach((root, i) => {
        if (i < this.exclusionVisibility.length) root.visible = this.exclusionVisibility[i];
      });
      for (const object of this.detailHidden) object.visible = true;
      this.detailHidden.length = 0;
      renderer.shadowMap.autoUpdate = shadows;
      renderer.xr.enabled = xr;
      renderer.setRenderTarget(target, face, mip);
      renderer.setViewport(viewport);
      renderer.setScissor(scissor);
      renderer.setScissorTest(scissorTest);
      this.mirrors.forEach((mirror, i) => {
        mirror.visible = mirrorVisibility[i];
      });
      this.activePass = false;
    }
    if (to < 6) {
      this.pendingFace = to;
      this.faceClock = this.clock;
      return;
    }
    // Publish only a completed six-face capture. A thrown GPU pass leaves the
    // last complete reflection and all renderer ownership untouched.
    const texture = this.cubeTargets[this.nextTarget].texture;
    for (const material of materials) {
      if (!this.originalMaps.has(material)) {
        this.originalMaps.set(material, {
          texture: material.envMap,
          intensity: material.envMapIntensity,
        });
        material.needsUpdate = true;
      }
      material.envMap = texture;
      material.envMapIntensity = 1;
      setOwnEnvMap(material, true);
    }
    this.probeActive = true;
    this.nextTarget = 1 - this.nextTarget;
  }
  /** CubeCamera.update for faces [from, to) only: the same cameras, face
   * order and target; the mip chain is generated once, by the sixth face. */
  private renderFaces(
    renderer: T.WebGLRenderer,
    scene: T.Scene,
    cube: T.CubeCamera,
    from: number,
    to: number,
  ) {
    if (cube.coordinateSystem !== renderer.coordinateSystem) {
      cube.coordinateSystem = renderer.coordinateSystem;
      cube.updateCoordinateSystem();
    }
    cube.updateMatrixWorld();
    const texture = cube.renderTarget.texture,
      mipmaps = texture.generateMipmaps;
    renderer.xr.enabled = false;
    try {
      for (let face = from; face < to; face++) {
        texture.generateMipmaps = mipmaps && face === 5;
        renderer.setRenderTarget(cube.renderTarget, face, cube.activeMipmapLevel);
        renderer.render(scene, cube.children[face] as T.Camera);
      }
    } finally {
      texture.generateMipmaps = mipmaps;
    }
    if (to === 6) texture.needsPMREMUpdate = true;
  }
  diagnostics(renderer: T.WebGLRenderer) {
    return this.mirrors.map((mirror, i) => {
      const target = this.views.targets[i];
      const width = Math.min(48, target.width),
        height = Math.min(32, target.height);
      // Mirror feeds are half-float (linear HDR). Read them in their own type
      // (a byte read of a float target is a GL error that outlives this call)
      // and quantise the clamped linear values as the former 8-bit target did.
      const half = target.texture.type === T.HalfFloatType;
      const raw = half ? new Uint16Array(width * height * 4) : new Uint8Array(width * height * 4);
      renderer.readRenderTargetPixels(
        target,
        Math.floor((target.width - width) / 2),
        Math.floor((target.height - height) / 2),
        width,
        height,
        raw,
      );
      const pixels = half
        ? Uint8Array.from(raw, (h) =>
            Math.round(Math.min(1, Math.max(0, T.DataUtils.fromHalfFloat(h))) * 255),
          )
        : (raw as Uint8Array);
      let min = 255,
        max = 0,
        peak = 0,
        hash = 2166136261;
      if (half)
        for (let i = 0; i < raw.length; i++)
          if (i % 4 !== 3) peak = Math.max(peak, T.DataUtils.fromHalfFloat(raw[i]));
      for (let i = 0; i < pixels.length; i++) {
        if (i % 4 === 3) continue;
        min = Math.min(min, pixels[i]);
        max = Math.max(max, pixels[i]);
        hash = Math.imul(hash ^ pixels[i], 16777619);
      }
      return {
        name: mirror.name,
        width: target.width,
        height: target.height,
        range: max - min,
        /** Largest linear (pre-exposure) value in the sampled centre. */
        peak,
        hash: hash >>> 0,
      };
    });
  }
  dispose() {
    this.disposed = true;
    this.prefilterPrograms = [];
    this.preparationRenderer = null;
    this.prefilterPreparation?.dispose();
    this.backgroundPreparation?.dispose();
    this.prefilterPreparation = null;
    this.backgroundPreparation = null;
    this.views.dispose();
    this.surfaces.length = 0;
    this.restoreEnvironment();
    this.cubeTargets.forEach((target) => target.dispose());
  }
}
